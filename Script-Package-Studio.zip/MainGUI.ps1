$version = "v3.1.51"
# Script-Package GUI - WPF, styled with the BatchAV Studio design system.
# All script logic and cmdlet calls are unchanged; only the UI layer moved
# from WinForms to WPF (src/ui.ps1 + src/scripts*.ps1 + src/xaml/Styles.xaml).
#
# Need these 2 modules:
# Install-Module -Name Microsoft.Graph -Force -AllowClobber
# Install-Module -Name ExchangeOnlineManagement -Force -AllowClobber

# Must run as administrator (runtime check instead of #Requires so automated
# UI tests can run un-elevated with SP_SHOT / SP_TEST set)
if (-not $env:SP_SHOT -and -not $env:SP_TEST) {
	$principal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
	if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
		Add-Type -AssemblyName PresentationFramework
		[void][System.Windows.MessageBox]::Show(
			"Script-Package Studio must be run as administrator.`nRight-click Script-Package-Studio.bat and choose 'Run as administrator'.",
			"Script-Package Studio", 'OK', 'Error')
		exit 1
	}
}

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Xaml

# Give the process its own taskbar identity. Without this the window is grouped
# under pwsh.exe and the taskbar shows the PowerShell icon instead of the app's.
# Must run before the window is created.
try {
	$aumidSig = '[DllImport("shell32.dll")] public static extern int SetCurrentProcessExplicitAppUserModelID([MarshalAs(UnmanagedType.LPWStr)] string AppID);'
	$aumidType = Add-Type -MemberDefinition $aumidSig -Name 'AppUserModelId' -Namespace 'SPS' -PassThru -ErrorAction Stop
	[void]$aumidType::SetCurrentProcessExplicitAppUserModelID('Avromiep.ScriptPackageStudio')
} catch {}

$script:SrcDir = Join-Path $PSScriptRoot 'src'
$script:SettingsIniPath = Join-Path $PSScriptRoot 'settings.ini'

. (Join-Path $script:SrcDir 'ui.ps1')

# ---- settings (persisted in settings.ini) -----------------------------------
$script:Settings = @{
	theme        = 'Dark'
	winWidth     = 560
	winHeight    = 760
	winMaximized = $false
	logExpanded  = $false
	blurTenant   = $false
}

function Read-AppSettings {
	if (-not (Test-Path -LiteralPath $script:SettingsIniPath)) { return }
	foreach ($line in (Get-Content -LiteralPath $script:SettingsIniPath -ErrorAction Ignore)) {
		if ($line -match '^\s*Theme\s*=\s*(Dark|Light)\s*$') { $script:Settings.theme = $Matches[1] }
		elseif ($line -match '^\s*WinWidth\s*=\s*(\d+)\s*$') { $script:Settings.winWidth = [Math]::Max(470, [int]$Matches[1]) }
		elseif ($line -match '^\s*WinHeight\s*=\s*(\d+)\s*$') { $script:Settings.winHeight = [Math]::Max(560, [int]$Matches[1]) }
		elseif ($line -match '^\s*WinMaximized\s*=\s*(0|1)\s*$') { $script:Settings.winMaximized = $Matches[1] -eq '1' }
		elseif ($line -match '^\s*LogExpanded\s*=\s*(0|1)\s*$') { $script:Settings.logExpanded = $Matches[1] -eq '1' }
		elseif ($line -match '^\s*BlurTenant\s*=\s*(0|1)\s*$') { $script:Settings.blurTenant = $Matches[1] -eq '1' }
	}
}

function Save-AppSettings {
	try {
		$values = [ordered]@{
			Theme        = $script:Settings.theme
			WinWidth     = [string][int]$script:Settings.winWidth
			WinHeight    = [string][int]$script:Settings.winHeight
			WinMaximized = if ($script:Settings.winMaximized) { '1' } else { '0' }
			LogExpanded  = if ($script:Settings.logExpanded) { '1' } else { '0' }
			BlurTenant   = if ($script:Settings.blurTenant) { '1' } else { '0' }
		}
		$lines = @()
		if (Test-Path -LiteralPath $script:SettingsIniPath) { $lines = @(Get-Content -LiteralPath $script:SettingsIniPath) }
		else { $lines = @('[General]') }
		$pending = [System.Collections.Generic.HashSet[string]]::new([string[]]$values.Keys)
		$lines = @($lines | ForEach-Object {
			$out = $_
			foreach ($k in $values.Keys) {
				if ($_ -match "^\s*$k\s*=") { $out = "$k=$($values[$k])"; [void]$pending.Remove($k); break }
			}
			$out
		})
		foreach ($k in $values.Keys) { if ($pending.Contains($k)) { $lines += "$k=$($values[$k])" } }
		Set-Content -LiteralPath $script:SettingsIniPath -Value $lines -Encoding UTF8
	} catch {}
}

# Settings retrieval function (kept for the hidden "Reload-Settings" entry)
function LoadSettings {
	Write-Host "Loading settings from settings.ini..."
	Read-AppSettings
	Apply-Theme $script:Settings.theme
	Write-Host "Loaded settings."
}

Read-AppSettings

# ---- styles + theme engine ---------------------------------------------------
$script:StyleDict = Read-XamlFile (Join-Path $script:SrcDir 'xaml\Styles.xaml')
[void]$script:StyleDict.MergedDictionaries.Add((Read-XamlString $script:ExtraStylesXaml))

# Use the icon font bundled with the app so glyphs render on EVERY Windows
# version. The Segoe Fluent Icons / Segoe MDL2 Assets fonts only ship with
# Windows 10/11 - on Windows Server 2012/2016 and older, they are missing and
# every icon shows as an empty box. Fluent System Icons (MIT) travels with us.
try {
	# Build the FontFamily via its TypeConverter, not New-Object: only a
	# converter-created FontFamily survives being applied through DynamicResource
	# (a New-Object one re-parses its source string and throws). The source is an
	# absolute, %20-encoded file URI so it holds even with spaces in the path.
	$iconFontRef = ([Uri]((Join-Path $PSScriptRoot 'Fonts') + '\')).AbsoluteUri + '#FluentSystemIcons-Resizable'
	$iconFontConv = [System.ComponentModel.TypeDescriptor]::GetConverter([System.Windows.Media.FontFamily])
	$script:StyleDict['IconFont'] = $iconFontConv.ConvertFromString($iconFontRef)
} catch {}

# ---- global TextBox behaviors (every TextBox in the app, dialogs included) --------
# Ctrl+Shift+V pastes (like Ctrl+V); double-clicking a text box selects all its text.
[System.Windows.EventManager]::RegisterClassHandler(
	[System.Windows.Controls.TextBox],
	[System.Windows.UIElement]::PreviewKeyDownEvent,
	[System.Windows.Input.KeyEventHandler] {
		param($s, $e)
		$mods = [System.Windows.Input.Keyboard]::Modifiers
		if ($e.Key -eq 'V' -and $mods -eq ([System.Windows.Input.ModifierKeys]::Control -bor [System.Windows.Input.ModifierKeys]::Shift)) {
			if ([System.Windows.Clipboard]::ContainsText()) { $s.Paste() }
			$e.Handled = $true
		}
	})
[System.Windows.EventManager]::RegisterClassHandler(
	[System.Windows.Controls.TextBox],
	[System.Windows.Controls.Control]::MouseDoubleClickEvent,
	[System.Windows.Input.MouseButtonEventHandler] {
		param($s, $e)
		$s.SelectAll()
	})

. (Join-Path $script:SrcDir 'theme.ps1')
. (Join-Path $script:SrcDir 'scripts1.ps1')
. (Join-Path $script:SrcDir 'scripts2.ps1')
. (Join-Path $script:SrcDir 'scripts3.ps1')

# ---- main window ---------------------------------------------------------------
$mainXaml = @"
<Window
	xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
	xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
	Title="Script-Package Studio $version" Width="560" Height="760" MinWidth="470" MinHeight="560"
	WindowStartupLocation="CenterScreen" Background="Transparent"
	WindowStyle="SingleBorderWindow"
	TextOptions.TextFormattingMode="Ideal" UseLayoutRounding="True">

	<WindowChrome.WindowChrome>
		<WindowChrome CaptionHeight="50" ResizeBorderThickness="6" CornerRadius="0"
					  GlassFrameThickness="1" UseAeroCaptionButtons="False"/>
	</WindowChrome.WindowChrome>

	<Border x:Name="RootBorder" Background="{DynamicResource BgBrush}">
		<Grid x:Name="Root">
			<Grid.RowDefinitions>
				<RowDefinition Height="50"/>
				<RowDefinition Height="*"/>
				<RowDefinition Height="Auto"/>
				<RowDefinition Height="36"/>
			</Grid.RowDefinitions>

			<!-- Title bar -->
			<Border Grid.Row="0" Background="{DynamicResource PanelBrush}"
					BorderBrush="{DynamicResource StrokeSoftBrush}" BorderThickness="0,0,0,1">
				<Grid>
					<StackPanel Orientation="Horizontal" Margin="16,0,0,0" VerticalAlignment="Center">
						<Image x:Name="TitleIcon" Width="28" Height="28" VerticalAlignment="Center"
							   RenderOptions.BitmapScalingMode="HighQuality"/>
						<TextBlock Text="Script-Package Studio" Margin="10,0,0,0" VerticalAlignment="Center"
								   FontFamily="{DynamicResource UiFont}" FontSize="13.5" FontWeight="SemiBold"
								   Foreground="{DynamicResource TextBrush}"/>
						<TextBlock Text="$version" Margin="8,1,0,0" VerticalAlignment="Center"
								   Style="{DynamicResource Small}"/>
					</StackPanel>
					<StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Top">
						<Button x:Name="ThemeBtn" Style="{DynamicResource IconBtn}" Margin="0,7,6,0"
								ToolTip="Toggle dark / light theme" WindowChrome.IsHitTestVisibleInChrome="True">
							<TextBlock x:Name="ThemeIcon" Text="&#xF597;" FontFamily="{DynamicResource IconFont}" FontSize="14"/>
						</Button>
						<Button x:Name="MinBtn" Style="{DynamicResource TitleBtn}" Content="&#xF1A3;" Height="36"
								WindowChrome.IsHitTestVisibleInChrome="True"/>
						<Button x:Name="MaxBtn" Style="{DynamicResource TitleBtn}" Content="&#xEC2A;" Height="36"
								WindowChrome.IsHitTestVisibleInChrome="True"/>
						<Button x:Name="CloseBtn" Style="{DynamicResource TitleBtnClose}" Content="&#xE6D3;" Height="36"
								WindowChrome.IsHitTestVisibleInChrome="True"/>
					</StackPanel>
				</Grid>
			</Border>

			<!-- Content -->
			<Grid Grid.Row="1" Margin="16">
				<Grid.RowDefinitions>
					<RowDefinition Height="Auto"/>
					<RowDefinition Height="*"/>
				</Grid.RowDefinitions>

				<!-- Tenant card: pick which Microsoft tenant the scripts run against -->
				<Border Style="{DynamicResource Card}" Padding="16,14">
					<Grid>
						<Grid.RowDefinitions>
							<RowDefinition Height="Auto"/>
							<RowDefinition Height="Auto"/>
						</Grid.RowDefinitions>
						<Grid.ColumnDefinitions>
							<ColumnDefinition Width="Auto"/>
							<ColumnDefinition Width="*"/>
							<ColumnDefinition Width="Auto"/>
							<ColumnDefinition Width="Auto"/>
							<ColumnDefinition Width="Auto"/>
						</Grid.ColumnDefinitions>
						<Ellipse x:Name="SignDot" Width="9" Height="9" Fill="{DynamicResource WarnBrush}"
								 VerticalAlignment="Center" Margin="0,0,11,0"/>
						<ComboBox x:Name="TenantCombo" Grid.Column="1" VerticalAlignment="Center" MinHeight="32"
								  ToolTip="Choose which Microsoft tenant to use. Selecting a tenant connects to it."/>
						<Button x:Name="BlurTenantBtn" Grid.Column="2" Style="{DynamicResource IconBtn}"
								Margin="6,0,0,0" ToolTip="Hide the tenant / account for screenshots">
							<TextBlock x:Name="BlurIcon" Text="&#xE883;" FontFamily="{DynamicResource IconFont}" FontSize="14"/>
						</Button>
						<Button x:Name="ForgetTenantBtn" Grid.Column="3" Style="{DynamicResource IconBtn}"
								Content="&#xE66D;" Margin="2,0,0,0"
								ToolTip="Forget the selected tenant (removes it from this list)"/>
						<Button x:Name="ConnectBtn" Grid.Column="4" Style="{DynamicResource BtnPrimary}"
								Content="Sign In" MinWidth="96" Margin="8,0,0,0"/>
						<TextBlock x:Name="SignStatusText" Grid.Row="1" Grid.Column="1" Grid.ColumnSpan="4"
								   Text="Currently not signed in." Style="{DynamicResource Small}" Margin="1,7,0,0"/>
					</Grid>
				</Border>

				<!-- Scripts card -->
				<Border Grid.Row="1" Style="{DynamicResource Card}" Margin="0,12,0,0" Padding="18,16">
					<Grid>
						<Grid.RowDefinitions>
							<RowDefinition Height="Auto"/>
							<RowDefinition Height="Auto"/>
							<RowDefinition Height="Auto"/>
							<RowDefinition Height="*"/>
							<RowDefinition Height="Auto"/>
						</Grid.RowDefinitions>
						<Grid Grid.Row="0">
							<StackPanel Orientation="Horizontal" VerticalAlignment="Center">
								<TextBlock Text="Scripts" Style="{DynamicResource H2}"/>
								<TextBlock x:Name="ScriptCountText" Style="{DynamicResource Small}"
										   Margin="10,4,0,0" VerticalAlignment="Center"/>
							</StackPanel>
						</Grid>
						<Grid Grid.Row="1" Margin="0,10,0,0">
							<TextBox x:Name="SearchBox" MinHeight="30" Padding="30,5,32,5"
									 ToolTip="Search scripts  (Ctrl+F)"/>
							<TextBlock Text="&#xEFD7;" FontFamily="{DynamicResource IconFont}" FontSize="13"
									   Foreground="{DynamicResource TextFaintBrush}" IsHitTestVisible="False"
									   Margin="10,0,0,0" VerticalAlignment="Center"/>
							<TextBlock x:Name="SearchHint" Text="Search scripts...   (Ctrl+F)" Style="{DynamicResource Small}"
									   Margin="32,0,0,0" VerticalAlignment="Center" IsHitTestVisible="False"/>
							<Button x:Name="SearchClearBtn" Style="{DynamicResource IconBtn}" Width="24" Height="24"
									HorizontalAlignment="Right" VerticalAlignment="Center" Margin="0,0,3,0"
									Visibility="Collapsed" ToolTip="Clear search">
								<TextBlock Text="&#xE6D3;" FontFamily="{DynamicResource IconFont}" FontSize="12"/>
							</Button>
						</Grid>
						<StackPanel x:Name="CatChipRow" Grid.Row="2" Orientation="Horizontal" Margin="0,10,0,0"/>
						<Grid Grid.Row="3">
							<ListBox x:Name="ScriptList" Margin="0,10,0,0" Background="Transparent"
									 BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Disabled"/>
							<StackPanel x:Name="EmptyState" VerticalAlignment="Center" HorizontalAlignment="Center"
										Visibility="Collapsed">
								<TextBlock Text="&#xEFD7;" FontFamily="{DynamicResource IconFont}" FontSize="22"
										   Foreground="{DynamicResource TextFaintBrush}" HorizontalAlignment="Center"/>
								<TextBlock Text="No scripts match your search." Style="{DynamicResource Dim}"
										   Margin="0,8,0,0" HorizontalAlignment="Center"/>
							</StackPanel>
						</Grid>
						<Grid Grid.Row="4" Margin="0,12,0,0">
							<TextBlock Text="Double-click a script, or press Enter, to run it."
									   Style="{DynamicResource Small}" VerticalAlignment="Center"/>
							<Button x:Name="RunBtn" Style="{DynamicResource BtnPrimary}" Content="Run"
									MinWidth="96" HorizontalAlignment="Right" IsDefault="True"/>
						</Grid>
					</Grid>
				</Border>
			</Grid>

			<!-- Activity log drawer: everything the scripts Write-Host lands here,
				 which used to be invisible (the launcher runs pwsh hidden) -->
			<Border Grid.Row="2" Background="{DynamicResource LogBgBrush}"
					BorderBrush="{DynamicResource StrokeSoftBrush}" BorderThickness="0,1,0,0">
				<Grid>
					<Grid.RowDefinitions>
						<RowDefinition Height="30"/>
						<RowDefinition Height="Auto"/>
					</Grid.RowDefinitions>
					<Grid Grid.Row="0" Margin="10,0,16,0">
						<StackPanel Orientation="Horizontal" VerticalAlignment="Center">
							<Button x:Name="LogToggleBtn" Style="{DynamicResource IconBtn}" Width="26" Height="22"
									ToolTip="Show / hide the activity log  (Ctrl+L)">
								<TextBlock x:Name="LogToggleIcon" Text="&#xE490;" FontFamily="{DynamicResource IconFont}" FontSize="10"/>
							</Button>
							<TextBlock Text="Activity" Style="{DynamicResource H3}" Margin="6,0,0,0" VerticalAlignment="Center"/>
							<TextBlock x:Name="LogCountText" Style="{DynamicResource Small}" Margin="10,1,0,0" VerticalAlignment="Center"/>
						</StackPanel>
						<StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Center">
							<Button x:Name="LogCopyBtn" Style="{DynamicResource BtnGhost}" Content="Copy" Padding="8,2"
									ToolTip="Copy the log to the clipboard"/>
							<Button x:Name="LogClearBtn" Style="{DynamicResource BtnGhost}" Content="Clear" Padding="8,2"/>
						</StackPanel>
					</Grid>
					<ListBox x:Name="LogList" Grid.Row="1" Height="150" Margin="4,0,4,4" Background="Transparent"
							 BorderThickness="0" Visibility="Collapsed"
							 ScrollViewer.HorizontalScrollBarVisibility="Disabled"
							 VirtualizingPanel.IsVirtualizing="True" VirtualizingPanel.VirtualizationMode="Recycling"/>
				</Grid>
			</Border>

			<!-- Status bar -->
			<Border Grid.Row="3" Background="{DynamicResource PanelBrush}"
					BorderBrush="{DynamicResource StrokeSoftBrush}" BorderThickness="0,1,0,0">
				<Grid Margin="14,0">
					<StackPanel Orientation="Horizontal" VerticalAlignment="Center">
						<Ellipse x:Name="StatusDot" Width="8" Height="8" Fill="{DynamicResource SuccessBrush}"
								 VerticalAlignment="Center"/>
						<TextBlock x:Name="StatusText" Text="Ready" Style="{DynamicResource Dim}"
								   Margin="8,0,0,0" VerticalAlignment="Center"/>
					</StackPanel>
					<ProgressBar x:Name="MainProgress" Width="180" Height="6" Maximum="100"
								 HorizontalAlignment="Right" VerticalAlignment="Center"/>
				</Grid>
			</Border>
		</Grid>
	</Border>
</Window>
"@

$script:Window = Read-XamlString $mainXaml
[void]$script:Window.Resources.MergedDictionaries.Add($script:StyleDict)

$script:UI = @{}
foreach ($n in @('RootBorder','Root','TitleIcon','ThemeBtn','ThemeIcon','MinBtn','MaxBtn','CloseBtn',
		'SignDot','SignStatusText','TenantCombo','BlurTenantBtn','BlurIcon','ForgetTenantBtn','ConnectBtn',
		'ScriptCountText','SearchBox','SearchHint','SearchClearBtn','CatChipRow','ScriptList','EmptyState','RunBtn',
		'LogToggleBtn','LogToggleIcon','LogCountText','LogCopyBtn','LogClearBtn','LogList',
		'StatusDot','StatusText','MainProgress')) {
	$el = $script:Window.FindName($n)
	if (-not $el) { throw "XAML element '$n' not found" }
	$script:UI[$n] = $el
}

# load the largest frame from the multi-size .ico so the taskbar / Alt-Tab icon
# is crisp (BitmapImage alone would grab the 16px frame and upscale it)
try {
	$icoDec = [System.Windows.Media.Imaging.BitmapDecoder]::Create(
		[Uri](Join-Path $PSScriptRoot 'Images\logo.ico'),
		[System.Windows.Media.Imaging.BitmapCreateOptions]::None,
		[System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad)
	$script:Window.Icon = ($icoDec.Frames | Sort-Object PixelWidth -Descending | Select-Object -First 1)
} catch {}

# same logo in the in-app title bar (top-left)
try {
	$script:UI.TitleIcon.Source = New-ImageSource (Join-Path $PSScriptRoot 'Images\logo.png')
} catch {}

# Global safety net: if any action throws an unhandled error mid-way (e.g. a
# cmdlet fails), show it instead of the action silently stopping with no
# feedback. Skipped in screenshot mode so automated runs never block on a modal.
if (-not $env:SP_SHOT) {
	$script:Window.Dispatcher.Add_UnhandledException({ param($s, $e)
		try {
			Write-Host "Error: $($e.Exception.Message)" -ForegroundColor Red
			[void](New-ErrorDialog (($e.Exception | Out-String).Trim())).ShowDialog()
		} catch {}
		$e.Handled = $true
	})
}

# $progressBar1 keeps the WinForms-era contract every script uses
# ($progressBar1.Value = n) and pumps the dispatcher so updates paint during
# synchronous work, like the old WinForms progress bar did.
$progressBar1 = [pscustomobject]@{}
$progressBar1 | Add-Member -MemberType ScriptProperty -Name Value `
	-Value { $script:UI.MainProgress.Value } `
	-SecondValue {
		param($v)
		$script:UI.MainProgress.Value = [double]$v
		try { $script:UI.MainProgress.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render) } catch {}
	}

# ---- tenant profiles ------------------------------------------------------------
# Saved tenants live in tenants.json next to the app (portable, like settings.ini).
# Only names/accounts/tenant ids are stored - the actual credentials stay in the
# Graph and Exchange Online token caches, which persist on this machine, so
# switching to a known tenant normally reconnects without any prompt.
$script:TenantsPath = Join-Path $PSScriptRoot 'tenants.json'
$script:Tenants = [System.Collections.Generic.List[object]]::new()
$script:ActiveTenant = $null
$script:SuppressTenantEvents = $false
$script:GraphScopes = @("User.ReadWrite.All", "Directory.ReadWrite.All", "User.Invite.All", "Group.ReadWrite.All", "UserAuthenticationMethod.ReadWrite.All")

function Load-Tenants {
	$script:Tenants.Clear()
	if (Test-Path -LiteralPath $script:TenantsPath) {
		try {
			foreach ($t in @(Get-Content -LiteralPath $script:TenantsPath -Raw | ConvertFrom-Json)) {
				if ($t.account -and $t.tenantId) { $script:Tenants.Add($t) }
			}
		} catch {}
	}
}

function Save-Tenants {
	try {
		ConvertTo-Json @($script:Tenants) -Depth 3 | Set-Content -LiteralPath $script:TenantsPath -Encoding UTF8
	} catch {}
}

function Get-MissingModules {
	$missing = @()
	if (-not (Get-Command Connect-MgGraph -ErrorAction Ignore)) { $missing += 'Microsoft.Graph' }
	if (-not (Get-Command Connect-ExchangeOnline -ErrorAction Ignore)) { $missing += 'ExchangeOnlineManagement' }
	return $missing
}

# Ensures the Microsoft modules are available before a sign-in attempt; offers
# to run Install-RequiredModules if they are not. Returns $true when ready.
function Confirm-RequiredModules {
	$missing = @(Get-MissingModules)
	if ($missing.Count -eq 0) { return $true }
	Write-Host "Missing PowerShell modules: $($missing -join ', ')" -ForegroundColor Yellow
	$choice = @{ Install = $false }
	$dlg = New-ModulesMissingDialog ($missing -join "`n")
	$dlg.FindName('InstallBtn').Add_Click({ $choice.Install = $true; $dlg.Close() })
	$dlg.FindName('NotNowBtn').Add_Click({ $dlg.Close() })
	[void]$dlg.ShowDialog()
	if (-not $choice.Install) { return $false }
	$script:UI.StatusText.Text = 'Installing modules... this can take several minutes.'
	Install-RequiredModules
	$script:UI.StatusText.Text = 'Ready'
	$missing = @(Get-MissingModules)
	if ($missing.Count -gt 0) {
		Write-Host "Modules still missing after install: $($missing -join ', ')" -ForegroundColor Red
		return $false
	}
	Write-Host "Modules installed." -ForegroundColor Green
	return $true
}

# On launch, if the required modules aren't installed yet, offer to install them.
# (PowerShell 7 itself is handled earlier by the launcher, so the user is prompted
# for PowerShell 7 first, then the modules here.)
function Confirm-ModulesAtStartup {
	$missing = @(Get-MissingModules)
	if ($missing.Count -eq 0) { return }
	Write-Host "Required modules not installed: $($missing -join ', ')" -ForegroundColor Yellow
	$choice = @{ Install = $false }
	$dlg = New-ModulesMissingDialog ($missing -join "`n") 'Script-Package Studio needs these PowerShell modules, which are not installed yet:'
	try { $dlg.Owner = $script:Window } catch {}
	$dlg.FindName('InstallBtn').Add_Click({ $choice.Install = $true; $dlg.Close() })
	$dlg.FindName('NotNowBtn').Add_Click({ $dlg.Close() })
	[void]$dlg.ShowDialog()
	if ($choice.Install) {
		$script:UI.StatusText.Text = 'Installing modules... this can take several minutes.'
		$script:Window.Dispatcher.Invoke([action] {}, [System.Windows.Threading.DispatcherPriority]::Render)
		Install-RequiredModules
		$script:UI.StatusText.Text = 'Ready'
	}
}

function Set-SignState([bool]$Connected, [string]$Text) {
	$brush = if ($Connected) { 'SuccessBrush' } else { 'WarnBrush' }
	$script:UI.SignDot.SetResourceReference([System.Windows.Shapes.Ellipse]::FillProperty, $brush)
	$script:UI.SignStatusText.Text = $Text
}

# Show an in-progress state on the Connect/Disconnect button while a sign-in runs, so
# it's clear the tenant isn't connected yet. Rendered before the (UI-thread-blocking)
# connect so the user actually sees it; Update-TenantCombo resets it (to 'Connected' /
# 'Connect') and re-enables the button when the sign-in finishes.
function Set-ConnectingButton {
	$script:UI.ConnectBtn.Content = 'Connecting...'
	$script:UI.ConnectBtn.IsEnabled = $false
	$script:UI.ConnectBtn.ToolTip = $null
	$script:Window.Dispatcher.Invoke([action] {}, [System.Windows.Threading.DispatcherPriority]::Render)
}

function Update-TenantCombo {
	$script:SuppressTenantEvents = $true
	try {
		$combo = $script:UI.TenantCombo
		$combo.Items.Clear()
		foreach ($t in $script:Tenants) {
			$item = [System.Windows.Controls.ComboBoxItem]::new()
			$item.Content = "$($t.name)  -  $($t.account)"
			$item.Tag = $t
			[void]$combo.Items.Add($item)
		}
		$addItem = [System.Windows.Controls.ComboBoxItem]::new()
		$addItem.Content = '+  Add a tenant...'
		$addItem.Tag = 'add'
		$addItem.FontStyle = 'Italic'
		[void]$combo.Items.Add($addItem)

		# preselect the active tenant, else the most recently used one
		$target = $script:ActiveTenant
		if (-not $target -and $script:Tenants.Count -gt 0) {
			$target = $script:Tenants | Sort-Object { [string]$_.lastUsed } -Descending | Select-Object -First 1
		}
		$combo.SelectedIndex = if ($target) { $script:Tenants.IndexOf($target) } else { -1 }

		$script:UI.ForgetTenantBtn.IsEnabled = $script:Tenants.Count -gt 0
		$script:UI.ConnectBtn.IsEnabled = $true
		if ($script:ActiveTenant) {
			$script:UI.ConnectBtn.Content = 'Connected'
			$script:UI.ConnectBtn.ToolTip = 'Connected - click to disconnect'
		} elseif ($script:Tenants.Count -gt 0) {
			$script:UI.ConnectBtn.Content = 'Connect'
			$script:UI.ConnectBtn.ToolTip = $null
		} else {
			$script:UI.ConnectBtn.Content = 'Sign In'
			$script:UI.ConnectBtn.ToolTip = $null
		}
	} finally {
		$script:SuppressTenantEvents = $false
	}
}

function Get-SelectedTenant {
	$item = $script:UI.TenantCombo.SelectedItem
	if ($item -and $item.Tag -ne 'add') { return $item.Tag }
	return $null
}

# fix A for the "second interactive sign-in freezes" deadlock. Connect-MgGraph and
# Connect-ExchangeOnline block the UI thread while doing async MSAL token work. WPF
# installs a DispatcherSynchronizationContext on the UI thread, so those awaited
# continuations try to resume ON the (blocked) UI thread -> deadlock, which froze
# the 2nd sign-in in a session. Running the cmdlet with the context temporarily
# cleared lets the continuations resume on the thread pool instead, so the cmdlet
# can return. Restored in finally so the rest of the app keeps its dispatcher context.
function Invoke-WithoutDispatcherContext([scriptblock]$Script) {
	$old = [System.Threading.SynchronizationContext]::Current
	[System.Threading.SynchronizationContext]::SetSynchronizationContext($null)
	try { & $Script } finally { [System.Threading.SynchronizationContext]::SetSynchronizationContext($old) }
}

# Connect to Exchange Online. -SkipLoadingCmdletHelp only exists in newer
# ExchangeOnlineManagement versions, so pass it only when the installed module
# supports it (older versions on other machines threw a parameter error).
function Connect-Exo([string]$Upn) {
	$p = @{ ShowBanner = $false }
	if ($Upn) { $p.UserPrincipalName = $Upn }
	$cmd = Get-Command Connect-ExchangeOnline -ErrorAction SilentlyContinue
	if ($cmd -and $cmd.Parameters.ContainsKey('SkipLoadingCmdletHelp')) { $p.SkipLoadingCmdletHelp = $true }
	# THE tenant-switch freeze fix. Since ExchangeOnlineManagement v3.7.0, Web Account
	# Manager (WAM) is the default auth broker. WAM shows an IN-PROCESS dialog that
	# needs this thread's message pump - but Connect-ExchangeOnline runs synchronously
	# on the (now-blocked) WPF UI thread, so on a switch that needs interactive auth
	# the dialog can never pump and the app deadlocks forever (progress stuck ~50%).
	# -DisableWAM forces the out-of-process browser flow (same as Connect-MgGraph),
	# which completes without the pump. Pass it on EVERY connect (WAM can't be
	# disabled once initialized in the process). Only exists in v3.7.0+.
	if ($cmd -and $cmd.Parameters.ContainsKey('DisableWAM')) { $p.DisableWAM = $true }
	# Clear the WPF dispatcher sync context INLINE (fix A for the sign-in deadlock) - do
	# NOT route this through Invoke-WithoutDispatcherContext {...}.GetNewClosure(). A
	# closure runs in a throwaway dynamic MODULE scope, and Connect-ExchangeOnline IMPORTS
	# its cmdlets (Get-Mailbox, Get-MailboxAutoReplyConfiguration, Set-Mailbox, ...) into
	# the CALLING scope - so wrapped, every Exchange cmdlet vanished after connect
	# ("not recognized as a cmdlet"). Calling it directly here keeps the import in the
	# app's runspace scope so the scripts can use those cmdlets.
	$oldCtx = [System.Threading.SynchronizationContext]::Current
	[System.Threading.SynchronizationContext]::SetSynchronizationContext($null)
	try { Connect-ExchangeOnline @p }
	finally { [System.Threading.SynchronizationContext]::SetSynchronizationContext($oldCtx) }
}

# Connect Graph + Exchange Online to a saved tenant. With cached tokens this is
# silent; otherwise Microsoft's normal auth prompt appears (usually one click
# thanks to browser SSO).
function Connect-Tenant($Tenant) {
	if (-not $Tenant) { return }
	if (-not (Confirm-RequiredModules)) { Update-TenantCombo; return }
	$script:UI.StatusText.Text = "Connecting to $($Tenant.name)..."
	Set-SignState $false "Connecting to $($Tenant.name) as $($Tenant.account)..."
	$script:UI.SignDot.SetResourceReference([System.Windows.Shapes.Ellipse]::FillProperty, 'AccentBrush')
	Write-Host "Connecting to tenant $($Tenant.name) ($($Tenant.tenantId)) as $($Tenant.account)..."
	$progressBar1.Value = 10
	Set-ConnectingButton

	# Silent switch: keep the previous session's cached tokens (do NOT Disconnect-MgGraph
	# first) and reconnect with -TenantId. With a cached token this is silent and instant
	# - no browser, no account picker. If the token isn't cached (new account, or the
	# cache was cleared/expired), Microsoft's normal browser sign-in appears - which no
	# longer freezes thanks to Invoke-WithoutDispatcherContext (the sync-context fix).
	Invoke-WithoutDispatcherContext { Connect-MgGraph -TenantId $Tenant.tenantId -Scopes $script:GraphScopes }
	$progressBar1.Value = 40
	CheckForErrors
	$currentMgContext = Get-MgContext
	if (-not $currentMgContext -or [string]$currentMgContext.TenantId -ne [string]$Tenant.tenantId) {
		Write-Host "Could not connect to $($Tenant.name)." -ForegroundColor Red
		$script:ActiveTenant = $null
		Set-SignState $false 'Currently not signed in.'
		Update-TenantCombo
		$script:UI.StatusText.Text = 'Ready'
		$progressBar1.Value = 0
		return
	}
	Write-Host "Connected to Graph"
	if ([string]$currentMgContext.Account -and [string]$currentMgContext.Account -ne [string]$Tenant.account) {
		Write-Host "Note: Graph connected as $($currentMgContext.Account) (this tenant was saved for $($Tenant.account))." -ForegroundColor Yellow
	}

	# Connect-Exo passes -DisableWAM so this uses the out-of-process browser instead
	# of the in-process WAM dialog that used to deadlock the UI thread on a switch.
	$script:UI.StatusText.Text = 'Finishing sign-in (Exchange Online)...'
	try { Disconnect-ExchangeOnline -Confirm:$false -ErrorAction Ignore } catch {}
	Connect-Exo $Tenant.account
	$progressBar1.Value = 80
	CheckForErrors
	Write-Host "Connected to Exchange"

	$script:ActiveTenant = $Tenant
	$Tenant.lastUsed = (Get-Date).ToString('o')
	Save-Tenants
	Update-TenantCombo
	Set-SignState $true "Connected to $($Tenant.name) as $($currentMgContext.Account)"
	$script:UI.StatusText.Text = 'Ready'
	$progressBar1.Value = 0
}

# Interactive sign-in to a new account/tenant; saves it as a profile
function Add-TenantSignIn {
	if (-not (Confirm-RequiredModules)) { return }
	Write-Host "Signing in to a new tenant..."
	$script:UI.SignDot.SetResourceReference([System.Windows.Shapes.Ellipse]::FillProperty, 'AccentBrush')
	Set-SignState $false 'Waiting for Microsoft sign-in...'
	$progressBar1.Value = 10
	Set-ConnectingButton

	# drop the current Graph context so the account picker appears instead of a
	# silent reconnect to the previous account
	try { Disconnect-MgGraph -ErrorAction Ignore | Out-Null } catch {}
	$Error.Clear()

	Invoke-WithoutDispatcherContext { Connect-MgGraph -Scopes $script:GraphScopes }
	$progressBar1.Value = 40
	CheckForErrors
	$currentMgContext = Get-MgContext
	if (-not $currentMgContext) {
		$script:ActiveTenant = $null
		Set-SignState $false 'Currently not signed in.'
		Update-TenantCombo
		$progressBar1.Value = 0
		return
	}
	Write-Host "Connected to Graph"

	$orgName = $null
	try { $orgName = [string](Get-MgOrganization -ErrorAction Ignore | Select-Object -First 1).DisplayName } catch {}
	if (-not $orgName) { $orgName = ([string]$currentMgContext.Account -split '@')[-1] }
	$Error.Clear()

	Set-SignState $false 'Finishing sign-in (Exchange Online)...'
	$script:Window.Dispatcher.Invoke([action] {}, [System.Windows.Threading.DispatcherPriority]::Render)

	# Drop any existing Exchange session first. Without this, adding a second
	# tenant while one is already connected hangs Connect-ExchangeOnline (the old
	# session is still active) and freezes the app before the tenant is saved.
	try { Disconnect-ExchangeOnline -Confirm:$false -ErrorAction Ignore } catch {}
	Connect-Exo $currentMgContext.Account
	$progressBar1.Value = 80
	CheckForErrors
	Write-Host "Connected to Exchange"

	$tenantProfile = $script:Tenants | Where-Object {
		[string]$_.tenantId -eq [string]$currentMgContext.TenantId -and [string]$_.account -eq [string]$currentMgContext.Account
	} | Select-Object -First 1
	if ($tenantProfile) {
		$tenantProfile.name = $orgName
	} else {
		$tenantProfile = [pscustomobject]@{
			name     = $orgName
			account  = [string]$currentMgContext.Account
			tenantId = [string]$currentMgContext.TenantId
			lastUsed = ''
		}
		$script:Tenants.Add($tenantProfile)
	}
	$tenantProfile.lastUsed = (Get-Date).ToString('o')
	$script:ActiveTenant = $tenantProfile
	Save-Tenants
	Update-TenantCombo
	Set-SignState $true "Connected to $orgName as $($currentMgContext.Account)"
	Write-Host "Saved tenant '$orgName' ($($currentMgContext.Account))." -ForegroundColor Green
	$progressBar1.Value = 0
}

function Disconnect-Tenant {
	Write-Host "Disconnecting..."
	$progressBar1.Value = 10
	try { Disconnect-ExchangeOnline -Confirm:$false -ErrorAction Ignore } catch {}
	$progressBar1.Value = 50
	try { Disconnect-MgGraph -ErrorAction Ignore | Out-Null } catch {}
	$Error.Clear()
	Write-Host "Disconnected from Graph and Exchange"
	$script:ActiveTenant = $null
	Set-SignState $false 'Currently not signed in.'
	Update-TenantCombo
	$progressBar1.Value = 0
}

# ---- activity log --------------------------------------------------------------
# The launcher runs pwsh hidden, so console output was never visible. Shadowing
# Write-Host mirrors every message the scripts print into the log drawer (and
# still writes to the console for anyone running from a terminal).
$script:UI.LogList.ItemContainerStyle = $script:StyleDict['LogItemStyle']

# Matches email addresses so the tenant/account email in a log line can be blurred
# on its own (keeping "Connected to <tenant>..." readable) when the blur toggle is on.
$script:LogEmailRegex = [regex]'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}'
function New-LogEmailBlur { $fx = New-Object System.Windows.Media.Effects.BlurEffect; $fx.Radius = 5; $fx }

# Render a log line as inlines: plain Runs for the text, and each email in its own
# TextBlock (via InlineUIContainer) so the email alone can carry a BlurEffect. The full
# raw text is stashed in .Tag because InlineUIContainer content is NOT part of .Text
# (Copy reads .Tag so the copied log keeps the real addresses).
function Set-LogItemInlines([System.Windows.Controls.TextBlock]$Tb, [string]$FullText, [string]$BrushKey) {
	$Tb.Inlines.Clear()
	$Tb.Tag = $FullText
	$idx = 0
	foreach ($m in $script:LogEmailRegex.Matches($FullText)) {
		if ($m.Index -gt $idx) { $Tb.Inlines.Add((New-Object System.Windows.Documents.Run ($FullText.Substring($idx, $m.Index - $idx)))) }
		$eb = [System.Windows.Controls.TextBlock]::new()
		$eb.Text = $m.Value
		$eb.FontFamily = $Tb.FontFamily
		$eb.FontSize = $Tb.FontSize
		$eb.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, $BrushKey)
		if ($script:Settings.blurTenant) { $eb.Effect = New-LogEmailBlur }
		$uic = New-Object System.Windows.Documents.InlineUIContainer $eb
		$uic.BaselineAlignment = [System.Windows.BaselineAlignment]::TextBottom
		$Tb.Inlines.Add($uic)
		$idx = $m.Index + $m.Length
	}
	if ($idx -lt $FullText.Length) { $Tb.Inlines.Add((New-Object System.Windows.Documents.Run ($FullText.Substring($idx)))) }
}

function Add-UiLog([string]$Text, [string]$Color = '') {
	if (-not $script:UI -or -not $script:UI.LogList) { return }
	if (-not $Text.Trim()) { return }
	$brushKey = switch ($Color) {
		'Red'      { 'ErrorBrush' }
		'Yellow'   { 'WarnBrush' }
		'Green'    { 'SuccessBrush' }
		'Cyan'     { 'InfoBrush' }
		default    { 'TextDimBrush' }
	}
	$tb = [System.Windows.Controls.TextBlock]::new()
	$tb.FontFamily = $script:StyleDict['UiFont']
	$tb.FontSize = 12
	$tb.TextWrapping = 'Wrap'
	$tb.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, $brushKey)
	Set-LogItemInlines $tb ("[{0:h:mm:ss tt}]  {1}" -f (Get-Date), $Text) $brushKey
	$list = $script:UI.LogList
	[void]$list.Items.Add($tb)
	while ($list.Items.Count -gt 500) { $list.Items.RemoveAt(0) }
	$script:UI.LogCountText.Text = "$($list.Items.Count) entries"
	if ($list.IsVisible) { $list.ScrollIntoView($list.Items[$list.Items.Count - 1]) }
}

function Write-Host {
	[CmdletBinding()]
	param(
		[Parameter(Position = 0, ValueFromRemainingArguments = $true)]
		[Alias('Msg', 'Message')]
		[object]$Object,
		[switch]$NoNewline,
		[object]$Separator = ' ',
		[System.ConsoleColor]$ForegroundColor,
		[System.ConsoleColor]$BackgroundColor
	)
	$fwd = @{ Object = $Object; NoNewline = $NoNewline; Separator = $Separator }
	if ($PSBoundParameters.ContainsKey('ForegroundColor')) { $fwd.ForegroundColor = $ForegroundColor }
	if ($PSBoundParameters.ContainsKey('BackgroundColor')) { $fwd.BackgroundColor = $BackgroundColor }
	Microsoft.PowerShell.Utility\Write-Host @fwd
	$color = if ($PSBoundParameters.ContainsKey('ForegroundColor')) { [string]$ForegroundColor } else { '' }
	try { Add-UiLog ([string]"$Object") $color } catch {}
}

function Set-LogExpanded([bool]$Expanded) {
	$script:Settings.logExpanded = $Expanded
	$script:UI.LogList.Visibility = if ($Expanded) { 'Visible' } else { 'Collapsed' }
	$script:UI.LogToggleIcon.Text = if ($Expanded) { [string][char]0xE488 } else { [string][char]0xE490 }
	if ($Expanded -and $script:UI.LogList.Items.Count -gt 0) {
		$script:UI.LogList.ScrollIntoView($script:UI.LogList.Items[$script:UI.LogList.Items.Count - 1])
	}
}

# ---- script catalog ----------------------------------------------------------
$script:ScriptCatalog = @(
	@{ Name = 'Add-AuthenticationPhoneMethod'; Desc = 'Add a 2FA phone number to an account, single or bulk.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xEE2F }
	@{ Name = 'Add-AutoReply'; Desc = 'Set an automatic reply on a mailbox, optionally scheduled.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xEBBC }
	@{ Name = 'Add-Contacts'; Desc = 'Add mail contacts to Microsoft 365, single or bulk.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xE249 }
	@{ Name = 'Add-DistributionListMember'; Desc = 'Add members to a distribution list.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xED75 }
	@{ Name = 'Add-EmailAlias'; Desc = 'Add aliases to a mailbox and view existing ones.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xEBBC }
	@{ Name = 'Add-MailboxMember'; Desc = 'Grant FullAccess / SendAs / SendOnBehalf on a mailbox.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xED93 }
	@{ Name = 'Add-TrustedSender'; Desc = 'Add a trusted sender or domain to every mailbox in the tenant.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xF039 }
	@{ Name = 'Add-UnifiedGroupMember'; Display = 'Add-TeamsGroupMember (UnifiedGroupMember)'; Desc = 'Add members to a Teams / Microsoft 365 group.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xED75 }
	@{ Name = 'Block-User'; Desc = 'Disable a user in AD and Microsoft 365, convert their mailbox to shared.'; SignIn = $true; Cat = 'Active Directory'; Icon = 0xEEE3 }
	@{ Name = 'Clear-RecycleBin'; Desc = 'Empty all recycle bins on this computer.'; SignIn = $false; Cat = 'System'; Icon = 0xE66D }
	@{ Name = 'Convert-UnifiedGroupToDistributionGroup'; Desc = 'Rebuild a Microsoft 365 group as a distribution list.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xE16F }
	@{ Name = 'Terminate-Disable-ADAndEmailAccounts'; Desc = 'Terminate a user: disable AD, convert mailbox to shared, strip licenses/2FA, optional add-members + auto-reply.'; SignIn = $true; Cat = 'Active Directory'; Icon = 0xEEE3 }
	@{ Name = 'Enable-Archive'; Desc = 'Enable, jumpstart or auto-expand mailbox archiving.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xE085 }
	@{ Name = 'Install-RequiredModules'; Desc = 'Install the Microsoft.Graph and ExchangeOnlineManagement modules.'; SignIn = $false; Cat = 'App'; Icon = 0xE0DD }
	@{ Name = 'New-ADAccounts'; Desc = 'Create Active Directory accounts in bulk from a CSV.'; SignIn = $false; Cat = 'Active Directory'; Icon = 0xEDBB }
	@{ Name = 'New-ADAndEmailAccounts'; Desc = 'Create AD accounts plus licensed mailboxes in bulk.'; SignIn = $true; Cat = 'Active Directory'; Icon = 0xEDBB }
	@{ Name = 'New-EmailAccounts'; Desc = 'Create licensed Microsoft 365 accounts in bulk.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xEBBC }
	@{ Name = 'Remove-DistributionListMember'; Desc = 'Remove members from a distribution list.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xED75 }
	@{ Name = 'Remove-EmailAlias'; Desc = 'Remove aliases from a mailbox.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xEBBC }
	@{ Name = 'Remove-MailboxMember'; Desc = 'Revoke FullAccess / SendAs / SendOnBehalf on a mailbox.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xED93 }
	@{ Name = 'Remove-UnifiedGroupMember'; Desc = 'Remove members from a Microsoft 365 group.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xED75 }
	@{ Name = 'Remove-UserFromAllGroups'; Desc = 'Remove a user from all (or selected) tenant groups - DLs, Teams/M365, security. Offboarding.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xED75 }
	@{ Name = 'Reset-MFA'; Desc = 'Clear a user''s MFA methods so they re-register, single or bulk.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xE72E }
	@{ Name = 'Set-License'; Desc = 'Assign, remove or swap Microsoft 365 licenses, single or bulk.'; SignIn = $true; Cat = 'Microsoft 365'; Icon = 0xE8FC }
	@{ Name = 'Update-ScriptPackage'; Desc = 'Download and install the latest release.'; SignIn = $false; Cat = 'App'; Icon = 0xE0BF }
	@{ Name = 'Set-ACLPermissions'; Desc = 'Add NTFS ACL permission rules to files and folders.'; SignIn = $false; Cat = 'System'; Icon = 0xEAA7 }
	@{ Name = 'Set-NTP'; Desc = 'Check or set the Windows time source.'; SignIn = $false; Cat = 'System'; Icon = 0xE508 }
	@{ Name = 'Show-Information'; Desc = 'Script-Package Studio info and links.'; SignIn = $false; Cat = 'App'; Icon = 0xEA88 }
)

$script:Categories = @('All', 'Microsoft 365', 'Active Directory', 'System', 'App')
$script:CurrentCategory = 'All'

function New-ScriptListItem($Meta) {
	$item = [System.Windows.Controls.ListBoxItem]::new()
	$item.Style = $script:StyleDict['PaletteItemStyle']
	$item.Tag = $Meta.Name

	$grid = [System.Windows.Controls.Grid]::new()
	foreach ($w in @('Auto', '*')) {
		$c = [System.Windows.Controls.ColumnDefinition]::new()
		$c.Width = if ($w -eq '*') { [System.Windows.GridLength]::new(1, 'Star') } else { [System.Windows.GridLength]::Auto }
		[void]$grid.ColumnDefinitions.Add($c)
	}

	$tile = [System.Windows.Controls.Border]::new()
	$tile.Width = 30; $tile.Height = 30
	$tile.CornerRadius = '8'
	$tile.VerticalAlignment = 'Center'
	$tile.Margin = '0,0,11,0'
	$tile.SetResourceReference([System.Windows.Controls.Border]::BackgroundProperty, 'AccentSoftBrush')
	$glyph = [System.Windows.Controls.TextBlock]::new()
	$glyph.Text = [string][char][int]$Meta.Icon
	$glyph.FontFamily = $script:StyleDict['IconFont']
	$glyph.FontSize = 14
	$glyph.HorizontalAlignment = 'Center'
	$glyph.VerticalAlignment = 'Center'
	$glyph.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, 'AccentBrush')
	$tile.Child = $glyph
	[void]$grid.Children.Add($tile)

	$sp = [System.Windows.Controls.StackPanel]::new()
	$sp.VerticalAlignment = 'Center'
	$name = [System.Windows.Controls.TextBlock]::new()
	$name.Text = if ($Meta.Display) { $Meta.Display } else { $Meta.Name }
	$name.FontFamily = $script:StyleDict['UiFont']
	$name.FontSize = 13
	$name.FontWeight = 'SemiBold'
	$name.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, 'TextBrush')
	$desc = [System.Windows.Controls.TextBlock]::new()
	$desc.Text = $Meta.Desc
	$desc.Style = $script:StyleDict['Small']
	$desc.Margin = '0,2,0,0'
	$desc.TextTrimming = 'CharacterEllipsis'
	$desc.TextWrapping = 'NoWrap'
	[void]$sp.Children.Add($name)
	[void]$sp.Children.Add($desc)
	[System.Windows.Controls.Grid]::SetColumn($sp, 1)
	[void]$grid.Children.Add($sp)

	if ($Meta.SignIn) {
		$item.ToolTip = 'Requires signing in to Microsoft Graph / Exchange Online first'
	}

	$item.Content = $grid
	$item.Add_MouseDoubleClick({ param($s, $e) Invoke-ScriptByName ([string]$s.Tag) })
	return $item
}

function Update-ScriptList {
	$filter = $script:UI.SearchBox.Text.Trim()
	$list = $script:UI.ScriptList
	$list.Items.Clear()
	foreach ($s in $script:ScriptCatalog) {
		if ($script:CurrentCategory -ne 'All' -and $s.Cat -ne $script:CurrentCategory) { continue }
		if ($filter) {
			$hay = "$($s.Name) $($s.Desc) $($s.Display)"
			if ($hay.IndexOf($filter, [System.StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
		}
		[void]$list.Items.Add((New-ScriptListItem $s))
	}
	$script:UI.ScriptCountText.Text = "$($list.Items.Count) of $($script:ScriptCatalog.Count)"
	$script:UI.EmptyState.Visibility = if ($list.Items.Count -eq 0) { 'Visible' } else { 'Collapsed' }
	if (($filter -or $script:CurrentCategory -ne 'All') -and $list.Items.Count -gt 0) { $list.SelectedIndex = 0 }
}

# category filter chips
foreach ($cat in $script:Categories) {
	$chip = [System.Windows.Controls.RadioButton]::new()
	$chip.Style = $script:StyleDict['Chip']
	$chip.GroupName = 'Category'
	$chip.Content = $cat
	$chip.Tag = $cat
	$chip.FontSize = 12
	$chip.Margin = '0,0,7,0'
	if ($cat -eq 'All') { $chip.IsChecked = $true }
	$chip.Add_Checked({ param($s, $e)
		$script:CurrentCategory = [string]$s.Tag
		Update-ScriptList
	})
	[void]$script:UI.CatChipRow.Children.Add($chip)
}

# ---- run / sign-in wiring (logic unchanged) -----------------------------------
function OnRunButtonClick {
	param([string]$selectedScript)

	# Perform actions based on the selected script
	switch ($selectedScript) {
		"Add-AuthenticationPhoneMethod" { Add-AuthenticationPhoneMethod }
		"Add-AutoReply" { Add-AutoReply }
		"Add-Contacts" { Add-Contacts }
		"Add-DistributionListMember" { Add-DistributionListMember }
		"Add-EmailAlias" { Add-EmailAlias }
		"Add-MailboxMember" { Add-MailboxMember }
		"Add-TrustedSender" { Add-TrustedSender }
		"Add-UnifiedGroupMember" { Add-UnifiedGroupMember }
		"Block-User" { Block-User }
		"Clear-RecycleBin" { Clear-RecycleBin }
		"Convert-UnifiedGroupToDistributionGroup" { Convert-UnifiedGroupToDistributionGroup }
		"Terminate-Disable-ADAndEmailAccounts" { Terminate-Disable-ADAndEmailAccounts }
		"Enable-Archive" { Enable-Archive }
		"Install-RequiredModules" { Install-RequiredModules }
		"New-ADAccounts" { New-ADAccounts }
		"New-ADAndEmailAccounts" { New-ADAndEmailAccounts }
		"New-EmailAccounts" { New-EmailAccounts }
		"Remove-DistributionListMember" { Remove-DistributionListMember }
		"Remove-EmailAlias" { Remove-EmailAlias }
		"Remove-MailboxMember" { Add-MailboxMember }
		"Remove-UnifiedGroupMember" { Remove-UnifiedGroupMember }
		"Remove-UserFromAllGroups" { Remove-UserFromAllGroups }
		"Reset-MFA" { Reset-MFA }
		"Set-License" { Set-License }
		"Update-ScriptPackage" { Update-ScriptPackage }
		"Set-ACLPermissions" { Set-ACLPermissions }
		"Set-NTP" { Set-NTP }
		"Show-Information" { Show-Information }
		"Debug" { Start-Process pwsh .\MainGUI.ps1 }
		"Reload-Settings" { LoadSettings }
		default { Write-Host "No script selected." }
	}
}

function Invoke-ScriptByName([string]$Name) {
	if (-not $Name) { Write-Host "No script selected."; return }
	$script:UI.StatusText.Text = "Running $Name..."
	$script:UI.StatusDot.SetResourceReference([System.Windows.Shapes.Ellipse]::FillProperty, 'AccentBrush')
	$known = $script:ScriptCatalog | Where-Object { $_.Name -eq $Name }
	try {
		OnRunButtonClick $Name
	} finally {
		$script:UI.StatusText.Text = if ($known) { "$Name finished at $(Get-Date -Format 'h:mm tt')" } else { 'Ready' }
		$script:UI.StatusDot.SetResourceReference([System.Windows.Shapes.Ellipse]::FillProperty, 'SuccessBrush')
	}
}

function Invoke-RunSelected {
	$name = $null
	if ($script:UI.ScriptList.SelectedItem) { $name = [string]$script:UI.ScriptList.SelectedItem.Tag }
	elseif ($script:UI.SearchBox.Text.Trim()) { $name = $script:UI.SearchBox.Text.Trim() }
	Invoke-ScriptByName $name
}

$script:UI.RunBtn.Add_Click({ Invoke-RunSelected })

# ---- tenant card wiring -----------------------------------------------------------
# Run a (UI-thread-blocking) sign-in only AFTER the just-closed tenant dropdown popup
# is fully gone. The popup is a separate always-on-top window; if the blocking sign-in
# starts before it's destroyed, it freezes open on top of the auth browser. A short
# timer lets the (now un-animated) popup close render first. Under SP_TEST there's no
# real browser, so run synchronously to keep the self-test deterministic.
function Start-DeferredSignIn([scriptblock]$Action) {
	if ($env:SP_TEST) { & $Action; return }
	$timer = New-Object System.Windows.Threading.DispatcherTimer
	$timer.Interval = [TimeSpan]::FromMilliseconds(250)
	$timer.Add_Tick({ $timer.Stop(); & $Action }.GetNewClosure())
	$timer.Start()
}

$script:UI.TenantCombo.Add_SelectionChanged({ param($s, $e)
	if ($script:SuppressTenantEvents) { return }
	$item = $s.SelectedItem
	if (-not $item) { return }
	# Close the dropdown, then defer the sign-in until the popup window is actually gone
	# (see Start-DeferredSignIn + the PopupAnimation=None set on DropDownOpened).
	$s.IsDropDownOpen = $false
	if ($item.Tag -eq 'add') {
		# put the selection back before starting the interactive sign-in
		$script:SuppressTenantEvents = $true
		$s.SelectedIndex = if ($script:ActiveTenant) { $script:Tenants.IndexOf($script:ActiveTenant) } else { -1 }
		$script:SuppressTenantEvents = $false
		Start-DeferredSignIn { Add-TenantSignIn }
		return
	}
	if ($script:ActiveTenant -ne $item.Tag) {
		$tenant = $item.Tag
		Start-DeferredSignIn ({ Connect-Tenant $tenant }.GetNewClosure())
	}
})

$script:UI.ConnectBtn.Add_Click({
	if ($script:ActiveTenant) {
		Disconnect-Tenant
		return
	}
	$sel = Get-SelectedTenant
	if ($sel) { Connect-Tenant $sel } else { Add-TenantSignIn }
})

$script:UI.ForgetTenantBtn.Add_Click({
	$sel = Get-SelectedTenant
	if (-not $sel) { return }
	if (-not (Confirm-YesNo 'Forget tenant' "Forget `"$($sel.name)`" ($($sel.account))? This removes it from the saved list.")) { return }
	if ($script:ActiveTenant -eq $sel) { Disconnect-Tenant }
	[void]$script:Tenants.Remove($sel)
	Save-Tenants
	Write-Host "Removed tenant '$($sel.name)' ($($sel.account)) from the list."
	Update-TenantCombo
})

# Blur/unblur the OPEN dropdown list. The Effect on the ComboBox element doesn't reach
# its popup (WPF renders the popup in a separate visual tree), so blur the popup's
# scroll content directly - which leaves the popup border + drop shadow crisp.
function Set-TenantPopupBlur([bool]$On) {
	try {
		$popup = $script:UI.TenantCombo.Template.FindName('PART_Popup', $script:UI.TenantCombo)
		if (-not $popup -or -not $popup.Child) { return }
		$content = $popup.Child.Child   # PART_Popup -> Border -> ScrollViewer (the items)
		if (-not $content) { return }
		$content.Effect = if ($On) { $fx = New-Object System.Windows.Media.Effects.BlurEffect; $fx.Radius = 8; $fx } else { $null }
	} catch {}
}
# On open: apply the current blur state to the popup content, AND force the popup's
# close animation OFF. WPF's dropdown fade-out gets frozen mid-fade by the blocking
# sign-in, which is what leaves the popup stuck (semi-transparent) on top of the auth
# browser. With no fade the popup closes instantly, so it's gone before sign-in starts.
$script:UI.TenantCombo.Add_DropDownOpened({
	Set-TenantPopupBlur ([bool]$script:Settings.blurTenant)
	try {
		$popup = $script:UI.TenantCombo.Template.FindName('PART_Popup', $script:UI.TenantCombo)
		if ($popup) { $popup.PopupAnimation = [System.Windows.Controls.Primitives.PopupAnimation]::None }
	} catch {}
})

# blur/unblur the tenant + account (for screenshots); remembered across launches
function Set-TenantBlur([bool]$On) {
	$script:Settings.blurTenant = $On
	if ($On) {
		$fx = New-Object System.Windows.Media.Effects.BlurEffect; $fx.Radius = 9
		$script:UI.TenantCombo.Effect = $fx
		$fx2 = New-Object System.Windows.Media.Effects.BlurEffect; $fx2.Radius = 6
		$script:UI.SignStatusText.Effect = $fx2
		$script:UI.BlurIcon.Text = [string][char]0xE889
		$script:UI.BlurTenantBtn.ToolTip = 'Show the tenant / account'
	} else {
		$script:UI.TenantCombo.Effect = $null
		$script:UI.SignStatusText.Effect = $null
		$script:UI.BlurIcon.Text = [string][char]0xE883
		$script:UI.BlurTenantBtn.ToolTip = 'Hide the tenant / account for screenshots'
	}
	Set-TenantPopupBlur $On
	# Blur/unblur the email address inside each activity-log line (the rest of the line
	# - "Connected to <tenant> as ..." - stays readable so the log is still useful).
	if ($script:UI.LogList) {
		foreach ($item in $script:UI.LogList.Items) {
			if ($item -is [System.Windows.Controls.TextBlock]) {
				foreach ($inline in $item.Inlines) {
					if ($inline -is [System.Windows.Documents.InlineUIContainer] -and $inline.Child) {
						$inline.Child.Effect = if ($On) { New-LogEmailBlur } else { $null }
					}
				}
			}
		}
	}
}
$script:UI.BlurTenantBtn.Add_Click({
	Set-TenantBlur (-not $script:Settings.blurTenant)
	Save-AppSettings
})
$script:UI.SearchBox.Add_TextChanged({
	$hasText = [bool]$script:UI.SearchBox.Text
	$script:UI.SearchHint.Visibility = if ($hasText) { 'Collapsed' } else { 'Visible' }
	$script:UI.SearchClearBtn.Visibility = if ($hasText) { 'Visible' } else { 'Collapsed' }
	Update-ScriptList
})
$script:UI.SearchClearBtn.Add_Click({ $script:UI.SearchBox.Clear(); $script:UI.SearchBox.Focus() })
$script:UI.ScriptList.Add_KeyDown({ param($s, $e)
	if ($e.Key -eq 'Return') { Invoke-RunSelected; $e.Handled = $true }
})

# ---- activity log wiring ---------------------------------------------------------
$script:UI.LogToggleBtn.Add_Click({ Set-LogExpanded (-not $script:Settings.logExpanded); Save-AppSettings })
$script:UI.LogClearBtn.Add_Click({
	$script:UI.LogList.Items.Clear()
	$script:UI.LogCountText.Text = ''
})
$script:UI.LogCopyBtn.Add_Click({
	$text = ($script:UI.LogList.Items | ForEach-Object { if ($_.Tag) { [string]$_.Tag } else { [string]$_.Text } }) -join "`r`n"
	if ($text) { [System.Windows.Clipboard]::SetText($text) }
})

# ---- keyboard shortcuts ------------------------------------------------------------
$script:Window.Add_PreviewKeyDown({ param($s, $e)
	$ctrl = [System.Windows.Input.Keyboard]::Modifiers -band [System.Windows.Input.ModifierKeys]::Control
	if ($ctrl) {
		switch ($e.Key) {
			'F' { $script:UI.SearchBox.Focus() | Out-Null; $script:UI.SearchBox.SelectAll(); $e.Handled = $true }
			'L' { Set-LogExpanded (-not $script:Settings.logExpanded); Save-AppSettings; $e.Handled = $true }
		}
	} elseif ($e.Key -eq 'Escape' -and $script:UI.SearchBox.Text) {
		$script:UI.SearchBox.Text = ''
		$e.Handled = $true
	}
})

# ---- window chrome -------------------------------------------------------------
$script:UI.MinBtn.Add_Click({ $script:Window.WindowState = 'Minimized' })
$script:UI.MaxBtn.Add_Click({
	$script:Window.WindowState = if ($script:Window.WindowState -eq 'Maximized') { 'Normal' } else { 'Maximized' }
})
$script:UI.CloseBtn.Add_Click({ $script:Window.Close() })
$script:Window.Add_StateChanged({
	if ($script:Window.WindowState -eq 'Maximized') {
		$script:UI.Root.Margin = '7'
		$script:UI.MaxBtn.Content = [char]0xF149
	} else {
		$script:UI.Root.Margin = '0'
		$script:UI.MaxBtn.Content = [char]0xEC2A
	}
})

# ---- theme toggle ---------------------------------------------------------------
$script:UI.ThemeBtn.Add_Click({
	$next = if ($script:Settings.theme -eq 'Dark') { 'Light' } else { 'Dark' }
	Apply-Theme $next
	Save-AppSettings
})

# ---- shutdown (same disconnect behavior as before, guarded so a missing
# ---- module can't block the window from closing) ---------------------------------
$script:Window.Add_Closing({ param($s, $e)
	if ($env:SP_SHOT) { return }
	$script:Settings.winWidth = [int]$script:Window.Width
	$script:Settings.winHeight = [int]$script:Window.Height
	$script:Settings.winMaximized = $script:Window.WindowState -eq 'Maximized'
	Save-AppSettings
	try { Disconnect-ExchangeOnline -Confirm:$false } catch {}
	try { Disconnect-Graph } catch {}
})

# ---- startup ----------------------------------------------------------------------
# the scripts write transcripts to .\Logs, which is gitignored (transcripts
# contain usernames/machine names) - make sure it exists on fresh clones
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'Logs'))) {
	New-Item -ItemType Directory -Path (Join-Path $PSScriptRoot 'Logs') -Force | Out-Null
}

$script:Window.Width = [double]$script:Settings.winWidth
$script:Window.Height = [double]$script:Settings.winHeight
if ($script:Settings.winMaximized) { $script:Window.WindowState = 'Maximized' }
Set-LogExpanded ([bool]$script:Settings.logExpanded)
Set-TenantBlur ([bool]$script:Settings.blurTenant)
Apply-Theme $script:Settings.theme
Load-Tenants
Update-TenantCombo
if ($script:Tenants.Count -gt 0) {
	Set-SignState $false 'Not connected - pick a tenant above, or click Connect.'
}
$missingModules = @(Get-MissingModules)
if ($missingModules.Count -gt 0) {
	Set-SignState $false "Missing modules: $($missingModules -join ', ') - you will be offered an install on sign-in."
}
Update-ScriptList

Write-Host "Loaded MainGUI."
if (-not $env:SP_SHOT) { CheckForErrors }

# ---- automated screenshot hook (set SP_SHOT to an output dir): renders the main
# ---- window and every dialog in both themes, then exits -----------------------------
if ($env:SP_SHOT) {
	function Save-VisualShot($Visual, [string]$Path) {
		$w = [int][Math]::Ceiling($Visual.ActualWidth)
		$h = [int][Math]::Ceiling($Visual.ActualHeight)
		if ($w -le 0 -or $h -le 0) { return }
		$rtb = [System.Windows.Media.Imaging.RenderTargetBitmap]::new($w, $h, 96, 96, [System.Windows.Media.PixelFormats]::Pbgra32)
		$rtb.Render($Visual)
		$enc = [System.Windows.Media.Imaging.PngBitmapEncoder]::new()
		$enc.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($rtb))
		$fs = [System.IO.FileStream]::new($Path, 'Create')
		$enc.Save($fs)
		$fs.Close()
	}

	$script:ShotBuilders = [ordered]@{
		'dlg-add-2fa'            = { New-AuthenticationPhoneDialog }
		'dlg-add-autoreply'      = {
			$w = New-AutoReplyDialog
			$msg = "I'm out of the office until Monday. For anything urgent, contact sales@contoso.com."
			$w.FindName('InternalReplyBox').Text = $msg; $w.FindName('ExternalReplyBox').Text = $msg
			$t = $w.FindName('ReplyBannerText'); $b = $w.FindName('ReplyBanner')
			$t.Text = 'NEW auto-reply - this is what will be set on the mailbox when you click Confirm.'
			$b.SetResourceReference([System.Windows.Controls.Border]::BorderBrushProperty, 'AccentBrush')
			$t.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, 'AccentBrush')
			$w
		}
		'dlg-autoreply-current'  = {
			$w = New-AutoReplyDialog
			$msg = "Thank you for your message. I have left the company; please contact hr@contoso.com."
			$w.FindName('InternalReplyBox').Text = $msg; $w.FindName('ExternalReplyBox').Text = $msg
			$t = $w.FindName('ReplyBannerText'); $b = $w.FindName('ReplyBanner')
			$t.Text = 'PREVIEW - this is the auto-reply CURRENTLY on the mailbox. Edit it to compose a new one.'
			$b.SetResourceReference([System.Windows.Controls.Border]::BorderBrushProperty, 'WarnBrush')
			$t.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, 'WarnBrush')
			$w.FindName('ShowCurrentBtn').Content = 'Clear preview'
			$w
		}
		'dlg-add-contacts'       = { New-AddContactsDialog }
		'dlg-add-distlistmember' = { New-MemberGroupDialog -Title 'Add-DistributionListMember' -ActionText 'Add Member' -BulkText 'Add Members' -WithPaste }
		'dlg-remove-distlistmember' = { New-MemberGroupDialog -Title 'Remove-DistributionListMember' -ActionText 'Remove Member' -BulkText 'Remove Members' -WithPaste }
		'dlg-paste-remove'          = { New-PasteMembersDialog -TargetPrefill 'dl@contoso.com' -Action 'remove' }
		'dlg-add-emailalias'     = { New-EmailAliasDialog -WithPrimary }
		'dlg-add-mailboxmember'  = { New-MailboxMemberDialog }
		'dlg-add-trustedsender'  = { New-TrustedSenderDialog }
		'dlg-block-user'         = { New-BlockUserDialog }
		'dlg-block-addmember'    = { New-BlockAddMemberDialog }
		'dlg-block-autoreply'    = { New-BlockAutoReplyDialog }
		'dlg-clear-recyclebin'   = { New-ClearRecycleBinDialog }
		'dlg-convert-group'      = { New-ConvertGroupDialog }
		'dlg-enable-archive'     = { New-EnableArchiveDialog }
		'dlg-new-adaccounts'     = { New-ADAccountsDialog -ForestName 'contoso.local' }
		'dlg-new-ademail'        = { New-ADAndEmailAccountsDialog -ForestName 'contoso.local' }
		'dlg-new-emailaccounts'  = { New-EmailAccountsDialog }
		'dlg-set-acl'            = { New-AclPermissionsDialog -DomainName 'CONTOSO' -UserGroupList @('Administrator', 'Domain Admins', 'Domain Users') }
		'dlg-remove-emailalias'  = { New-EmailAliasDialog -Title 'Remove-EmailAlias' -ActionText 'Remove Alias' -BulkText 'Remove Aliases' -CheckText 'Remove Incremental Aliases' }
		'dlg-set-ntp'            = { New-SetNTPDialog }
		'dlg-reset-mfa'          = { New-ResetMfaDialog }
		'dlg-disable-accounts'   = { New-DisableAccountsDialog }
		'dlg-remove-groups'      = { New-RemoveGroupsDialog }
		'dlg-term-autoreply'     = { New-TermAutoReplyDialog 'user@contoso.com' }
		'dlg-set-license'        = { New-SetLicenseDialog }
		'dlg-ac-empty'           = {
			$w = New-StyledDialog -Title 'Type a name OR an email' -Icon '&#xE721;' -BodyXaml @'
<StackPanel Margin="16" Width="380">
	<Border Style="{DynamicResource Card}">
		<StackPanel>
			<TextBlock Text="Add-DistributionListMember" Style="{DynamicResource H3}"/>
			<Grid Margin="0,12,0,0">
				<Grid.ColumnDefinitions><ColumnDefinition Width="70"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
				<Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
				<TextBlock Text="Member" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
				<TextBox x:Name="Mem" Grid.Column="1"/>
				<TextBlock Text="Group" Style="{DynamicResource Dim}" Grid.Row="1" VerticalAlignment="Center" Margin="0,8,0,0"/>
				<TextBox x:Name="Grp" Grid.Row="1" Grid.Column="1" Margin="0,8,0,0"/>
			</Grid>
		</StackPanel>
	</Border>
</StackPanel>
'@
			Set-FieldWatermark $w.FindName('Mem') 'Name or email address'
			Set-FieldWatermark $w.FindName('Grp') 'Name or email address'
			$w
		}
		'dlg-ac-mixed'           = { New-AcPreviewDialog 'Type-ahead - mixed results' 'Mailbox / user (start typing a name)' 'sa' @(
			@('Sara Adler', 'sadler@contoso.com', ''),
			@('Sales', 'sales@contoso.com', 'shared mailbox'),
			@('All Staff', 'allstaff@contoso.com', 'distribution list'),
			@('Marketing Team', 'marketing@contoso.com', 'Teams / Microsoft 365 group'),
			@('Reception Room', 'reception@contoso.com', 'room')) }
		'dlg-ac-member'          = { New-AcPreviewDialog 'Type-ahead - a member field' 'Member (person to add)' 'jo' @(
			@('John Doe', 'jdoe@contoso.com', ''),
			@('Joanna Klein', 'jklein@contoso.com', ''),
			@('Jordan Prima', 'jprima@contoso.com', ''),
			@('Johnson, Alex', 'ajohnson@contoso.com', ''),
			@('Job Applicants', 'jobs@contoso.com', 'shared mailbox')) }
		'dlg-ac-group'           = { New-AcPreviewDialog 'Type-ahead - a group field' 'Group (distribution list / Teams group)' 'sal' @(
			@('Sales Team', 'salesteam@contoso.com', 'Teams / Microsoft 365 group'),
			@('Sales', 'sales@contoso.com', 'distribution list'),
			@('Sales Managers', 'salesmgrs@contoso.com', 'mail-enabled security group'),
			@('Sally Ann Reyes', 'sreyes@contoso.com', '')) }
		'dlg-show-information'   = { New-InformationDialog }
		'dlg-error'              = { New-ErrorDialog "Add-MailboxPermission: mailbox admin@contoso.com`nwas not found on the server." }
		'dlg-opcomplete'         = { New-OperationCompleteDialog }
		'dlg-warning'            = { New-WarningDialog "Turning on AutoExpandingArchive is irreversible - are you sure you'd like to continue?" }
		'dlg-updatecomplete'     = { New-UpdateCompleteDialog "Latest version already installed." }
		'dlg-modules'            = { New-ModulesMissingDialog "Microsoft.Graph`nExchangeOnlineManagement" }
		'dlg-notice-info'        = { New-NoticeDialog 'Already added' 'admin@contoso.com is already added to "Contoso Ltd".' 'Info' }
		'dlg-notice-warn'        = { New-NoticeDialog 'Wrong script for this target' "'sales@contoso.com' is a distribution list, not a mailbox.`n`nUse the 'Add-DistributionListMember' script for it instead." 'Warn' }
		'dlg-notice-summary'     = { New-NoticeDialog 'Add complete' "sales@contoso.com (shared mailbox): 5 added, 1 already there`nContoso Team (Teams / Microsoft 365 group): 5 added`ndl@contoso.com (distribution list): 4 added, 1 failed" 'Warn' }
		'dlg-paste'              = { New-PasteMembersDialog -TargetPrefill "sales@contoso.com`nContoso Team" }
		'dlg-confirm'            = { New-ConfirmDialog 'Forget tenant' 'Forget "Contoso Ltd" (admin@contoso.com)? This removes it from the saved list.' }
		'dlg-confirm-external'   = { New-ConfirmDialog 'External addresses found' "3 addresses aren't in your tenant's domains:`n`n  amy@gmail.com`n  ben@outlook.com`n  cara@partner.co`n`nBring them in so they can be added? Distribution lists get a mail contact; Teams / Microsoft 365 groups get a guest invite; shared mailboxes can't take external addresses, so those are skipped.`n`nYes = bring them in & add.  No = skip the external ones." '&#xEA88;' }
	}

	$script:Window.Add_ContentRendered({
		try {
			$outDir = $env:SP_SHOT
			New-Item -ItemType Directory -Path $outDir -Force | Out-Null
			Write-Host "Example activity entry" -ForegroundColor Cyan
			Write-Host "Example warning entry" -ForegroundColor Red
			# sample tenants so the switcher renders populated
			$script:Tenants.Clear()
			$script:Tenants.Add([pscustomobject]@{ name = 'Contoso Ltd'; account = 'admin@contoso.com'; tenantId = '00000000-0000-0000-0000-000000000001'; lastUsed = (Get-Date).ToString('o') })
			$script:Tenants.Add([pscustomobject]@{ name = 'Fabrikam Inc'; account = 'admin@fabrikam.com'; tenantId = '00000000-0000-0000-0000-000000000002'; lastUsed = '' })
			$script:ActiveTenant = $script:Tenants[0]
			Update-TenantCombo
			Set-SignState $true 'Connected to Contoso Ltd as admin@contoso.com'
			foreach ($themeName in @('Dark', 'Light')) {
				Apply-Theme $themeName
				$script:Window.UpdateLayout()
				$script:Window.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::ApplicationIdle)
				Save-VisualShot $script:UI.RootBorder (Join-Path $outDir "main-$themeName.png")
				Set-LogExpanded $true
				$script:Window.UpdateLayout()
				$script:Window.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::ApplicationIdle)
				Save-VisualShot $script:UI.RootBorder (Join-Path $outDir "main-log-$themeName.png")
				Set-LogExpanded $false
				foreach ($key in $script:ShotBuilders.Keys) {
					$dlg = & $script:ShotBuilders[$key]
					$dlg.WindowStartupLocation = 'Manual'
					$dlg.Left = 40; $dlg.Top = 40
					$dlg.ShowActivated = $false
					$dlg.Show()
					$dlg.UpdateLayout()
					$dlg.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::ApplicationIdle)
					Save-VisualShot $dlg.Content (Join-Path $outDir "$key-$themeName.png")
					$dlg.Close()
				}
			}
			Apply-Theme 'Dark'
		} catch {
			Set-Content -Path (Join-Path $env:SP_SHOT 'error.txt') -Value ($_ | Out-String)
		}
		$script:Window.Close()
	})
}

# ---- automation hook (dot-sources a script into app scope; used by self-tests) ------
if ($env:SP_TEST -and (Test-Path -LiteralPath $env:SP_TEST)) {
	. $env:SP_TEST
}

# On first launch, prompt to install the required modules if they're missing (after
# the window is visible). Guarded off during screenshot/self-test runs.
if (-not $env:SP_SHOT -and -not $env:SP_TEST) {
	$script:ModulesCheckedAtStartup = $false
	$script:Window.Add_ContentRendered({
		if ($script:ModulesCheckedAtStartup) { return }
		$script:ModulesCheckedAtStartup = $true
		try { Confirm-ModulesAtStartup } catch {}
	})
}

# Show MainWindow
[void]$script:Window.ShowDialog()
