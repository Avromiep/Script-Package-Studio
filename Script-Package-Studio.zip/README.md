# Script-Package Studio

A modern WPF admin toolkit for Microsoft 365 and Active Directory - dark/light themes, a multi-tenant switcher, a searchable script browser, and an activity log.

## Requirements

**[Powershell 7 or higher](https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell?view=powershell-7.4)**  

**Run as administrator:** The installer version will create a shortcut which can be ran as admin. You can set it to always run as admin by going to the shortcut's properties, then "Advanced", then checking off "Run as administrator".  
For the portable version, run `Script-Package-Studio.bat` as administrator.

**Modules:** Microsoft.Graph, ExchangeOnlineManagement  
- `Install-Module -Name Microsoft.Graph -Force -AllowClobber`  
- `Install-Module -Name ExchangeOnlineManagement -Force -AllowClobber`  
  
If the modules are missing, the app offers to install them the first time you sign in. You can also run the `Install-RequiredModules` script from the list to install them manually.

## The GUI

What it looks like:  
![Script-Package Studio GUI](Images/gui-v3-2.png)

A modern WPF interface with dark and light themes (toggle in the title bar; your choice is remembered).

**Tenant switcher:** Sign in to multiple Microsoft tenants and switch between them from the dropdown at the top. Saved tenants are remembered in `tenants.json` (names, accounts and tenant ids only - credentials stay in the Microsoft token caches), so switching to a known tenant usually reconnects without any prompt. Use *+ Add a tenant...* in the dropdown to sign in to another tenant, the trash button to forget one, and Connect/Disconnect to control the session without relaunching (Disconnect asks for confirmation first, so you can't drop the session by accident). See the [scripts](#scripts) section below for which scripts need a connected tenant.

**Active Directory user search:** The AD username fields on Block-User and Terminate offer type-ahead search of your domain - type a full name **or** a username and pick the person from the dropdown (it shows both, flags disabled accounts, and fills in the username). It's a fast local lookup, so it only works when you're on a machine with the Active Directory module (e.g. a domain controller).

**Recipient search:** Fields that take an email address (member, mailbox, group, user...) offer type-ahead search of the connected tenant - start typing a name or address and pick the recipient from the dropdown; non-user mailboxes (shared, distribution list, Teams/M365 group, room) are tagged so you can tell them apart. On sign-in the app indexes the tenant's recipients in the background so lookups are instant; a small status light on the home screen (and mirrored onto any script window that uses the search) shows *Preparing tenant search* while it loads and *Tenant search ready* once it's done. The whole feature can be turned off under *Recipient search* in Settings.

**Script browser:** Search with `Ctrl+F`, filter by category (Microsoft 365 / Active Directory / System / App), then run a script with double-click, `Enter`, or the Run button. Each script has a small **ⓘ** button (on its tile, and in the script's window) that opens a short, plain-language explanation of what it does and how to use it - written so a non-technical person can follow it.

**Activity log:** Everything the scripts report is collected in the collapsible Activity drawer at the bottom (`Ctrl+L`), color-coded, with copy/clear buttons.

**Status bar:** Shows progress for running tasks and what ran last. The progress bar shows how far along a task is, with a moving shimmer so you can tell it's still working.

**Updating:** Updates are built into **Settings** (the gear icon) - it checks for a newer release, installs it, and offers to relaunch. (There's no separate "update" script.)

<a name="scripts"></a>

## Scripts

### Add-Contacts

*Requires sign in.*  
Add contacts for Microsoft 365.

### Add-DistributionListMember

*Requires sign in.*  
Add a single member or multiple members to a distribution list.

### Add-EmailAlias

*Requires sign in.*  
Add an alias to an email.   
Also has options for adding aliases in bulk.

### Add-MailboxMember

*Requires sign in.*  
Add a member to another mailbox. It can be a shared mailbox or just another user's email.  
Also has options for adding members in bulk.  
Also has buttons for adding only SendAs, SendOnBehalf or FullAccess permissions (FullAccess is also known as ReadAndManage).  
**Copy a user's access:** the *Copy access from a user...* button mirrors everything one user has onto another - shared / other-mailbox access (Full Access + Send As), distribution lists, and Teams / Microsoft 365 groups (security groups optional). Enter a *From* and a *To* user, tick what to copy, and use *Preview* to see what will be copied before *Copy access* applies it. Group memberships and Send As are found instantly; Full Access has no reverse lookup so mailboxes are scanned one by one (shared mailboxes by default; tick the box to also scan user mailboxes) - this can take a few minutes in a large tenant. Dynamic and on-prem-synced groups are listed as skipped since their membership can't be edited here.

### Add-TrustedSender

*Requires sign in.*  
Adds an email address or domain to the trusted senders list for all mailboxes in the current tenant. This will take a while to complete (especially in a big tenant) since all the mailboxes are having their junk email settings configured.

### Add-UnifiedGroupMember

*Requires sign in.*  
Add a single or multiple members to a Unified/Office365 Group.  

### Add-AutoReply

*Requires sign in.*  
Turn on an automatic (out-of-office) reply for a mailbox. Write the internal and external messages, optionally schedule a start/end date, and click Confirm. **Show current** loads the reply already set on the mailbox so you can review or edit it before replacing it.

### Add-AuthenticationPhoneMethod

*Requires sign in.*  
Add a phone number to a user for 2FA.  
You don't have to type the `+1 ` yourself - enter a US/Canada number as plain digits (any format, e.g. `(222) 444-6666`). For other countries, type the country code (e.g. `+44` or `00441234...`) and it's lifted out of the box up next to the flag. A country flag and the `+code` show just to the left of the box (outside it) and update live as you type, while the box keeps just the national number - so you can see which country the number is being read as. It's submitted to Microsoft in the `+CC national` format it expects.  
**Show current** lists the 2FA methods already registered for that user - phone, alternate phone, Microsoft Authenticator, other authenticator apps, security keys, email, and so on (only the ones they actually have). **Remove a 2FA method** opens a picker where you select one of those methods and remove it (with a yes/no confirm) - useful when someone lost a phone or key. A colored banner makes it clear whether you're viewing current methods or adding a new one. Add a number as the primary **Mobile** or as an **Alternate mobile** (use Alternate when a mobile is already set).  
Also has options for bulk (the same number formatting applies to the CSV).

### Block-User

*Requires sign in. Requires run on server with Active Directory.*  
For AD: This will disable the AD account of the entered user.  
For O365: This will disable the account, convert the mailbox to type shared,  change the password to something random, remove all licenses and remove any 2FA number associated with the account. Has options for adding members to the shared mailbox and for adding an auto-reply.  
Bulk options will be added in the future.

### Terminate-Disable-ADAndEmailAccounts

*Requires sign in. Requires run on server with Active Directory.*  
Full offboarding for someone who has left: disables their Active Directory and Microsoft 365 accounts, converts the mailbox to shared, removes licenses and 2FA, revokes their sessions, and can set an auto-reply and give a manager access to the mailbox. Also has a bulk (CSV) option.

### Clear-RecycleBin

Empties all recycle bins on the computer. For a terminal server, this would mean deleting the contents of everyone's recycle bins.

### Convert-UnifiedGroupToDistributionGroup

*Requires sign in.*  
Creates a new distribution list using the members of an existing Microsoft 365 (Unified) group.  
Has an input field for an email address of a Microsoft 365 Group. The script will create a new distribution list, get all the members of the M365 group and then add them to the newly created distribution list. The name of the new distribution list will be the first part of the email entered with "-New" tacked on.  
Also includes a tab for converting M365 groups in bulk.   
If you want to change the names/addresses of the newly created distribution list(s) or if you want to delete the old M365 group(s) you will need to do it manually from the Office365 admin web portal.

### Enable-Archive

*Requires sign in.*  
Turn on archiving, jumpstart archiving or turn on auto-expanding archive for a mailbox.  

### Install-RequiredModules

Installs required modules for the script package to work.  
`Install-Module -Name Microsoft.Graph -Force -AllowClobber`  
`Install-Module -Name ExchangeOnlineManagement -Force -AllowClobber`

### New-ADAccounts

*Requires run on server with Active Directory.*  
Add Active Directory accounts in bulk.  
The script will auto-detect the ActiveDirectory domain/forest name, but it can be changed if necessary.

### New-ADAndEmailAccounts

*Requires sign in. Requires run on server with Active Directory.*  
The script will auto-detect the ActiveDirectory domain/forest name, but it can be changed if necessary.  
The email domain to use for the new email accounts must be entered or the email accounts won't be created.  
Choose a license for the new email account from the list and make sure to purchase enough licenses before running the script or none will be assigned.  

### New-EmailAccounts
*Requires sign in.*  
Use the button to open and fill out the template.  
Choose a license for the new email account from the list and make sure to purchase enough licenses before running the script or none will be assigned.  

### Remove-DistributionListMember

*Requires sign in.*  
Remove a single member or multiple members from a distribution list.

### Remove-MailboxMember

*Requires sign in.*  
Remove a member from another mailbox. It can be a shared mailbox or just another user's email.  
Also has options for removing members in bulk.  
Also has buttons for removing only SendAs, SendOnBehalf or FullAccess permissions (FullAccess is also known as ReadAndManage).

### Remove-UnifiedGroupMember

*Requires sign in.*  
Removes a single or multiple members from a Unified/Office365 group.

### Remove-EmailAlias

*Requires sign in.*  
Remove an alias from a mailbox (the primary address stays). Also has options for removing aliases in bulk, and for removing numbered/incremental aliases.

### Remove-UserFromAllGroups

*Requires sign in.*  
Remove a user from all (or the ones you choose) of the tenant's groups - distribution lists, Teams / Microsoft 365 groups, and security groups. Useful when offboarding someone.

### Reset-MFA

*Requires sign in.*  
Clear a user's 2FA (MFA) methods so they re-register from scratch - for example after they lost their phone. Single or bulk.

### Set-License

*Requires sign in.*  
Assign, remove, or swap Microsoft 365 licenses for a user. Single or bulk.

### Set-ACLPermissions

A tool for dealing with ACL permissions.  
Has bulk options.

### Set-NTP

A tool for checking the time server and configuration of the current computer/server. Can set it to time.windows.com.

### Show-Information

Script-Package Studio info and links.

## Logging

Most of the scripts will create a transcript in the `Logs` folder.  
The transcripts are set to overwrite older ones, so if you run a script twice you will only see the log for the latest run.

## Credits

Icons: [Fluent System Icons](https://github.com/microsoft/fluentui-system-icons) by Microsoft (MIT). The font is bundled in `Fonts/` so icons render on every Windows version - see `Fonts/FluentSystemIcons-LICENSE.txt`.
