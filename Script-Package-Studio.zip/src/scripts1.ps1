﻿# Script-Package - script dialogs (Add-*)
# Every function keeps its original logic and cmdlet calls; only the UI layer
# changed from WinForms to WPF windows styled by the merged design dictionary.

# Classify a recipient so the member scripts can catch "wrong script for this target"
# mistakes (e.g. running Add-MailboxMember against a distribution list).
# Returns 'Mailbox' | 'DistributionList' | 'UnifiedGroup' | 'Other', or $null if the
# recipient can't be looked up. $script:LastRecipientRaw holds the raw type string for
# diagnostics/logging.
function Get-RecipientCategory([string]$Identity) {
	$script:LastRecipientRaw = ''
	if (-not $Identity) { return $null }
	$r = $null
	try { $r = Get-Recipient -Identity $Identity -ErrorAction Stop | Select-Object -First 1 } catch { return $null }
	if (-not $r) { return $null }
	$d = "$($r.RecipientTypeDetails) $($r.RecipientType)"
	$script:LastRecipientRaw = $d.Trim()
	if ($d -match 'GroupMailbox') { return 'UnifiedGroup' }                                       # Microsoft 365 / Teams group
	if ($d -match 'Distribution|MailUniversal|MailNonUniversal|RoomList') { return 'DistributionList' }
	if ($d -match 'Mailbox') { return 'Mailbox' }                                                 # User/Shared/Room/etc.
	return 'Other'
}

# Friendly, specific type name from a raw "RecipientTypeDetails RecipientType" string
# (e.g. 'SharedMailbox UserMailbox' -> 'shared mailbox') so the summary can say exactly
# what each target was. Pass $script:LastRecipientRaw captured right after Get-RecipientCategory.
function Get-RecipientTypeName([string]$Raw) {
	switch -Regex ($Raw) {
		'SharedMailbox'                 { return 'shared mailbox' }
		'RoomMailbox'                   { return 'room mailbox' }
		'EquipmentMailbox'              { return 'equipment mailbox' }
		'GroupMailbox'                  { return 'Teams / Microsoft 365 group' }
		'DynamicDistribution'           { return 'dynamic distribution list' }
		'MailUniversalSecurityGroup'    { return 'mail-enabled security group' }
		'MailUniversalDistributionGroup|MailNonUniversalGroup|DistributionGroup' { return 'distribution list' }
		'UserMailbox'                   { return "user's mailbox" }
		default                         { return 'recipient' }
	}
}

# True if an add/remove error just means "nothing to do" (already a member on add, or
# not a member on remove) rather than a real failure - used to summarize bulk runs.
function Test-HarmlessMemberError([string]$Message) {
	return ($Message -match "already a member|already exists|already has|is already|AlreadyExists|already present|isn't a member|is not a member|not a member|no matching|couldn't be found|not found")
}

# Show ONE summary popup after a bulk add/remove (instead of a popup per row). $Counts has
# done/noop/failed/skipped; $Action is 'add' or 'remove' for the wording.
function Show-BulkSummary([hashtable]$Counts, [string]$Action, $Corrected = $null) {
	$doneWord = if ($Action -eq 'remove') { 'removed' } else { 'added' }
	$noopWord = if ($Action -eq 'remove') { "weren't members" } else { 'already there' }
	$parts = @()
	if ($Counts.done -gt 0)    { $parts += "$($Counts.done) $doneWord" }
	if ($Counts.noop -gt 0)    { $parts += "$($Counts.noop) $noopWord" }
	if ($Counts.skipped -gt 0) { $parts += "$($Counts.skipped) skipped (couldn't look up)" }
	if ($Counts.failed -gt 0)  { $parts += "$($Counts.failed) failed" }
	$summary = if ($parts.Count) { $parts -join ', ' } else { 'nothing to do' }
	Write-Host "Bulk result: $summary." -ForegroundColor Cyan
	# Note any targets that were auto-routed to a different type than the script is named for.
	$note = ''
	$corr = @($Corrected)
	if ($corr.Count) {
		$note = "`n`nNote - some targets were a different type than this script, and were handled as their real type:`n" + (($corr | ForEach-Object { "  - $_" }) -join "`n")
	}
	$kind  = if ($Counts.failed -gt 0) { 'Warn' } else { 'Info' }
	$title = if ($Action -eq 'remove') { 'Bulk remove complete' } else { 'Bulk add complete' }
	Show-Notice $title "Finished processing the list:`n`n$summary.$note" $kind
	$progressBar1.Value = 0
}

# Add or remove ONE member on ONE target, auto-routing by the target's REAL type instead of
# assuming the script's own type. So 'Add distribution list member' still works when the
# address is really a shared mailbox (grants access) or a Teams group (adds as member), etc.
# Returns @{ Category; TypeName; Status ('done'|'noop'|'failed'|'unknown'); Message }.
# Shows no UI - the caller decides how to report. $MailboxRight picks what to do when the
# target turns out to be a mailbox: 'FullAndSendAs' (default) | 'FullAccess' | 'SendAs' |
# 'SendOnBehalf'. $FallbackCategory is used when the target can't be classified (e.g. lookup
# failed) so we still try the script's native cmdlet and surface its real error. Pass a shared
# [hashtable]$Cache across a bulk run to avoid re-querying the same target.
function Invoke-MemberRoute {
	param(
		[string]$Target,
		[string]$Member,
		[string]$Action = 'add',
		[string]$MailboxRight = 'FullAndSendAs',
		[string]$FallbackCategory = '',
		[hashtable]$Cache = $null
	)
	$isRemove = ($Action -eq 'remove')
	if ($Cache -and $Cache.ContainsKey($Target)) {
		$cat = $Cache[$Target].Cat; $typeName = $Cache[$Target].Name
	} else {
		$cat = Get-RecipientCategory $Target
		$typeName = Get-RecipientTypeName $script:LastRecipientRaw
		if ($Cache) { $Cache[$Target] = @{ Cat = $cat; Name = $typeName } }
	}
	if (-not $Cache) { $progressBar1.Value = 65 }   # single op: bar advances once the type is known, before the change
	$res = @{ Category = $cat; TypeName = $typeName; Status = 'unknown'; Message = '' }
	$effCat = if ($cat -and $cat -ne 'Other') { $cat } elseif ($FallbackCategory) { $FallbackCategory } else { '' }
	if (-not $effCat) { return $res }
	try {
		if ($isRemove) {
			switch ($effCat) {
				'DistributionList' { Remove-DistributionGroupMember -Identity $Target -Member $Member -Confirm:$false -ErrorAction Stop }
				'UnifiedGroup'     { Remove-UnifiedGroupLinks -Identity $Target -LinkType Members -Links $Member -Confirm:$false -ErrorAction Stop }
				'Mailbox' {
					switch ($MailboxRight) {
						'SendAs'       { Remove-RecipientPermission -Identity $Target -Trustee $Member -AccessRights SendAs -Confirm:$false -ErrorAction Stop }
						'SendOnBehalf' { Set-Mailbox -Identity $Target -GrantSendOnBehalfTo @{Remove=$Member} -ErrorAction Stop }
						'FullAccess'   { Remove-MailboxPermission -Identity $Target -User $Member -AccessRights FullAccess -InheritanceType All -Confirm:$false -ErrorAction Stop }
						default {
							Remove-MailboxPermission -Identity $Target -User $Member -AccessRights FullAccess -InheritanceType All -Confirm:$false -ErrorAction Stop
							Remove-RecipientPermission -Identity $Target -Trustee $Member -AccessRights SendAs -Confirm:$false -ErrorAction Stop
						}
					}
				}
			}
		} else {
			switch ($effCat) {
				'DistributionList' { Add-DistributionGroupMember -Identity $Target -Member $Member -ErrorAction Stop }
				'UnifiedGroup'     { Add-UnifiedGroupLinks -Identity $Target -LinkType Members -Links $Member -ErrorAction Stop }
				'Mailbox' {
					switch ($MailboxRight) {
						'SendAs'       { Add-RecipientPermission -Identity $Target -Trustee $Member -AccessRights SendAs -Confirm:$false -ErrorAction Stop }
						'SendOnBehalf' { Set-Mailbox -Identity $Target -GrantSendOnBehalfTo @{Add=$Member} -ErrorAction Stop }
						'FullAccess'   { Add-MailboxPermission -Identity $Target -User $Member -AccessRights FullAccess -InheritanceType All -AutoMapping $true -ErrorAction Stop }
						default {
							Add-MailboxPermission -Identity $Target -User $Member -AccessRights FullAccess -InheritanceType All -AutoMapping $true -ErrorAction Stop
							Add-RecipientPermission -Identity $Target -Trustee $Member -AccessRights SendAs -Confirm:$false -ErrorAction Stop
						}
					}
				}
			}
		}
		$res.Status = 'done'
	} catch {
		$msg = "$($_.Exception.Message)".Trim()
		$res.Message = $msg
		$res.Status = if (Test-HarmlessMemberError $msg) { 'noop' } else { 'failed' }
	}
	return $res
}

# What each detected type is "called" for the after-the-fact note.
$script:MemberTypeArticle = @{ Mailbox = 'a mailbox'; DistributionList = 'a distribution list'; UnifiedGroup = 'a Teams / Microsoft 365 group' }
# Plain name of the category a script is FOR - used only in the "you opened the wrong script" heads-up.
$script:MemberTypeName = @{ Mailbox = 'mailbox'; DistributionList = 'distribution list'; UnifiedGroup = 'Teams / Microsoft 365 group' }

# Run one single-target add/remove through Invoke-MemberRoute and report the outcome with a
# popup - INCLUDING a friendly note when the target turned out to be a different type than the
# script is named for (e.g. "that address is actually a distribution list, but Jane was added
# to it anyway"). No confirmation gate: it just does the right thing, then tells you. $Expected
# is the category this script is for (used only for the note + as the fallback cmdlet).
function Invoke-SingleMemberChange {
	param([string]$Target, [string]$Member, [string]$Expected, [string]$Action = 'add', [string]$MailboxRight = 'FullAndSendAs')
	$isRemove = ($Action -eq 'remove')
	$verbPast = if ($isRemove) { 'removed from' } else { 'added to' }
	if (-not $Target -or -not $Member) {
		Show-Notice 'Missing info' "Enter both a member and a target first." 'Warn'; $progressBar1.Value = 0; return
	}
	$progressBar1.Value = 40
	$r = Invoke-MemberRoute -Target $Target -Member $Member -Action $Action -MailboxRight $MailboxRight -FallbackCategory $Expected
	$typeName = $r.TypeName
	$mismatch = ($r.Category -and $r.Category -ne 'Other' -and $r.Category -ne $Expected)
	$expName = $script:MemberTypeName[$Expected]
	# Always name the target's REAL, specific type (shared mailbox / user's mailbox / distribution list /
	# Teams group), woven into the sentence. Heads-up only when the category differs from this script.
	$where = if ($typeName -and $typeName -ne 'recipient') { "the $typeName `"$Target`"" } else { "`"$Target`"" }
	switch ($r.Status) {
		'unknown' {
			Write-Host "Couldn't determine the type of '$Target'." -ForegroundColor Red
			Show-Notice 'Not found' "Couldn't find `"$Target`" or work out its type (mailbox, distribution list, or Teams / Microsoft 365 group).`n`nCheck the address and that you're connected to the right tenant." 'Error'
		}
		'done' {
			Write-Host "$Member was $verbPast $where." -ForegroundColor Cyan
			$progressBar1.Value = 100
			$note = if ($mismatch) { "`n`nHeads up: you used the $expName script, but `"$Target`" is actually a $typeName - $Member was still $verbPast it." } else { '' }
			Show-Notice $(if ($isRemove) { 'Removed' } else { 'Added' }) "$Member was $verbPast $where.$note" 'Info'
			OperationComplete
		}
		'noop' {
			$noopMsg = if ($isRemove) { "$Member wasn't on $where - nothing to remove." } else { "$Member is already on $where." }
			Write-Host $noopMsg -ForegroundColor Yellow
			$note = if ($mismatch) { "`n`n(Heads up: you used the $expName script, but `"$Target`" is actually a $typeName.)" } else { '' }
			Show-Notice 'Nothing to do' "$noopMsg$note" 'Info'
		}
		'failed' {
			$vb = if ($isRemove) { 'remove' } else { 'add' }
			$pp = if ($isRemove) { 'from' } else { 'to' }
			Write-Host "Couldn't $vb $Member $pp '$Target': $($r.Message)" -ForegroundColor Red
			Show-Notice "$(if ($isRemove) { 'Remove' } else { 'Add' }) failed" "Couldn't $vb $Member $pp `"$Target`":`n`n$($r.Message)" 'Error'
		}
	}
	$progressBar1.Value = 0
}

# Bulk (CSV) auto-route for one row. Uses the shared $Cache + $Notes list so the end summary
# can mention any targets whose real type differed. Returns 'done'|'noop'|'failed'|'unknown'.
function Invoke-BulkMemberRow {
	param([string]$Target, [string]$Member, [string]$Expected, [string]$Action, [hashtable]$Cache, [System.Collections.Generic.HashSet[string]]$Corrected, [string]$MailboxRight = 'FullAndSendAs')
	$r = Invoke-MemberRoute -Target $Target -Member $Member -Action $Action -MailboxRight $MailboxRight -FallbackCategory $Expected -Cache $Cache
	if ($r.Category -and $r.Category -ne 'Other' -and $r.Category -ne $Expected -and $Corrected) {
		[void]$Corrected.Add("`"$Target`" is a $($r.TypeName)")
	}
	$verbPast = if ($Action -eq 'remove') { 'removed from' } else { 'added to' }
	switch ($r.Status) {
		'done'    { Write-Host "$Member was $verbPast the $($r.TypeName) `"$Target`"." }
		'noop'    { Write-Host "${Member}: nothing to do on the $($r.TypeName) `"$Target`"." -ForegroundColor Yellow }
		'failed'  { Write-Host "Couldn't process $Member on '$Target': $($r.Message)" -ForegroundColor Red }
		'unknown' { Write-Host "Skipped $Member on '$Target' - couldn't determine its type." -ForegroundColor Yellow }
	}
	return $r.Status
}

# Pull unique email addresses out of arbitrary pasted text (case-insensitive de-dupe,
# original order kept). Same idea as a standalone email-extractor utility.
function Get-EmailsFromText([string]$Text) {
	if (-not $Text) { return @() }
	$seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
	$out  = [System.Collections.Generic.List[string]]::new()
	foreach ($m in ([regex]'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}').Matches($Text)) {
		if ($seen.Add($m.Value)) { $out.Add($m.Value) }
	}
	return $out.ToArray()
}

# --- External-address handling ------------------------------------------------------------
# When a pasted address isn't in one of the tenant's accepted domains it can't be added to a
# group/mailbox as-is. We offer to bring it in first: distribution lists take a MAIL CONTACT,
# Teams / Microsoft 365 groups take a GUEST invite, shared mailboxes can't take an external at
# all. These helpers do the lookups/provisioning and are called from the paste "Add All" flow.

# Tenant's accepted domains (lowercased HashSet), or $null if the lookup fails (then we skip
# the whole external check and just let the normal cmdlets run + surface their own errors).
function Get-AcceptedDomainList {
	try {
		$set = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
		foreach ($d in (Get-AcceptedDomain -ErrorAction Stop)) { [void]$set.Add(("$($d.DomainName)").Trim()) }
		if ($set.Count -eq 0) { return $null }
		return $set
	} catch { return $null }
}

# Is $Email outside every accepted domain? $Accepted is the HashSet from Get-AcceptedDomainList.
function Test-IsExternalAddress([string]$Email, $Accepted) {
	if (-not $Accepted) { return $false }
	$at = $Email.LastIndexOf('@')
	if ($at -lt 0) { return $false }
	$dom = $Email.Substring($at + 1).Trim()
	return (-not $Accepted.Contains($dom))
}

# Ensure a mail contact exists for an external address; returns the identity to use as a DL
# member (the existing recipient if one already resolves, else a freshly created contact).
# Throws on failure so the caller can record it.
function Resolve-OrCreateMailContact([string]$Email) {
	$existing = $null
	try { $existing = Get-Recipient -Identity $Email -ErrorAction Stop | Select-Object -First 1 } catch { $existing = $null }
	if ($existing) { return $Email }
	# Name must be unique in the OU; the address itself is a safe, unique choice.
	New-MailContact -Name $Email -ExternalEmailAddress $Email -ErrorAction Stop | Out-Null
	return $Email
}

# Ensure the external address exists as a guest user; returns its AAD object id. Reuses an
# existing guest if one is already present, otherwise sends an invitation. Throws on failure.
function Resolve-OrInviteGuest([string]$Email) {
	$u = $null
	try { $u = Get-MgUser -Filter "mail eq '$Email'" -ErrorAction Stop | Select-Object -First 1 } catch { $u = $null }
	if (-not $u) { try { $u = Get-MgUser -Filter "otherMails/any(x:x eq '$Email')" -ErrorAction Stop | Select-Object -First 1 } catch { $u = $null } }
	if ($u) { return $u.Id }
	$inv = New-MgInvitation -InvitedUserEmailAddress $Email -InviteRedirectUrl 'https://myapps.microsoft.com' -SendInvitationMessage:$true -ErrorAction Stop
	return $inv.InvitedUser.Id
}

# Add an already-resolved guest (AAD object id) to a Microsoft 365 / Teams group given by its
# SMTP address. Resolves the group's AAD id via Get-UnifiedGroup, then New-MgGroupMember.
function Add-GuestToUnifiedGroup([string]$GroupSmtp, [string]$GuestId) {
	$g = Get-UnifiedGroup -Identity $GroupSmtp -ErrorAction Stop
	$gid = $g.ExternalDirectoryObjectId
	if (-not $gid) { throw "Couldn't resolve the group's directory id for '$GroupSmtp'." }
	New-MgGroupMember -GroupId $gid -DirectoryObjectId $GuestId -ErrorAction Stop
}

# Universal paste-to-add/remove: paste people (top, live-extracted) + paste one or more
# targets (bottom) that can be ANY mix of distribution lists, shared mailboxes, or Teams /
# M365 groups. On Add/Remove All, each target's real type is detected (Get-RecipientCategory)
# and the right cmdlet is used per target. $Action = 'add' | 'remove'. The CSV path is kept.
function New-PasteMembersDialog {
	param([string]$TargetPrefill = '', [string]$Action = 'add')
	$isRemove = ($Action -eq 'remove')
	$verb     = if ($isRemove) { 'Remove' } else { 'Add' }
	$verbLow  = if ($isRemove) { 'remove' } else { 'add' }
	$prep     = if ($isRemove) { 'from' } else { 'to' }
	$topLabel = "Paste text with the people to $verbLow (emails are pulled out automatically):"
	$tgtLabel = "$verb them $prep these - paste names + emails of distribution lists, shared mailboxes, or Teams / M365 groups; the addresses are pulled out automatically:"
	$win = New-StyledDialog -Title "$verb members (paste)" -Icon '&#xED75;' -BodyXaml @"
<StackPanel Margin="16" Width="480">
	<Border Style="{DynamicResource Card}">
		<StackPanel>
			<TextBlock Text="$topLabel" Style="{DynamicResource Dim}" TextWrapping="Wrap" Margin="0,0,0,4"/>
			<TextBox x:Name="PasteInput" Style="{DynamicResource TextArea}" Height="90" TextWrapping="Wrap" AcceptsReturn="True" VerticalScrollBarVisibility="Auto"/>
			<Grid Margin="0,10,0,4">
				<TextBlock Text="Members - edit if needed:" Style="{DynamicResource Dim}" HorizontalAlignment="Left"/>
				<TextBlock x:Name="PasteCount" Style="{DynamicResource Small}" HorizontalAlignment="Right" VerticalAlignment="Center"/>
			</Grid>
			<TextBox x:Name="PastePreview" Style="{DynamicResource TextArea}" Height="90" AcceptsReturn="True" VerticalScrollBarVisibility="Auto"/>
			<Border Style="{DynamicResource Divider}"/>
			<TextBlock Text="$tgtLabel" Style="{DynamicResource Dim}" TextWrapping="Wrap" Margin="0,0,0,4"/>
			<TextBox x:Name="PasteTargetsInput" Style="{DynamicResource TextArea}" Height="60" AcceptsReturn="True" VerticalScrollBarVisibility="Auto"/>
			<Grid Margin="0,8,0,4">
				<TextBlock Text="Targets - edit if needed:" Style="{DynamicResource Dim}" HorizontalAlignment="Left"/>
				<TextBlock x:Name="PasteTargetsCount" Style="{DynamicResource Small}" HorizontalAlignment="Right" VerticalAlignment="Center"/>
			</Grid>
			<TextBox x:Name="PasteTargetsPreview" Style="{DynamicResource TextArea}" Height="60" AcceptsReturn="True" VerticalScrollBarVisibility="Auto"/>
			<Grid Margin="0,14,0,0">
				<Button x:Name="PasteCancelBtn" Style="{DynamicResource BtnGhost}" Content="Cancel" HorizontalAlignment="Left" MinWidth="90"/>
				<Button x:Name="PasteAddBtn" Style="{DynamicResource BtnPrimary}" Content="$verb All" HorizontalAlignment="Right" MinWidth="140"/>
			</Grid>
		</StackPanel>
	</Border>
</StackPanel>
"@
	$pasteBox   = $win.FindName('PasteInput')
	$previewBox = $win.FindName('PastePreview')
	$countText  = $win.FindName('PasteCount')
	$targetsInput   = $win.FindName('PasteTargetsInput')
	$targetsPreview = $win.FindName('PasteTargetsPreview')
	$targetsCount   = $win.FindName('PasteTargetsCount')
	$result = @{ Counts = $null; Lines = $null; AnyFailed = $false; TargetCount = 0; Action = $Action }
	$win.Tag = $result

	# Live: refill the members list from the top box whenever it changes (no button needed).
	$pasteBox.Add_TextChanged({
		$emails = @(Get-EmailsFromText $pasteBox.Text)
		$previewBox.Text = ($emails -join "`r`n")
		$countText.Text = "$($emails.Count) unique"
	}.GetNewClosure())

	# Live: filter the targets down the SAME way as the members box. If the pasted text has any
	# email address(es), show JUST the emails, in the exact order they appear - so a messy blob with
	# prose/signatures becomes only the addresses, and the last pasted email is the last one here.
	# Only when there are NO emails at all do we keep each line as a plain-name/alias target (e.g.
	# "Sales DL") so name-only targets still work.
	$refreshTargets = {
		$emails = @(Get-EmailsFromText $targetsInput.Text)
		if ($emails.Count) {
			$out = $emails
		} else {
			$seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
			$list = [System.Collections.Generic.List[string]]::new()
			foreach ($line in ($targetsInput.Text -split "?
")) { $t = $line.Trim(); if ($t -and $seen.Add($t)) { [void]$list.Add($t) } }
			$out = $list.ToArray()
		}
		$targetsPreview.Text = (@($out) -join "`r`n")
		$targetsCount.Text = "$(@($out).Count) target(s)"
	}.GetNewClosure()
	$targetsInput.Add_TextChanged($refreshTargets)
	$targetsInput.Text = $TargetPrefill
	& $refreshTargets

	$win.FindName('PasteCancelBtn').Add_Click({ $win.Close() }.GetNewClosure())

	$win.FindName('PasteAddBtn').Add_Click({
		$members = @(Get-EmailsFromText $previewBox.Text)
		# targets: the preview is already the final, filtered list (emails only, or plain names) in order
		$targets = @($targetsPreview.Text -split "?
" | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique)
		if ($members.Count -eq 0) { Show-Notice 'Nothing to do' "No people to $verbLow - paste some text with email addresses at the top." 'Warn'; return }
		if ($targets.Count -eq 0) { Show-Notice 'Nothing to do' 'Add at least one target (distribution list, shared mailbox, or Teams / M365 group) at the bottom.' 'Warn'; return }
		$counts = @{ done = 0; noop = 0; failed = 0; skipped = 0 }
		$lines = [System.Collections.Generic.List[string]]::new()
		$anyFailed = $false
		$doneWord = if ($isRemove) { 'removed' } else { 'added' }
		$noopWord = if ($isRemove) { "weren't members" } else { 'already there' }
			# External (non-tenant-domain) addresses: offer once to bring them in first, so a
			# batch doesn't need a separate contact/guest step. Add only. 'bring-in' | 'skip'.
			$externalMode = 'skip'
			$externalSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
			if (-not $isRemove) {
				$accepted = Get-AcceptedDomainList
				$ext = @($members | Where-Object { Test-IsExternalAddress $_ $accepted })
				foreach ($e in $ext) { [void]$externalSet.Add($e) }
				if ($ext.Count -gt 0) {
					$plural = if ($ext.Count -ne 1) { 'es' } else { '' }
					$shown = if ($ext.Count -gt 15) { (@($ext | Select-Object -First 15) -join "`n  ") + "`n  ...and $($ext.Count - 15) more" } else { $ext -join "`n  " }
					$msg = "$($ext.Count) address$plural aren't in your tenant's domains:`n`n  $shown`n`nBring them in so they can be added? Distribution lists get a mail contact; Teams / Microsoft 365 groups get a guest invite; shared mailboxes can't take external addresses, so those are skipped.`n`nYes = bring them in & add.  No = skip the external ones."
					if (Confirm-YesNo 'External addresses found' $msg '&#xEA88;') { $externalMode = 'bring-in' }
				}
			}
		$progressBar1.Value = 10
		$totalOps = [Math]::Max(1, $targets.Count * $members.Count)   # members across every target
		$opN = 0
		foreach ($target in $targets) {
			$cat = Get-RecipientCategory $target
			$typeName = Get-RecipientTypeName $script:LastRecipientRaw
			if (-not $cat -or $cat -eq 'Other') {
				Write-Host "Skipping '$target' - couldn't determine its type (not a mailbox / list / group)." -ForegroundColor Yellow
				$lines.Add("$target - skipped (not a mailbox, list, or group)")
				continue
			}
			$skipM  = [System.Collections.Generic.List[string]]::new()
			$addedM = [System.Collections.Generic.List[string]]::new()
			$noopM  = [System.Collections.Generic.List[string]]::new()
			$failM  = [System.Collections.Generic.List[string]]::new()
			foreach ($m in $members) {
				try {
					if ($isRemove) {
						switch ($cat) {
							'DistributionList' { Remove-DistributionGroupMember -Identity $target -Member $m -Confirm:$false -ErrorAction Stop }
							'UnifiedGroup'     { Remove-UnifiedGroupLinks -Identity $target -LinkType Members -Links $m -Confirm:$false -ErrorAction Stop }
							'Mailbox'          {
								Remove-MailboxPermission -Identity $target -User $m -AccessRights FullAccess -InheritanceType All -Confirm:$false -ErrorAction Stop
								Remove-RecipientPermission -Identity $target -Trustee $m -AccessRights SendAs -Confirm:$false -ErrorAction Stop
							}
						}
					} else {
						switch ($cat) {
							'DistributionList' { $mm = $m; if ($externalSet.Contains($m)) { if ($externalMode -ne 'bring-in') { throw 'SP_SKIP' }; $mm = Resolve-OrCreateMailContact $m }; Add-DistributionGroupMember -Identity $target -Member $mm -ErrorAction Stop }
							'UnifiedGroup'     { if ($externalSet.Contains($m)) { if ($externalMode -ne 'bring-in') { throw 'SP_SKIP' }; $gid = Resolve-OrInviteGuest $m; Add-GuestToUnifiedGroup $target $gid } else { Add-UnifiedGroupLinks -Identity $target -LinkType Members -Links $m -ErrorAction Stop } }
							'Mailbox'          {
								if ($externalSet.Contains($m)) { throw 'SP_SKIP_MB' }
								Add-MailboxPermission -Identity $target -User $m -AccessRights FullAccess -InheritanceType All -AutoMapping $true -ErrorAction Stop
								Add-RecipientPermission -Identity $target -Trustee $m -AccessRights SendAs -Confirm:$false -ErrorAction Stop
							}
						}
					}
					Write-Host "$m $(if ($isRemove) { 'removed from' } else { 'added to' }) the $typeName `"$target`""
					$counts.done++; $addedM.Add($m)
				} catch {
					$msg = "$($_.Exception.Message)".Trim()
					if ($msg -eq 'SP_SKIP') { Write-Host "${m}: external, skipped on '$target'." -ForegroundColor Yellow; $skipM.Add("$m (external - skipped)"); $counts.skipped++ }
						elseif ($msg -eq 'SP_SKIP_MB') { Write-Host "${m}: external, can't get mailbox access on '$target'." -ForegroundColor Yellow; $skipM.Add("$m (external - no mailbox access)"); $counts.skipped++ }
						elseif (Test-HarmlessMemberError $msg) { Write-Host "${m}: nothing to do on '$target'." -ForegroundColor Yellow; $counts.noop++; $noopM.Add($m) }
					else { Write-Host "Failed: $m on '$target': $msg" -ForegroundColor Red; $counts.failed++; $anyFailed = $true; $failM.Add($m) }
				}
				$opN++; Set-LoopProgress $opN $totalOps   # advance the bar per member so it climbs as it works
			}
			# Name the actual addresses under each target (not just counts) so it's clear WHAT
			# was added/removed where. Indented one level under the target header.
			$detail = @()
			if ($addedM.Count) { $detail += "  $doneWord ($($addedM.Count)): $($addedM -join ', ')" }
			if ($noopM.Count)  { $detail += "  $noopWord ($($noopM.Count)): $($noopM -join ', ')" }
			if ($skipM.Count)  { $detail += "  skipped ($($skipM.Count)): $($skipM -join ', ')" }
				if ($failM.Count)  { $detail += "  failed ($($failM.Count)): $($failM -join ', ')" }
			$lineText = if ($detail.Count) { "$target ($typeName):`n" + ($detail -join "`n") } else { "$target ($typeName): nothing to do" }
			$lines.Add($lineText)
			Write-Host $lineText -ForegroundColor Cyan
		}
		$result.Counts = $counts; $result.Lines = $lines; $result.AnyFailed = $anyFailed; $result.TargetCount = $targets.Count
		$win.Close()
	}.GetNewClosure())

	return $win
}
function Show-PasteMembersDialog {
	param([string]$TargetPrefill = '', [string]$Action = 'add')
	$win = New-PasteMembersDialog -TargetPrefill $TargetPrefill -Action $Action
	[void]$win.ShowDialog()
	$r = $win.Tag
	if ($r -and $r.Lines) {
		# One line per target, naming its actual type (shared mailbox / distribution list /
		# Teams group) so it's clear what was added to / removed from where.
		$body = $r.Lines -join "`n"
		$kind = if ($r.AnyFailed) { 'Warn' } else { 'Info' }
		$title = if ($Action -eq 'remove') { 'Remove complete' } else { 'Add complete' }
		$progressBar1.Value = 100   # finished - fill the bar before the summary pops up
		Show-Notice $title $body $kind
		$progressBar1.Value = 0
	}
}

# Shared shape used by Add/Remove DistributionListMember and UnifiedGroupMember
function New-MemberGroupDialog {
	param([string]$Title, [string]$ActionText, [string]$BulkText, [string]$Icon = '&#xED75;', [switch]$WithPaste)
	$pasteBtn = if ($WithPaste) { '<Button x:Name="PasteBtn" Style="{DynamicResource BtnSecondary}" Content="Paste List..." Margin="0,8,0,0"/>' } else { '' }
	New-StyledDialog -Title $Title -Icon $Icon -BodyXaml @"
<StackPanel Margin="16" Width="340">
	<Border Style="{DynamicResource Card}">
		<StackPanel>
			<TextBlock Text="Single" Style="{DynamicResource H3}"/>
			<Grid Margin="0,12,0,0">
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="70"/><ColumnDefinition Width="*"/>
				</Grid.ColumnDefinitions>
				<Grid.RowDefinitions>
					<RowDefinition Height="Auto"/><RowDefinition Height="Auto"/>
				</Grid.RowDefinitions>
				<TextBlock Text="Member" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
				<TextBox x:Name="MemberInput" Grid.Column="1"/>
				<TextBlock Text="Group" Style="{DynamicResource Dim}" Grid.Row="1" VerticalAlignment="Center" Margin="0,8,0,0"/>
				<TextBox x:Name="GroupInput" Grid.Row="1" Grid.Column="1" Margin="0,8,0,0"/>
			</Grid>
			<Button x:Name="ActionBtn" Style="{DynamicResource BtnPrimary}" Content="$ActionText" Margin="0,14,0,0"/>
		</StackPanel>
	</Border>
	<Border Style="{DynamicResource Card}" Margin="0,12,0,0">
		<StackPanel>
			<TextBlock Text="Bulk" Style="{DynamicResource H3}"/>
			<Button x:Name="OpenTemplateBtn" Style="{DynamicResource BtnSecondary}" Content="Open Template" Margin="0,12,0,0"/>
			<Button x:Name="BulkBtn" Style="{DynamicResource BtnPrimary}" Content="$BulkText" Margin="0,8,0,0"/>
			$pasteBtn
		</StackPanel>
	</Border>
</StackPanel>
"@
}

# ---------------------------------------------------------------------------
function New-AuthenticationPhoneDialog {
	New-StyledDialog -Title 'Add-AuthenticationPhoneMethod' -Icon '&#xEE2F;' -BodyXaml @'
<StackPanel Margin="16" Width="420">
	<Border Style="{DynamicResource Card}">
		<StackPanel>
			<TextBlock Text="Single" Style="{DynamicResource H3}"/>
			<Grid Margin="0,12,0,0">
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="70"/><ColumnDefinition Width="*"/>
				</Grid.ColumnDefinitions>
				<TextBlock Text="Email" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
				<TextBox x:Name="EmailInput" Grid.Column="1"/>
			</Grid>
			<StackPanel Orientation="Horizontal" Margin="70,10,0,0">
				<Button x:Name="ShowCurrentBtn" Style="{DynamicResource BtnSecondary}" Content="Show current" MinWidth="104"
						ToolTip="Show this user's current 2FA methods; click again to hide"/>
				<Button x:Name="RemoveMethodBtn" Style="{DynamicResource BtnSecondary}" Content="Remove a 2FA method" Margin="8,0,0,0"
						ToolTip="Pick one of this user's 2FA methods to remove"/>
			</StackPanel>
			<Border x:Name="PhoneBanner" Margin="0,14,0,0" Padding="10,6" CornerRadius="6" BorderThickness="1">
				<TextBlock x:Name="PhoneBannerText" Style="{DynamicResource Small}" TextWrapping="Wrap"/>
			</Border>
			<!-- Populated by "Show current" with a read-only row per registered 2FA method (any type).
				 Removing is done from the "Remove a 2FA method" picker. Scrolls if there are many. -->
			<ScrollViewer x:Name="MethodsScroller" MaxHeight="220" Margin="0,10,0,0" VerticalScrollBarVisibility="Auto" Visibility="Collapsed">
				<StackPanel x:Name="MethodsPanel"/>
			</ScrollViewer>
			<Grid Margin="0,12,0,0">
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="70"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/>
				</Grid.ColumnDefinitions>
				<TextBlock Text="Phone" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
				<!-- Country indicator OUTSIDE the box, to its left: [flag] [+code]. The box holds only the
					 national number (first digit flush-left); a typed country code is lifted up here. -->
				<StackPanel x:Name="PhoneCcGroup" Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center" Visibility="Collapsed">
					<Border x:Name="FlagPanel" Width="26" Height="18" CornerRadius="3" ClipToBounds="True"
							Background="{DynamicResource PanelBrush}" BorderBrush="{DynamicResource StrokeSoftBrush}" BorderThickness="1">
						<Grid>
							<Image x:Name="FlagImg" Stretch="UniformToFill"/>
							<TextBlock x:Name="FlagChip" FontSize="9" FontWeight="SemiBold" Visibility="Collapsed"
									   Foreground="{DynamicResource TextDimBrush}" HorizontalAlignment="Center" VerticalAlignment="Center"/>
						</Grid>
					</Border>
					<TextBlock x:Name="PhoneCcText" VerticalAlignment="Center" Margin="7,0,9,0" FontWeight="SemiBold"
							   FontSize="13" Foreground="{DynamicResource TextBrush}"/>
				</StackPanel>
				<TextBox x:Name="PhoneInput" Grid.Column="2"/>
			</Grid>
			<TextBlock Text="US/Canada: just the 10 digits. Other countries: type the country code (e.g. +44) - it moves up next to the flag." Style="{DynamicResource Small}" Margin="70,6,0,0" TextWrapping="Wrap"/>
			<StackPanel Orientation="Horizontal" Margin="70,10,0,0">
				<RadioButton x:Name="TypeMobileChip" Style="{DynamicResource Chip}" GroupName="PhoneType" Content="Mobile" IsChecked="True"/>
				<RadioButton x:Name="TypeAltChip" Style="{DynamicResource Chip}" GroupName="PhoneType" Content="Alternate mobile" Margin="8,0,0,0"/>
			</StackPanel>
			<Button x:Name="AddPhoneBtn" Style="{DynamicResource BtnPrimary}" Content="Add Phone Number" Margin="0,14,0,0"/>
		</StackPanel>
	</Border>
	<Border Style="{DynamicResource Card}" Margin="0,12,0,0">
		<StackPanel>
			<TextBlock Text="Bulk" Style="{DynamicResource H3}"/>
			<Button x:Name="OpenTemplateBtn" Style="{DynamicResource BtnSecondary}" Content="Open Template" Margin="0,12,0,0"/>
			<Button x:Name="AddBulkPhoneBtn" Style="{DynamicResource BtnPrimary}" Content="Add Phone Numbers" Margin="0,8,0,0"/>
		</StackPanel>
	</Border>
</StackPanel>
'@
}

# Picker to remove ONE 2FA method: a single list you select from, instead of a Remove button on
# every row. Builder (XAML only) + the show/remove logic are split so the dialog can be screenshotted.
function New-RemoveMethodDialog {
	New-StyledDialog -Title 'Remove a 2FA method' -Icon '&#xEE2F;' -BodyXaml @'
<StackPanel Margin="16" Width="440">
	<Border Style="{DynamicResource Card}">
		<StackPanel>
			<TextBlock Text="Remove a 2FA method" Style="{DynamicResource H3}"/>
			<TextBlock x:Name="PickSub" Style="{DynamicResource Small}" Margin="0,4,0,0" TextWrapping="Wrap"
					   Text="Select a method, then click Remove. This can't be undone."/>
			<ListBox x:Name="PickList" Margin="0,12,0,0" MaxHeight="300" Background="Transparent" BorderThickness="0"
					 ScrollViewer.HorizontalScrollBarVisibility="Disabled"/>
			<TextBlock x:Name="PickEmpty" Style="{DynamicResource Dim}" Margin="2,10,0,0" Visibility="Collapsed"
					   Text="This user has no removable 2FA methods."/>
			<Grid Margin="0,14,0,0">
				<Button x:Name="PickCloseBtn" Style="{DynamicResource BtnSecondary}" Content="Close" HorizontalAlignment="Left" MinWidth="90"/>
				<Button x:Name="PickRemoveBtn" Style="{DynamicResource BtnDanger}" Content="Remove" HorizontalAlignment="Right" MinWidth="110"/>
			</Grid>
		</StackPanel>
	</Border>
</StackPanel>
'@
}

# Show the picker for $User's removable 2FA methods; remove the selected one(s). Returns $true if at
# least one method was removed (so the caller can refresh its view). Reads live methods from Graph.
function Show-RemoveMethodPicker([string]$User) {
	$state = [pscustomobject]@{ Removed = $false }
	$win = New-RemoveMethodDialog
	$list = $win.FindName('PickList'); $empty = $win.FindName('PickEmpty')
	$removeBtn = $win.FindName('PickRemoveBtn'); $closeBtn = $win.FindName('PickCloseBtn')

	$reload = {
		$list.Items.Clear()
		$infos = @()
		try { $infos = @(Get-MgUserAuthenticationMethod -UserId $User -ErrorAction Stop | ForEach-Object { Get-AuthMethodInfo $_ } | Where-Object { $_.Removable -and $_.Kind -ne 'Password' }) }
		catch { Show-Notice 'Could not read methods' "Couldn't read $User's sign-in methods: $($_.Exception.Message)" 'Error'; return }
		foreach ($info in ($infos | Sort-Object @{ Expression = { if ($_.Type -like '*phone*') { 0 } else { 5 } } }, Kind, Detail)) {
			$it = New-Object System.Windows.Controls.ListBoxItem
			$it.Content = (New-AuthMethodRow $info).Element
			$it.Tag = $info
			$it.Padding = '0'
			[void]$list.Items.Add($it)
		}
		$empty.Visibility = if ($infos.Count) { 'Collapsed' } else { 'Visible' }
		$removeBtn.IsEnabled = [bool]$infos.Count
	}
	& $reload

	$removeBtn.Add_Click({
		$sel = $list.SelectedItem
		if (-not $sel) { Show-Notice 'Select a method' 'Pick which 2FA method to remove first.' 'Info'; return }
		$info = $sel.Tag
		$label = ("$($info.Kind) $($info.Detail)").Trim()
		if (-not (Confirm-YesNo 'Remove 2FA method' "Remove `"$label`" from $User? They won't be able to use it for sign-in / MFA anymore.")) { return }
		try { Remove-OneAuthMethod $User $info.Type $info.Id; Write-Host "Removed $label from $User." -ForegroundColor Green; $state.Removed = $true }
		catch { Write-Host "Couldn't remove $label`: $($_.Exception.Message)" -ForegroundColor Red; Show-Notice 'Remove failed' "$($_.Exception.Message)" 'Error'; return }
		& $reload
	})
	$closeBtn.Add_Click({ [System.Windows.Window]::GetWindow($closeBtn).Close() })
	[void]$win.ShowDialog()
	return $state.Removed
}

function Add-AuthenticationPhoneMethod {
	Start-Transcript -IncludeInvocationHeader -Path ".\Logs\Add-AuthenticationPhoneMethod.txt"
	Write-Host "Running Add-2FA script..."
	$progressBar1.Value = 10
	function OnAddPhoneButtonClick {
		$progressBar1.Value = 10
		$user = $emailInput.Text
		$phoneNumber = Get-AcPhoneValue $phoneCc $phoneInput   # combines the +code shown by the flag with the national number in the box
		$ptype = if ($typeAltChip.IsChecked -eq $true) { 'alternateMobile' } else { 'mobile' }   # a user's primary mobile can hold one number; extra numbers go in as alternateMobile
		$progressBar1.Value = 40
		New-MgUserAuthenticationPhoneMethod -UserId $user -phoneType $ptype -phoneNumber $phoneNumber
		Write-Host "Added $phoneNumber ($(Get-PhoneTypeLabel $ptype)) to $user."
		$progressBar1.Value = 80
		CheckForErrors
		OperationComplete
	}
	function OnOpenTemplateButtonClick {
		Write-Host "Open template button clicked."
		$progressBar1.Value = 10
		Invoke-Item ".\Templates\Add-AuthenticationPhoneMethod.csv"
		$progressBar1.Value = 100
		CheckForErrors
		$progressBar1.Value = 0
	}
	function OnAddBulkPhoneButtonClick {
		Write-Host "AddBulkPhone button clicked."
		$progressBar1.Value = 10
		Import-Csv -Path ".\Templates\Add-AuthenticationPhoneMethod.csv" | ForEach-Object {
			Step-Progress   # keep the bar climbing per item
			$progressBar1.Value = 20
			$user = $_.Email
			$phoneNumber = Format-PhoneForMfa $_.Phone   # same normalization as the single add
			$progressBar1.Value = 40
			New-MgUserAuthenticationPhoneMethod -UserId $user -phoneType "mobile" -phoneNumber $phoneNumber
			$progressBar1.Value = 80
			Write-Host "Added $phoneNumber to $user."
		}
		CheckForErrors
		OperationComplete
	}

	# Banner above the phone box mirrors the auto-reply pattern: it flips between the user's CURRENT
	# registered 2FA numbers (loaded by Show current, amber) and the NEW number you're adding
	# (accent). $PmSuppress silences the flip while Show current writes the banner programmatically.
	$script:PmShowingCurrent = $false
	$script:PmSuppress = $false
	function Set-PhoneBannerNew([string]$msg = 'NEW - the number you type below is ADDED to this user (existing 2FA numbers are kept).') {
		$phoneBannerText.Text = $msg
		$phoneBanner.SetResourceReference([System.Windows.Controls.Border]::BorderBrushProperty, 'AccentBrush')
		$phoneBannerText.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, 'AccentBrush')
		$script:PmShowingCurrent = $false
		if ($showCurrentBtn) { $showCurrentBtn.Content = 'Show current' }
	}
	function Set-PhoneBannerCurrent([string]$msg) {
		$phoneBannerText.Text = $msg
		$phoneBanner.SetResourceReference([System.Windows.Controls.Border]::BorderBrushProperty, 'WarnBrush')
		$phoneBannerText.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, 'WarnBrush')
		$script:PmShowingCurrent = $true
		if ($showCurrentBtn) { $showCurrentBtn.Content = 'Clear preview' }
	}

	$scriptForm8 = New-AuthenticationPhoneDialog
	$emailInput = $scriptForm8.FindName('EmailInput')
	Enable-RecipientAutocomplete $emailInput 'User'
	$phoneInput = $scriptForm8.FindName('PhoneInput')
	$typeMobileChip = $scriptForm8.FindName('TypeMobileChip')
	$typeAltChip = $scriptForm8.FindName('TypeAltChip')
	$phoneBanner = $scriptForm8.FindName('PhoneBanner')
	$phoneBannerText = $scriptForm8.FindName('PhoneBannerText')
	$showCurrentBtn = $scriptForm8.FindName('ShowCurrentBtn')
	Set-PhoneBannerNew
	# Country indicator (flag + "+code") shown OUTSIDE the box, to its left; the box keeps only the
	# national number. Updated live as you type - US flag/+1 for a bare US number, the right country
	# once a code is typed (the code is then lifted out of the box up next to the flag).
	$phoneCc = [pscustomobject]@{ Group = $scriptForm8.FindName('PhoneCcGroup'); Img = $scriptForm8.FindName('FlagImg'); Chip = $scriptForm8.FindName('FlagChip'); Code = $scriptForm8.FindName('PhoneCcText') }
	Update-AcPhoneField $phoneCc $phoneInput
	# Typing a number means you're adding a new one - flip the banner back from a current-numbers preview.
	$phoneInput.Add_TextChanged({
		if ($script:PhoneFmtBusy) { return }
		Update-AcPhoneField $phoneCc $phoneInput
		if (-not $script:PmSuppress -and $script:PmShowingCurrent) { Set-PhoneBannerNew }
	})

	$methodsScroller = $scriptForm8.FindName('MethodsScroller')
	$methodsPanel = $scriptForm8.FindName('MethodsPanel')

	# Build / refresh the READ-ONLY list of the user's current 2FA methods (any type, password
	# excluded - it isn't 2FA). Removing is done from the "Remove a 2FA method" picker, so no
	# per-row buttons. Returns $true if any exist, $false if none, $null on a read error / no user.
	$refreshMethods = {
		$u = $emailInput.Text.Trim()
		$methodsPanel.Children.Clear()
		if (-not $u) { return $null }
		try { $all = @(Get-MgUserAuthenticationMethod -UserId $u -ErrorAction Stop) }
		catch { Write-Host "Could not read sign-in methods for $u : $($_.Exception.Message)" -ForegroundColor Red; return $null }
		$infos = @($all | ForEach-Object { Get-AuthMethodInfo $_ } | Where-Object { $_.Kind -ne 'Password' })
		foreach ($info in ($infos | Sort-Object @{ Expression = { if ($_.Type -like '*phone*') { 0 } else { 5 } } }, Kind, Detail)) {
			[void]$methodsPanel.Children.Add((New-AuthMethodRow $info).Element)
		}
		# default the new-number type to Alternate mobile if a primary mobile already exists
		if ($typeAltChip -and ($infos | Where-Object { $_.Kind -eq 'Phone (Mobile)' })) { $typeAltChip.IsChecked = $true }
		return [bool]$infos.Count
	}

    # Load + show the user's CURRENT 2FA methods (read-only list). Shared by the auto-load (on
    # entering a user) and the manual button.
    function Show-CurrentMethods([string]$user) {
        if (-not $user) { return }
        Write-Host "Fetching current sign-in methods for $user..."
        $progressBar1.Value = 20
        $any = & $refreshMethods
        $progressBar1.Value = 60
        if ($null -eq $any) { $progressBar1.Value = 0; return }   # read failed / no user (already logged)
        if (-not $any) {
            $methodsScroller.Visibility = 'Collapsed'
            Set-PhoneBannerNew "No 2FA methods are registered for $user yet - add a phone number below."
            Write-Host "No 2FA methods on $user." -ForegroundColor Cyan
        } else {
            $methodsScroller.Visibility = 'Visible'
            Set-PhoneBannerCurrent "CURRENT 2FA methods for ${user}. Use ""Remove a 2FA method"" to remove one, or add a new phone number below."
            Write-Host "Loaded current sign-in methods for $user." -ForegroundColor Green
        }
        CheckForErrors
        $progressBar1.Value = 0
    }

    # The button now just toggles the list - the current methods load automatically once you enter a
    # user. Re-click hides them (and switches the box back to adding a NEW number).
    $showCurrentBtn.Add_Click({
        if ($script:PmShowingCurrent) { $methodsScroller.Visibility = 'Collapsed'; $methodsPanel.Children.Clear(); Set-PhoneBannerNew; Write-Host 'Closed the list - the box adds a NEW number.' -ForegroundColor Cyan; return }
        $user = $emailInput.Text.Trim()
        if (-not $user) { Write-Host 'Enter a user email address first.' -ForegroundColor Yellow; return }
        $script:PmLastLoaded = $user
        Show-CurrentMethods $user
    })

    # Auto-load the user's current 2FA methods the moment a full address is entered (typed or picked).
    # Debounced; only when connected; skips a repeat of the same user.
    $script:PmLastLoaded = ''
    $pmAutoTimer = New-Object System.Windows.Threading.DispatcherTimer
    $pmAutoTimer.Interval = [TimeSpan]::FromMilliseconds(450)
    $pmAutoTimer.Add_Tick({
        $pmAutoTimer.Stop()
        $u = $emailInput.Text.Trim()
        if (-not (Test-AcIsCompleteEmail $u)) { return }
        if ($u -eq $script:PmLastLoaded) { return }
        if (-not (Get-MgContext)) { return }
        $script:PmLastLoaded = $u
        Show-CurrentMethods $u
    })
    $emailInput.Add_TextChanged({ $pmAutoTimer.Stop(); $pmAutoTimer.Start() })


	# "Remove a 2FA method": open the picker to choose one of the user's methods to remove.
	$scriptForm8.FindName('RemoveMethodBtn').Add_Click({
		$user = $emailInput.Text.Trim()
		if (-not $user) { Write-Host 'Enter a user email address first.' -ForegroundColor Yellow; return }
		$changed = Show-RemoveMethodPicker $user
		if ($changed -and $script:PmShowingCurrent) { & $refreshMethods | Out-Null }   # refresh the visible list
	})

	$scriptForm8.FindName('AddPhoneBtn').Add_Click({ OnAddPhoneButtonClick })
	$scriptForm8.FindName('OpenTemplateBtn').Add_Click({ OnOpenTemplateButtonClick })
	$scriptForm8.FindName('AddBulkPhoneBtn').Add_Click({ OnAddBulkPhoneButtonClick })

	Write-Host "Loaded ScriptForm8."
	$progressBar1.Value = 0

	[void]$scriptForm8.ShowDialog()

	Stop-Transcript
}

# ---------------------------------------------------------------------------
# Exchange stores auto-reply messages as HTML; convert to readable plain text so an
# existing reply can be shown in the plain-text boxes.
function ConvertFrom-AutoReplyHtml([string]$Html) {
	if (-not $Html) { return '' }
	$t = $Html -replace '(?is)<br\s*/?>', "`n" -replace '(?is)</p\s*>', "`n" -replace '(?is)<[^>]+>', ''
	$t = [System.Net.WebUtility]::HtmlDecode($t)
	return $t.Trim()
}

function New-AutoReplyDialog {
	$win = New-StyledDialog -Title 'Add-AutoReply' -Icon '&#xEBBC;' -BodyXaml @'
<StackPanel Margin="16" Width="520">
	<Border Style="{DynamicResource Card}">
		<StackPanel>
			<Grid>
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="70"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/>
				</Grid.ColumnDefinitions>
				<TextBlock Text="Mailbox" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
				<TextBox x:Name="EmailInputBox" Grid.Column="1"/>
				<Button x:Name="ShowCurrentBtn" Grid.Column="2" Style="{DynamicResource BtnSecondary}" Content="Show current" Margin="8,0,0,0" MinWidth="104"
						ToolTip="Load the mailbox's current auto-reply, then click again to clear it"/>
			</Grid>
			<Border x:Name="ReplyBanner" Margin="0,14,0,0" Padding="10,6" CornerRadius="6" BorderThickness="1">
				<TextBlock x:Name="ReplyBannerText" Style="{DynamicResource Small}" TextWrapping="Wrap"/>
			</Border>
			<Grid Margin="0,10,0,0">
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="*"/><ColumnDefinition Width="12"/><ColumnDefinition Width="*"/>
				</Grid.ColumnDefinitions>
				<StackPanel Grid.Column="0">
					<TextBlock Text="Internal Auto-Reply" Style="{DynamicResource Dim}"/>
					<TextBox x:Name="InternalReplyBox" Style="{DynamicResource TextArea}" Height="170" Margin="0,6,0,0"/>
				</StackPanel>
				<StackPanel Grid.Column="2">
					<TextBlock Text="External Auto-Reply" Style="{DynamicResource Dim}"/>
					<TextBox x:Name="ExternalReplyBox" Style="{DynamicResource TextArea}" Height="170" Margin="0,6,0,0"/>
				</StackPanel>
			</Grid>
			<CheckBox x:Name="MatchRepliesCheck" Content="Match Replies" IsChecked="True" Margin="0,12,0,0"/>
			<Border Style="{DynamicResource Divider}"/>
			<CheckBox x:Name="UseScheduleCheck" Content="Use Start and End Date"/>
			<Grid Margin="0,10,0,0">
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="70"/><ColumnDefinition Width="*"/>
				</Grid.ColumnDefinitions>
				<Grid.RowDefinitions>
					<RowDefinition Height="Auto"/><RowDefinition Height="Auto"/>
				</Grid.RowDefinitions>
				<TextBlock Text="Start" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
				<DatePicker x:Name="StartDatePicker" Grid.Column="1" IsEnabled="False"/>
				<TextBlock Text="End" Style="{DynamicResource Dim}" Grid.Row="1" VerticalAlignment="Center" Margin="0,8,0,0"/>
				<DatePicker x:Name="EndDatePicker" Grid.Row="1" Grid.Column="1" IsEnabled="False" Margin="0,8,0,0"/>
			</Grid>
			<Button x:Name="ConfirmBtn" Style="{DynamicResource BtnPrimary}" Content="Confirm" Margin="0,16,0,0"/>
		</StackPanel>
	</Border>
</StackPanel>
'@
	$win.FindName('StartDatePicker').SelectedDate = [DateTime]::Now
	$win.FindName('EndDatePicker').SelectedDate = [DateTime]::Now
	return $win
}

function Add-AutoReply {
	Start-Transcript -IncludeInvocationHeader -Path ".\Logs\Add-AutoReply.txt"
	Write-Host "Running Add-AutoReply script..."

	function OnConfirmAutoReplyButtonClick {
		$progressBar1.Value = 20
		Write-Host "ConfirmAutoReplyButton clicked, adding auto-replies..."
		$internalMessage = $internalReplyTextBox.Text
		$externalMessage = $externalReplyTextBox.Text
		$mailbox = $emailInputBox.Text

		if ($useScheduleCheckBox.IsChecked -eq $true) {
			Write-Host "Use schedule is checked, creating auto-reply with schedule..."
			$startTime = $startDatePicker.SelectedDate
			$endTime = $endDatePicker.SelectedDate
			Set-MailboxAutoReplyConfiguration -Identity $mailbox -AutoReplyState Scheduled -StartTime $startTime -EndTime $endTime -InternalMessage $internalMessage -ExternalMessage $externalMessage -ExternalAudience All -Confirm:$false
			$progressBar1.Value = 50
		}
		else {
			Write-Host "Use schedule isn't checked, creating auto-reply..."
			Set-MailboxAutoReplyConfiguration -Identity $mailbox -AutoReplyState Enabled -InternalMessage $internalMessage -ExternalMessage $externalMessage -ExternalAudience All -Confirm:$false
			$progressBar1.Value = 50
		}
		CheckForErrors
		OperationComplete
	}

	# Banner above the reply boxes makes it obvious whether they hold the mailbox's CURRENT
	# auto-reply (loaded by Show current, amber) or the NEW text you're composing (accent). It
	# flips to NEW the moment you edit. $ArSuppress silences the flip while Show current loads
	# text programmatically.
	$script:ArShowingCurrent = $false
	$script:ArSuppress = $false
	function Set-BannerNew([string]$msg = 'NEW auto-reply - this is what will be set on the mailbox when you click Confirm.') {
		$replyBannerText.Text = $msg
		$replyBanner.SetResourceReference([System.Windows.Controls.Border]::BorderBrushProperty, 'AccentBrush')
		$replyBannerText.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, 'AccentBrush')
		$script:ArShowingCurrent = $false
		if ($showCurrentBtn) { $showCurrentBtn.Content = 'Show current' }
	}
	function Set-BannerCurrent {
		$replyBannerText.Text = 'PREVIEW - this is the auto-reply CURRENTLY on the mailbox. Edit it to compose a new one.'
		$replyBanner.SetResourceReference([System.Windows.Controls.Border]::BorderBrushProperty, 'WarnBrush')
		$replyBannerText.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, 'WarnBrush')
		$script:ArShowingCurrent = $true
		if ($showCurrentBtn) { $showCurrentBtn.Content = 'Clear preview' }
	}

	$addAutoReplyForm = New-AutoReplyDialog
	$emailInputBox = $addAutoReplyForm.FindName('EmailInputBox')
	Enable-RecipientAutocomplete $emailInputBox 'Mailbox'
	$internalReplyTextBox = $addAutoReplyForm.FindName('InternalReplyBox')
	$externalReplyTextBox = $addAutoReplyForm.FindName('ExternalReplyBox')
	$matchRepliesCheckBox = $addAutoReplyForm.FindName('MatchRepliesCheck')
	$useScheduleCheckBox = $addAutoReplyForm.FindName('UseScheduleCheck')
	$startDatePicker = $addAutoReplyForm.FindName('StartDatePicker')
	$endDatePicker = $addAutoReplyForm.FindName('EndDatePicker')
	$startDatePicker.SelectedDate = [DateTime]::Now
	$endDatePicker.SelectedDate = [DateTime]::Now
	$replyBanner = $addAutoReplyForm.FindName('ReplyBanner')
	$replyBannerText = $addAutoReplyForm.FindName('ReplyBannerText')
	$showCurrentBtn = $addAutoReplyForm.FindName('ShowCurrentBtn')
	Set-BannerNew

	$internalReplyTextBox.Add_TextChanged({
		if ($matchRepliesCheckBox.IsChecked -eq $true) { $externalReplyTextBox.Text = $internalReplyTextBox.Text }
		if (-not $script:ArSuppress -and $script:ArShowingCurrent) { Set-BannerNew }
	})
	$externalReplyTextBox.Add_TextChanged({
		if ($matchRepliesCheckBox.IsChecked -eq $true) { $internalReplyTextBox.Text = $externalReplyTextBox.Text }
		if (-not $script:ArSuppress -and $script:ArShowingCurrent) { Set-BannerNew }
	})
	$onSchedule = {
		if ($useScheduleCheckBox.IsChecked -eq $true) {
			$startDatePicker.IsEnabled = $true
			$endDatePicker.IsEnabled = $true
		}
		else {
			$startDatePicker.IsEnabled = $false
			$endDatePicker.IsEnabled = $false
		}
	}
	$useScheduleCheckBox.Add_Checked($onSchedule)
	$useScheduleCheckBox.Add_Unchecked($onSchedule)

    # Load + preview the mailbox's CURRENT auto-reply. The amber banner makes clear it's the current
    # one; editing it flips the banner to NEW. Shared by the auto-load (on entering an address) and
    # the manual button.
    function Show-CurrentReply([string]$mailbox) {
        if (-not $mailbox) { return }
        Write-Host "Fetching current auto-reply for $mailbox..."
        $progressBar1.Value = 20
        try { $cfg = Get-MailboxAutoReplyConfiguration -Identity $mailbox -ErrorAction Stop }
        catch { Write-Host "Could not read auto-reply for $mailbox : $($_.Exception.Message)" -ForegroundColor Red; $progressBar1.Value = 0; return }
        $progressBar1.Value = 60
        $state = [string]$cfg.AutoReplyState
        $script:ArSuppress = $true
        if (-not $state -or $state -eq 'Disabled') {
            $internalReplyTextBox.Text = ''
            $externalReplyTextBox.Text = ''
            $script:ArSuppress = $false
            Set-BannerNew 'No auto-reply is currently set on this mailbox - compose a new one below (set on Confirm).'
            Write-Host "No auto-reply is currently set on $mailbox (state: $state)." -ForegroundColor Cyan
        } else {
            $intText = ConvertFrom-AutoReplyHtml ([string]$cfg.InternalMessage)
            $extText = ConvertFrom-AutoReplyHtml ([string]$cfg.ExternalMessage)
            if ($intText -ne $extText) { $matchRepliesCheckBox.IsChecked = $false }
            $internalReplyTextBox.Text = $intText
            $externalReplyTextBox.Text = $extText
            if ($state -eq 'Scheduled') {
                $useScheduleCheckBox.IsChecked = $true
                if ($cfg.StartTime) { try { $startDatePicker.SelectedDate = [datetime]$cfg.StartTime } catch {} }
                if ($cfg.EndTime)   { try { $endDatePicker.SelectedDate   = [datetime]$cfg.EndTime }   catch {} }
            }
            $script:ArSuppress = $false
            Set-BannerCurrent
            Write-Host "Current auto-reply on $mailbox is '$state' - loaded for REVIEW (edit to replace)." -ForegroundColor Green
        }
        CheckForErrors
        $progressBar1.Value = 0
    }

    # The button is now a manual refresh / clear toggle - the current reply loads automatically once
    # you enter an address, but this still lets you reload it, or clear the preview to start fresh.
    $showCurrentBtn.Add_Click({
        if ($script:ArShowingCurrent) {
            $script:ArSuppress = $true
            $internalReplyTextBox.Text = ''
            $externalReplyTextBox.Text = ''
            $script:ArSuppress = $false
            Set-BannerNew
            Write-Host "Cleared the preview - compose a new auto-reply." -ForegroundColor Cyan
            return
        }
        $mailbox = $emailInputBox.Text.Trim()
        if (-not $mailbox) { Write-Host "Enter a mailbox email address first." -ForegroundColor Yellow; return }
        $script:ArLastLoaded = $mailbox
        Show-CurrentReply $mailbox
    })

    # Auto-load the CURRENT auto-reply the moment a full address is entered (typed or picked from the
    # dropdown) - no need to click Show current. Debounced so it doesn't fire mid-typing, only fires
    # when connected, and never overwrites a reply you've already started composing.
    $script:ArLastLoaded = ''
    $arAutoTimer = New-Object System.Windows.Threading.DispatcherTimer
    $arAutoTimer.Interval = [TimeSpan]::FromMilliseconds(450)
    $arAutoTimer.Add_Tick({
        $arAutoTimer.Stop()
        $mbx = $emailInputBox.Text.Trim()
        if (-not (Test-AcIsCompleteEmail $mbx)) { return }
        if ($mbx -eq $script:ArLastLoaded) { return }
        if (-not (Get-MgContext)) { return }
        if (-not $script:ArShowingCurrent -and ("$($internalReplyTextBox.Text)".Trim() -or "$($externalReplyTextBox.Text)".Trim())) { return }
        $script:ArLastLoaded = $mbx
        Show-CurrentReply $mbx
    })
    $emailInputBox.Add_TextChanged({ $arAutoTimer.Stop(); $arAutoTimer.Start() })


	$addAutoReplyForm.FindName('ConfirmBtn').Add_Click({ OnConfirmAutoReplyButtonClick })

	[void]$addAutoReplyForm.ShowDialog()

	Stop-Transcript
}

# ---------------------------------------------------------------------------
function New-AddContactsDialog {
    New-StyledDialog -Title 'Add contacts & guests' -Icon '&#xE249;' -HelpKey 'Add-Contacts' -BodyXaml @'
<StackPanel Margin="16" Width="340">
    <Border Style="{DynamicResource Card}">
        <StackPanel>
            <TextBlock Text="What do you want to do?" Style="{DynamicResource H3}"/>
            <StackPanel Orientation="Horizontal" Margin="0,10,0,0">
                <RadioButton x:Name="AddContactChip" Style="{DynamicResource Chip}" GroupName="ContactMode" Content="Add contact" IsChecked="True"/>
                <RadioButton x:Name="GuestInviteChip" Style="{DynamicResource Chip}" GroupName="ContactMode" Content="Invite guest" Margin="8,0,0,0"/>
            </StackPanel>
            <TextBlock x:Name="ModeHint" Style="{DynamicResource Small}" TextWrapping="Wrap" Margin="0,10,0,0" Text="Adds the person to your address book (Global Address List) so staff can find and email them, and you can add them to distribution lists. No email is sent to them. The name is optional."/>
        </StackPanel>
    </Border>
    <Border Style="{DynamicResource Card}" Margin="0,12,0,0">
        <StackPanel>
            <TextBlock Text="Single" Style="{DynamicResource H3}"/>
            <Grid Margin="0,12,0,0">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="92"/><ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                <Grid.RowDefinitions>
                    <RowDefinition Height="Auto"/><RowDefinition Height="Auto"/>
                </Grid.RowDefinitions>
                <TextBlock x:Name="NameLabel" Text="Name (optional)" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
                <TextBox x:Name="NameInput" Grid.Column="1"/>
                <TextBlock Text="Email" Style="{DynamicResource Dim}" Grid.Row="1" VerticalAlignment="Center" Margin="0,8,0,0"/>
                <TextBox x:Name="EmailInput" Grid.Row="1" Grid.Column="1" Margin="0,8,0,0"/>
            </Grid>
            <Button x:Name="AddContactBtn" Style="{DynamicResource BtnPrimary}" Content="Add contact" Margin="0,14,0,0"/>
        </StackPanel>
    </Border>
    <Border Style="{DynamicResource Card}" Margin="0,12,0,0">
        <StackPanel>
            <TextBlock Text="Bulk" Style="{DynamicResource H3}"/>
            <Button x:Name="OpenTemplateBtn" Style="{DynamicResource BtnSecondary}" Content="Open Template" Margin="0,12,0,0"/>
            <Button x:Name="BulkContactsBtn" Style="{DynamicResource BtnPrimary}" Content="Add contacts" Margin="0,8,0,0"/>
        </StackPanel>
    </Border>
</StackPanel>
'@
}

function Add-Contacts {
    Start-Transcript -IncludeInvocationHeader -Path ".\Logs\Add-Contacts.txt"
    Write-Host "Running Add-Contacts script..."
    UpdateProgressBar(10)
    # Mode 0 = add a mail contact (address-book entry, name optional, no email to them).
    # Mode 1 = invite the person as a B2B guest (sends an invitation email).
    $addContactsMode = New-Object PSObject -Property @{ Value = 0 }

    # Create a mail contact. A name is optional - with one it's "Jane Vendor", without it the address
    # is used as the name. No email is ever sent to the person.
    function New-OneMailContact([string]$email, [string]$displayName) {
        $em = "$email".Trim(); if (-not $em) { return }
        $dn = "$displayName".Trim()
        if ($dn) {
            $split = $dn -Split ' '
            New-MailContact -Name $dn -DisplayName $dn -ExternalEmailAddress $em -FirstName $split[0] -LastName $split[1] -ErrorAction Stop
        } else {
            New-MailContact -Name $em -ExternalEmailAddress $em -ErrorAction Stop
        }
    }

    # Invite an external person as a B2B guest - this actually SENDS them an invitation email and
    # creates a guest account (unlike the contact mode, which only makes an address-book entry).
    # Skips if they're already in the directory so it never double-invites. $displayName is optional.
    function Invoke-GuestInvite([string]$email, [string]$displayName) {
        $e = "$email".Trim()
        if (-not $e) { return }
        $existing = $null
        try { $existing = Get-MgUser -Filter "mail eq '$e'" -ErrorAction Stop | Select-Object -First 1 } catch {}
        if (-not $existing) { try { $existing = Get-MgUser -Filter "otherMails/any(x:x eq '$e')" -ErrorAction Stop | Select-Object -First 1 } catch {} }
        if ($existing) { Write-Host "$e is already in the directory - no invite sent." -ForegroundColor Yellow; return }
        $p = @{ InvitedUserEmailAddress = $e; InviteRedirectUrl = 'https://myapps.microsoft.com'; SendInvitationMessage = $true; ErrorAction = 'Stop' }
        if ("$displayName".Trim()) { $p.InvitedUserDisplayName = "$displayName".Trim() }
        $inv = New-MgInvitation @p
        Write-Host "Invited $e as a guest - they'll get an invitation email." -ForegroundColor Cyan
    }

    function OnAddContactButtonClick {
        Write-Host "AddContact button clicked."
        UpdateProgressBar(10)
        $email = $emailInputBox.Text
        $name = $nameInputBox.Text
        UpdateProgressBar(50)
        if ($addContactsMode.Value -eq 0) {
            New-OneMailContact $email $name
        } elseif ($addContactsMode.Value -eq 1) {
            Invoke-GuestInvite $email $name
        }
        UpdateProgressBar(90)
        CheckForErrors
        OperationComplete
    }
    function OnBulkContactsButtonClick {
        Write-Host "AddContactsBulk button clicked."
        $progressBar1.Value = 5
        if ($addContactsMode.Value -eq 0) {
            # Contacts bulk: CSV with DisplayName (optional) + EmailAddress.
            Import-Csv ".\Templates\Add-Contacts.csv" | ForEach-Object {
                Step-Progress   # keep the bar climbing per item
                New-OneMailContact $_.EmailAddress $_.DisplayName
            }
        } elseif ($addContactsMode.Value -eq 1) {
            # Guest bulk: a plain list of one email address per line.
            Get-Content ".\Templates\Add-Contacts.txt" | ForEach-Object {
                Step-Progress   # keep the bar climbing per item
                $e = "$_".Trim(); if (-not $e) { return }
                Invoke-GuestInvite $e ''
            }
        }
        CheckForErrors
        OperationComplete
    }
    function OnOpenTemplateButtonClick {
        Write-Host "OpenTemplate button clicked."
        UpdateProgressBar(10)
        if ($addContactsMode.Value -eq 0) {
            Invoke-Item ".\Templates\Add-Contacts.csv"
        } else {
            if (-not (Test-Path ".\Templates\Add-Contacts.txt")) { "" | Out-File ".\Templates\Add-Contacts.txt" -Encoding UTF8 }
            Invoke-Item ".\Templates\Add-Contacts.txt"
        }
        UpdateProgressBar(80)
        CheckForErrors
        UpdateProgressBar(0)
    }
    function OnRadioButtonSelect {
        if ($addContactRadioButton.IsChecked -eq $true) {
            $addContactsMode.Value = 0
            $modeHint.Text = 'Adds the person to your address book (Global Address List) so staff can find and email them, and you can add them to distribution lists. No email is sent to them. The name is optional.'
            $addContactButton.Content = 'Add contact'; $bulkContactsButton.Content = 'Add contacts'
        } elseif ($guestInviteRadioButton.IsChecked -eq $true) {
            $addContactsMode.Value = 1
            $modeHint.Text = 'Invites the person as a guest - they GET an invitation email and can be given access to Teams / Microsoft 365 groups, SharePoint and apps. You can enter just the email; the name is optional.'
            $addContactButton.Content = 'Send guest invite'; $bulkContactsButton.Content = 'Send invites'
        }
        Write-Host "Mode = $($addContactsMode.Value)"
        CheckForErrors
    }

    $scriptForm10 = New-AddContactsDialog
    $addContactRadioButton = $scriptForm10.FindName('AddContactChip')
    $guestInviteRadioButton = $scriptForm10.FindName('GuestInviteChip')
    $modeHint = $scriptForm10.FindName('ModeHint')
    $nameInputBox = $scriptForm10.FindName('NameInput')
    $emailInputBox = $scriptForm10.FindName('EmailInput')
    $addContactButton = $scriptForm10.FindName('AddContactBtn')
    $bulkContactsButton = $scriptForm10.FindName('BulkContactsBtn')
    $addContactRadioButton.Add_Checked({ OnRadioButtonSelect })
    $guestInviteRadioButton.Add_Checked({ OnRadioButtonSelect })
    $addContactButton.Add_Click({ OnAddContactButtonClick })
    $scriptForm10.FindName('OpenTemplateBtn').Add_Click({ OnOpenTemplateButtonClick })
    $bulkContactsButton.Add_Click({ OnBulkContactsButtonClick })

    Write-Host "Loaded ScriptForm10."
    UpdateProgressBar(0)

    [void]$scriptForm10.ShowDialog()

    Stop-Transcript
}

# ---------------------------------------------------------------------------
function Add-DistributionListMember {
	Start-Transcript -IncludeInvocationHeader -Path ".\Logs\Add-DistributionListMember.txt"
	Write-Host "Running Add-DistributionListMember script..."
	$progressBar1.Value = 10
	function OnAddMemberButtonClick {
		Write-Host "AddMemberButton clicked."
		$progressBar1.Value = 20
		$member = $memberInputBox.Text
		$group = $groupInputBox.Text
		$progressBar1.Value = 40
		Invoke-SingleMemberChange -Target $group -Member $member -Expected 'DistributionList' -Action 'add'
	}
	function OnOpenTemplateButtonClick {
		Write-Host "OpenTemplateButton clicked."
		$progressBar1.Value = 10
		Invoke-Item ".\Templates\Add-DistributionListMember.csv"
		$progressBar1.Value = 100
		CheckForErrors
		$progressBar1.Value = 0
	}
	function OnAddBulkMembersButtonClick {
		Write-Host "AddBulkMembersButton clicked."
		$progressBar1.Value = 10
		$typeCache = @{}
		$corrected = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
		$counts = @{ done = 0; noop = 0; failed = 0; skipped = 0 }
		Import-Csv ".\Templates\Add-DistributionListMember.csv" | ForEach-Object {
			Step-Progress   # keep the bar climbing per item
			$progressBar1.Value = 20
			$member = $_.Member
			$group = $_.Group
			switch (Invoke-BulkMemberRow -Target $group -Member $member -Expected 'DistributionList' -Action 'add' -Cache $typeCache -Corrected $corrected) {
				'done'    { $counts.done++ }
				'noop'    { $counts.noop++ }
				'failed'  { $counts.failed++ }
				'unknown' { $counts.skipped++ }
			}
		}
		Show-BulkSummary $counts 'add' $corrected
	}

	$scriptForm8 = New-MemberGroupDialog -Title 'Add-DistributionListMember' -ActionText 'Add Member' -BulkText 'Add Members' -WithPaste
	$memberInputBox = $scriptForm8.FindName('MemberInput')
	$groupInputBox = $scriptForm8.FindName('GroupInput')
	Enable-RecipientAutocomplete $memberInputBox 'User'
	Enable-RecipientAutocomplete $groupInputBox 'Group'
	$scriptForm8.FindName('ActionBtn').Add_Click({ OnAddMemberButtonClick })
	$scriptForm8.FindName('OpenTemplateBtn').Add_Click({ OnOpenTemplateButtonClick })
	$scriptForm8.FindName('BulkBtn').Add_Click({ OnAddBulkMembersButtonClick })
	$scriptForm8.FindName('PasteBtn').Add_Click({ Show-PasteMembersDialog -TargetPrefill $groupInputBox.Text })

	Write-Host "Loaded ScriptForm8."
	$progressBar1.Value = 0

	[void]$scriptForm8.ShowDialog()

	Stop-Transcript
}

# ---------------------------------------------------------------------------
# Add one alias to a mailbox. $AsPrimary promotes it to the PRIMARY address (the old primary
# becomes a secondary alias); otherwise it's added as a secondary alias. Pre-checks the alias
# domain is an accepted tenant domain so you get a friendly message instead of a raw Exchange
# error. Returns @{ Status='done'|'noop'|'failed'|'skipped'; Message }.
function Add-OneAlias([string]$Mailbox, [string]$Alias, [bool]$AsPrimary, $Accepted) {
	$res = @{ Status = 'failed'; Message = '' }
	$Mailbox = "$Mailbox".Trim(); $Alias = "$Alias".Trim()
	if (-not $Mailbox -or -not $Alias) { $res.Status = 'skipped'; $res.Message = 'blank mailbox or alias'; return $res }
	if ($Accepted -and (Test-IsExternalAddress $Alias $Accepted)) {
		$dom = $Alias.Substring($Alias.LastIndexOf('@') + 1)
		$res.Status = 'skipped'; $res.Message = "the domain '$dom' isn't an accepted domain in this tenant"; return $res
	}
	try {
		if ($AsPrimary) { Set-Mailbox -Identity $Mailbox -WindowsEmailAddress $Alias -ErrorAction Stop }
		else { Set-Mailbox -Identity $Mailbox -EmailAddresses @{Add = $Alias} -ErrorAction Stop }
		$res.Status = 'done'; return $res
	} catch {
		$msg = "$($_.Exception.Message)".Trim()
		if ($msg -match 'already|proxy|in use|ProxyAddress|must be unique|duplicate') { $res.Status = 'noop'; $res.Message = 'already assigned as an address' }
		else { $res.Status = 'failed'; $res.Message = $msg }
		return $res
	}
}

function New-EmailAliasDialog {
	param([string]$Title = 'Add-EmailAlias', [string]$ActionText = 'Add Alias', [string]$BulkText = 'Add Aliases', [string]$CheckText = 'Create Incremental Aliases', [switch]$WithPrimary)
	$primaryChk = if ($WithPrimary) { '<CheckBox x:Name="PrimaryCheck" Content="Set as primary address (single only)" Margin="0,10,0,0"/>' } else { '' }
	$previewChk = if ($WithPrimary) { '<CheckBox x:Name="PreviewCheck" Content="Preview only" Margin="0,10,0,0"/>' } else { '' }
	New-StyledDialog -Title $Title -Icon '&#xEBBC;' -BodyXaml @"
<StackPanel Margin="16" Orientation="Horizontal">
	<StackPanel Width="330">
		<Border Style="{DynamicResource Card}">
			<StackPanel>
				<TextBlock Text="Single" Style="{DynamicResource H3}"/>
				<Grid Margin="0,12,0,0">
					<Grid.ColumnDefinitions>
						<ColumnDefinition Width="70"/><ColumnDefinition Width="*"/>
					</Grid.ColumnDefinitions>
					<Grid.RowDefinitions>
						<RowDefinition Height="Auto"/><RowDefinition Height="Auto"/>
					</Grid.RowDefinitions>
					<TextBlock Text="Mailbox" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
					<TextBox x:Name="MailboxInput" Grid.Column="1"/>
					<TextBlock Text="Alias" Style="{DynamicResource Dim}" Grid.Row="1" VerticalAlignment="Center" Margin="0,8,0,0"/>
					<TextBox x:Name="AliasInput" Grid.Row="1" Grid.Column="1" Margin="0,8,0,0"/>
				</Grid>
				<Grid Margin="0,12,0,0">
					<Grid.ColumnDefinitions>
						<ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/>
					</Grid.ColumnDefinitions>
					<CheckBox x:Name="IncrementalCheck" Content="$CheckText" VerticalAlignment="Center"/>
					<TextBox x:Name="CountBox" Grid.Column="1" Width="64" Text="0" IsEnabled="False"
							 HorizontalContentAlignment="Center"/>
				</Grid>
				$primaryChk
				<Button x:Name="ActionBtn" Style="{DynamicResource BtnPrimary}" Content="$ActionText" Margin="0,14,0,0"/>
			</StackPanel>
		</Border>
		<Border Style="{DynamicResource Card}" Margin="0,12,0,0">
			<StackPanel>
				<TextBlock Text="Bulk" Style="{DynamicResource H3}"/>
				<Button x:Name="OpenTemplateBtn" Style="{DynamicResource BtnSecondary}" Content="Open Template" Margin="0,12,0,0"/>
				$previewChk
				<Button x:Name="BulkBtn" Style="{DynamicResource BtnPrimary}" Content="$BulkText" Margin="0,8,0,0"/>
			</StackPanel>
		</Border>
	</StackPanel>
	<Border Style="{DynamicResource Card}" Width="300" Margin="12,0,0,0" VerticalAlignment="Stretch">
		<StackPanel>
			<TextBlock Text="Info" Style="{DynamicResource H3}"/>
			<Button x:Name="GetAliasBtn" Style="{DynamicResource BtnSecondary}" Content="Get Current Aliases" Margin="0,12,0,0"/>
			<TextBox x:Name="InfoBox" Style="{DynamicResource TextArea}" Height="190" Margin="0,10,0,0" IsReadOnly="True"/>
			<Button x:Name="CopyBtn" Style="{DynamicResource BtnGhost}" Content="Copy to Clipboard" Margin="0,10,0,0"/>
		</StackPanel>
	</Border>
</StackPanel>
"@
}

function Add-EmailAlias {
	Start-Transcript -IncludeInvocationHeader -Path ".\Logs\Add-EmailAlias.txt"
	Write-Host "Running Add-EmailAlias script..."
	$progressBar1.Value = 10

	function OnAddAliasButtonClick {
		Write-Host "AddAliasButton clicked."
		$mailbox = $mailboxTextBox.Text
		$alias = $aliasTextBox.Text
		$accepted = Get-AcceptedDomainList
		if ($incrementalCheckBox.IsChecked -eq $true) {
			Write-Host "Creating incremental aliases..."
			$progressBar1.Value = 20
			$splitAlias = $alias -split '\@'
			$aliasName = $splitAlias[0]; $aliasDomain = $splitAlias[1]
			$created = [System.Collections.Generic.List[string]]::new()
			$failed  = [System.Collections.Generic.List[string]]::new()
			for ($i = 1; $i -le $numericUpDown1.Value; $i++) {
				Step-Progress
				$completeAlias = "$aliasName$i@$aliasDomain"
				$r = Add-OneAlias $mailbox $completeAlias $false $accepted
				if ($r.Status -eq 'done') { $created.Add($completeAlias) }
				elseif ($r.Status -eq 'noop') { $failed.Add("$completeAlias - already assigned") }
				else { $failed.Add("$completeAlias - $($r.Message)") }
			}
			Show-AccountResults "Add aliases to $mailbox" $created $failed
		} else {
			Write-Host "Creating single alias..."
			$progressBar1.Value = 40
			$asPrimary = ($primaryCheckBox.IsChecked -eq $true)
			$r = Add-OneAlias $mailbox $alias $asPrimary $accepted
			$progressBar1.Value = 100
			switch ($r.Status) {
				'done'    { $verb = if ($asPrimary) { "set as the primary address on" } else { "added to" }; Write-Host "$alias $verb $mailbox." -ForegroundColor Cyan; Show-Notice 'Alias added' "'$alias' was $verb `"$mailbox`"." 'Info' }
				'noop'    { Write-Host "$alias already assigned." -ForegroundColor Yellow; Show-Notice 'Already an alias' "'$alias' is already assigned as an address (on this or another recipient)." 'Info' }
				'skipped' { Write-Host "Skipped '$alias': $($r.Message)" -ForegroundColor Yellow; Show-Notice "Can't add that alias" "Couldn't add '$alias' - $($r.Message)." 'Warn' }
				'failed'  { Write-Host "Failed to add '$alias': $($r.Message)" -ForegroundColor Red; Show-Notice 'Add alias failed' "Couldn't add '$alias' to `"$mailbox`":`n`n$($r.Message)" 'Error' }
			}
			$progressBar1.Value = 0
		}
	}
	function OnOpenTemplateButtonClick {
		$progressBar1.Value = 10
		Invoke-Item ".\Templates\Add-EmailAlias.csv"
		$progressBar1.Value = 100
		CheckForErrors
		$progressBar1.Value = 0
	}
	function OnAddAliasBulkButtonClick {
		$accepted = Get-AcceptedDomainList
		$preview = ($previewCheckBox.IsChecked -eq $true)
		$created = [System.Collections.Generic.List[string]]::new()
		$failed  = [System.Collections.Generic.List[string]]::new()
		Import-Csv ".\Templates\Add-EmailAlias.csv" | ForEach-Object {
			Step-Progress   # keep the bar climbing per item
			$progressBar1.Value = 40
			$mailbox = "$($_.Mailbox)".Trim(); $alias = "$($_.Alias)".Trim()
			$label = "$alias -> $mailbox"
			if ($preview) {
				if (-not $mailbox -or -not $alias) { $failed.Add("$label - blank mailbox or alias") }
				elseif ($accepted -and (Test-IsExternalAddress $alias $accepted)) { $failed.Add("$label - domain not accepted") }
				else { $created.Add($label) }
				return
			}
			$r = Add-OneAlias $mailbox $alias $false $accepted
			if ($r.Status -eq 'done') { $created.Add($label) }
			elseif ($r.Status -eq 'noop') { $failed.Add("$label - already assigned") }
			else { $failed.Add("$label - $($r.Message)") }
		}
		Show-AccountResults 'Add email aliases' $created $failed -Preview:$preview
	}
	function OnIncrementalCheckBoxChecked {
		if ($incrementalCheckBox.IsChecked -eq $true) {
			$numericUpDown1.Enabled = $true
			$addAliasButton.Content = "Add Aliases"
		} elseif ($incrementalCheckBox.IsChecked -eq $false) {
			$numericUpDown1.Enabled = $false
			$addAliasButton.Content = "Add Alias"
		}
	}
	function OnGetAliasButtonClick {
		Write-Host "GetAliasButton clicked."
		$progressBar1.Value = 10
		$infoTextBox.Text = Get-Mailbox $mailboxTextBox.Text | Select-Object -ExpandProperty emailaddresses
		$progressBar1.Value = 100
		CheckForErrors
		$progressBar1.Value = 0
	}
	function OnCopyButtonClick {
		Write-Host "CopyButton clicked."
		$progressBar1.Value = 10
		Get-Mailbox $mailboxTextBox.Text | Select-Object -ExpandProperty emailaddresses | Set-Clipboard
		$progressBar1.Value = 80
		CheckForErrors
		OperationComplete
	}

	$emailAliasForm = New-EmailAliasDialog -WithPrimary
	$mailboxTextBox = $emailAliasForm.FindName('MailboxInput')
	Enable-RecipientAutocomplete $mailboxTextBox 'Mailbox'
	$aliasTextBox = $emailAliasForm.FindName('AliasInput')
	$incrementalCheckBox = $emailAliasForm.FindName('IncrementalCheck')
	$primaryCheckBox = $emailAliasForm.FindName('PrimaryCheck')
	$previewCheckBox = $emailAliasForm.FindName('PreviewCheck')
	$addAliasButton = $emailAliasForm.FindName('ActionBtn')
	$infoTextBox = $emailAliasForm.FindName('InfoBox')
	$numericUpDown1 = New-NumericProxy ($emailAliasForm.FindName('CountBox')) 1000
	$incrementalCheckBox.Add_Checked({ OnIncrementalCheckBoxChecked })
	$incrementalCheckBox.Add_Unchecked({ OnIncrementalCheckBoxChecked })
	$addAliasButton.Add_Click({ OnAddAliasButtonClick })
	$emailAliasForm.FindName('OpenTemplateBtn').Add_Click({ OnOpenTemplateButtonClick })
	$emailAliasForm.FindName('BulkBtn').Add_Click({ OnAddAliasBulkButtonClick })
	$emailAliasForm.FindName('GetAliasBtn').Add_Click({ OnGetAliasButtonClick })
	$emailAliasForm.FindName('CopyBtn').Add_Click({ OnCopyButtonClick })

	Write-Host "Loaded EmailAliasForm."
	$progressBar1.Value = 0

	[void]$emailAliasForm.ShowDialog()

	Stop-Transcript
}

# ===================== Copy a user's access to another user ==============================
# Mirror what one user "has" onto another: shared / other-mailbox Full Access + Send As,
# distribution-list membership, Teams / Microsoft 365 group membership, and (optional)
# security-group membership. Group membership is read in ONE Graph call (Get-MgUserMemberOf);
# Send As is a fast reverse lookup (Get-RecipientPermission -Trustee); Full Access has no
# reverse lookup so mailboxes are scanned one by one - which can take a few minutes in a big
# tenant and keeps the window busy while it runs (the app's usual UI-thread limit), so the
# bar steps per mailbox to show it's working.
#
# It classifies by the Exchange mailbox TYPE (RecipientTypeDetails), not by how a mailbox is
# used, so it can't tell a personal mailbox that's *used* like a shared one from a truly
# personal one. To handle that honestly: every item is labelled with its type and Preview
# lists them as a checklist - personal (user) mailboxes come UNCHECKED, so nothing personal is
# copied unless you deliberately tick it; shared mailboxes, lists and groups come checked.

# Build an inventory of what $Source has, honouring $Opts (@{ Mailbox; Dl; Unified; Security;
# UserMailboxes }). $Progress is called as & $Progress $done $total during the Full Access scan.
# Each item is @{ Kind; Id; Name; Type; Personal }. Returns ordered @{ Full; SendAs; Dl; Unified;
# Security = @(item); Skipped = @(string) }.
function Get-UserAccessInventory([string]$Source, [hashtable]$Opts, [scriptblock]$Progress) {
    $inv = [ordered]@{ Full = @(); SendAs = @(); Dl = @(); Unified = @(); Security = @(); Skipped = @() }

    # --- group memberships (distribution / Teams-M365 / security) in one Graph call ---
    if ($Opts.Dl -or $Opts.Unified -or $Opts.Security) {
        $groups = @()
        try { $groups = @(Get-MgUserMemberOf -UserId $Source -All -ErrorAction Stop) }
        catch { $inv.Skipped += "couldn't read group memberships: $($_.Exception.Message)" }
        foreach ($g in $groups) {
            $ap = $g.AdditionalProperties
            if (-not $ap -or "$($ap['@odata.type'])" -ne '#microsoft.graph.group') { continue }
            $name = "$($ap['displayName'])"; $mail = "$($ap['mail'])"
            $types = @($ap['groupTypes'])
            $isUnified = $types -contains 'Unified'
            $isDynamic = $types -contains 'DynamicMembership'
            $mailEnabled = [bool]$ap['mailEnabled']
            $securityEnabled = [bool]$ap['securityEnabled']
            $onprem = [bool]$ap['onPremisesSyncEnabled']
            if ($isDynamic) { $inv.Skipped += "$name (dynamic group - membership is set by rule)"; continue }
            if ($onprem)    { $inv.Skipped += "$name (synced from on-prem - manage it on-premises)"; continue }
            if ($isUnified) {
                if ($Opts.Unified) { if ($mail) { $inv.Unified += @{ Kind = 'Unified'; Id = $mail; Name = $name; Type = 'Teams / Microsoft 365 group'; Personal = $false } } else { $inv.Skipped += "$name (Teams/M365 group has no address)" } }
            } elseif ($mailEnabled) {
                if ($Opts.Dl) { if ($mail) { $inv.Dl += @{ Kind = 'Dl'; Id = $mail; Name = $name; Type = 'distribution list'; Personal = $false } } else { $inv.Skipped += "$name (distribution list has no address)" } }
            } else {
                if ($Opts.Security) { $inv.Security += @{ Kind = 'Security'; Id = $g.Id; Name = $name; Type = 'security group'; Personal = $false } }
            }
        }
    }

    # --- Send As (fast reverse lookup by trustee) - labelled by target type; personal ones come
    #     back too but are flagged Personal so Preview leaves them unchecked ---
    if ($Opts.Mailbox) {
        try {
            $sa = @(Get-RecipientPermission -Trustee $Source -ErrorAction Stop | Where-Object { $_.AccessControlType -eq 'Allow' -and ("$($_.AccessRights)" -match 'SendAs') })
            foreach ($p in $sa) {
                $id = "$($p.Identity)"
                if (-not $id -or $id -eq $Source -or $id -match 'NT AUTHORITY') { continue }
                $rtd = ''
                try { $rtd = "$((Get-Recipient -Identity $id -ErrorAction Stop | Select-Object -First 1).RecipientTypeDetails)" } catch {}
                $type = if ($rtd) { Get-RecipientTypeName $rtd } else { 'mailbox' }
                $inv.SendAs += @{ Kind = 'SendAs'; Id = $id; Name = $id; Type = $type; Personal = ($rtd -eq 'UserMailbox') }
            }
        } catch { $inv.Skipped += "couldn't read Send As grants: $($_.Exception.Message)" }
    }

    # --- Full Access (no reverse lookup exists - scan mailboxes). Shared always; user mailboxes
    #     only when asked (slower). Whatever is found is labelled + flagged Personal for user ones. ---
    if ($Opts.Mailbox) {
        $rtd = if ($Opts.UserMailboxes) { @('SharedMailbox', 'UserMailbox', 'RoomMailbox', 'EquipmentMailbox') } else { @('SharedMailbox') }
        $mbxs = @()
        try { $mbxs = @(Get-Mailbox -ResultSize Unlimited -RecipientTypeDetails $rtd -ErrorAction Stop) }
        catch { $inv.Skipped += "couldn't list mailboxes to scan for Full Access: $($_.Exception.Message)" }
        $i = 0; $tot = $mbxs.Count
        foreach ($mb in $mbxs) {
            $i++
            if ($Progress) { & $Progress $i $tot }
            if ("$($mb.PrimarySmtpAddress)" -eq $Source) { continue }   # their own mailbox
            try {
                $perm = @(Get-MailboxPermission -Identity $mb.Identity -User $Source -ErrorAction SilentlyContinue | Where-Object { -not $_.IsInherited -and $_.Deny -ne $true -and ("$($_.AccessRights)" -match 'FullAccess') })
                if ($perm.Count) {
                    $mrtd = "$($mb.RecipientTypeDetails)"
                    $inv.Full += @{ Kind = 'Full'; Id = "$($mb.PrimarySmtpAddress)"; Name = "$($mb.DisplayName)"; Type = (Get-RecipientTypeName $mrtd); Personal = ($mrtd -eq 'UserMailbox') }
                }
            } catch {}
        }
    }
    return $inv
}

# Apply a FLAT list of chosen items (each @{ Kind; Id; Name }) onto $Target. Each grant tolerates
# its own failure so one hiccup doesn't stop the rest; "already has it" is counted, not failed.
# Returns @{ Granted; Already; Failed = @(string); Total }.
function Copy-UserAccess([string]$Target, [object[]]$Items, [scriptblock]$Progress) {
    $granted = 0; $already = 0; $failed = @()
    $targetId = ''
    if (@($Items | Where-Object { $_.Kind -eq 'Security' }).Count) { try { $targetId = (Get-MgUser -UserId $Target -ErrorAction Stop).Id } catch {} }
    $i = 0; $tot = @($Items).Count
    foreach ($it in $Items) {
        $i++
        if ($Progress) { & $Progress $i $tot }
        try {
            switch ($it.Kind) {
                'Full'     { Add-MailboxPermission -Identity $it.Id -User $Target -AccessRights FullAccess -InheritanceType All -AutoMapping $true -ErrorAction Stop | Out-Null }
                'SendAs'   { Add-RecipientPermission -Identity $it.Id -Trustee $Target -AccessRights SendAs -Confirm:$false -ErrorAction Stop | Out-Null }
                'Dl'       { Add-DistributionGroupMember -Identity $it.Id -Member $Target -ErrorAction Stop }
                'Unified'  { Add-UnifiedGroupLinks -Identity $it.Id -LinkType Members -Links $Target -ErrorAction Stop }
                'Security' { if ($targetId) { New-MgGroupMember -GroupId $it.Id -DirectoryObjectId $targetId -ErrorAction Stop } else { throw "couldn't resolve $Target for the security-group add" } }
            }
            $granted++
            Write-Host "  copied $($it.Kind): $($it.Name)" -ForegroundColor Cyan
        } catch {
            $msg = "$($_.Exception.Message)".Trim()
            if (Test-HarmlessMemberError $msg) { $already++; Write-Host "  already had $($it.Kind): $($it.Name)" -ForegroundColor Yellow }
            else { $failed += "$($it.Name) [$($it.Kind)] - $msg"; Write-Host "  couldn't copy $($it.Kind) '$($it.Name)': $msg" -ForegroundColor Red }
        }
    }
    return @{ Granted = $granted; Already = $already; Failed = $failed; Total = $tot }
}

function New-CopyAccessDialog {
    New-StyledDialog -Title "Copy a user's access" -Icon '&#xED93;' -BodyXaml @'
<StackPanel Margin="16" Width="470">
    <Border Style="{DynamicResource Card}">
        <StackPanel>
            <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="46"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
                <TextBlock Text="From" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
                <TextBox x:Name="SourceInput" Grid.Column="1"/>
                <TextBlock Text="To" Style="{DynamicResource Dim}" Grid.Row="1" VerticalAlignment="Center" Margin="0,8,0,0"/>
                <TextBox x:Name="TargetInput" Grid.Row="1" Grid.Column="1" Margin="0,8,0,0"/>
            </Grid>
            <TextBlock Text="Look for:" Style="{DynamicResource Small}" Margin="0,12,0,4"/>
            <CheckBox x:Name="ChkMailbox" Content="Shared / other mailbox access (Full Access + Send As)" IsChecked="True"/>
            <CheckBox x:Name="ChkDl" Content="Distribution list memberships" IsChecked="True" Margin="0,6,0,0"/>
            <CheckBox x:Name="ChkUnified" Content="Teams / Microsoft 365 group memberships" IsChecked="True" Margin="0,6,0,0"/>
            <CheckBox x:Name="ChkSecurity" Content="Security group memberships" Margin="0,6,0,0"/>
            <CheckBox x:Name="ChkUserMbx" Content="Also scan regular user mailboxes for Full Access (slower)" Margin="0,10,0,0"/>
            <TextBlock Text="Personal (user) mailboxes are listed UNCHECKED - nothing personal is copied unless you tick it. Shared mailboxes, lists and groups are checked. Full Access on a user mailbox is only found when you turn on the scan above (slow in a big tenant); Send As on a user mailbox always shows." Style="{DynamicResource Small}" TextWrapping="Wrap" Margin="0,6,0,0"/>
            <TextBlock Text="Step 1 &#183; Load what this user has" Style="{DynamicResource Small}" Margin="0,12,0,4"/>
            <Button x:Name="LoadBtn" Style="{DynamicResource BtnPrimary}" Content="Load their access"/>
        </StackPanel>
    </Border>
    <Border Style="{DynamicResource Card}" Margin="0,12,0,0">
        <StackPanel>
            <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
                <TextBlock Text="Step 2 &#183; Review and choose what to copy" Style="{DynamicResource H3}" VerticalAlignment="Center"/>
                <StackPanel Grid.Column="1" Orientation="Horizontal">
                    <Button x:Name="SelectAllBtn" Style="{DynamicResource BtnGhost}" Content="All" Padding="8,2"/>
                    <Button x:Name="SelectNoneBtn" Style="{DynamicResource BtnGhost}" Content="None" Padding="8,2" Margin="4,0,0,0"/>
                </StackPanel>
            </Grid>
            <TextBlock x:Name="ResultStatus" Style="{DynamicResource Small}" Margin="0,4,0,0" TextWrapping="Wrap" Text="Enter the two users above and click Load their access. What they have will be listed here to review - personal mailboxes come unchecked - then Copy selected."/>
            <ScrollViewer MaxHeight="240" Margin="0,8,0,0" VerticalScrollBarVisibility="Auto">
                <StackPanel x:Name="ItemsHost"/>
            </ScrollViewer>
            <Button x:Name="CopyBtn" Style="{DynamicResource BtnPrimary}" Content="Copy selected" Margin="0,12,0,0" IsEnabled="False"/>
        </StackPanel>
    </Border>
</StackPanel>
'@
}

# Open the copy-access dialog (owned by $Owner so it sits on top of the Add-MailboxMember window).
function Invoke-CopyAccessDialog {
    param([object]$Owner)
    $dlg = New-CopyAccessDialog
    if ($Owner) { try { $dlg.Owner = $Owner } catch {} }
    $srcBox = $dlg.FindName('SourceInput'); $tgtBox = $dlg.FindName('TargetInput')
    Enable-RecipientAutocomplete $srcBox 'User'
    Enable-RecipientAutocomplete $tgtBox 'User'
    $chkMbx = $dlg.FindName('ChkMailbox'); $chkDl = $dlg.FindName('ChkDl'); $chkUni = $dlg.FindName('ChkUnified')
    $chkSec = $dlg.FindName('ChkSecurity'); $chkUserMbx = $dlg.FindName('ChkUserMbx')
    $itemsHost = $dlg.FindName('ItemsHost'); $status = $dlg.FindName('ResultStatus'); $copyBtn = $dlg.FindName('CopyBtn')

    function Get-CopyOpts {
        @{ Mailbox = ($chkMbx.IsChecked -eq $true); Dl = ($chkDl.IsChecked -eq $true); Unified = ($chkUni.IsChecked -eq $true); Security = ($chkSec.IsChecked -eq $true); UserMailboxes = ($chkUserMbx.IsChecked -eq $true) }
    }
    function Add-Section([string]$Header, $Items) {
        if (-not @($Items).Count) { return }
        $h = New-Object System.Windows.Controls.TextBlock
        $h.Text = $Header; $h.FontSize = 11; $h.Margin = '0,8,0,2'
        $h.SetResourceReference([System.Windows.Controls.TextBlock]::ForegroundProperty, 'TextDimBrush')
        [void]$itemsHost.Children.Add($h)
        foreach ($x in $Items) {
            $cb = New-Object System.Windows.Controls.CheckBox
            $label = "$($x.Name)"
            if ($x.Type) { $label += "   [$($x.Type)]" }
            if ($x.Id -and $x.Id -ne $x.Name) { $label += "   <$($x.Id)>" }
            $cb.Content = $label
            $cb.IsChecked = (-not $x.Personal)
            $cb.Margin = '2,2,0,0'
            $cb.Tag = $x
            [void]$itemsHost.Children.Add($cb)
        }
    }
    function Set-AllChecks([bool]$On) {
        foreach ($c in $itemsHost.Children) { if ($c -is [System.Windows.Controls.CheckBox]) { $c.IsChecked = $On } }
    }
    function Get-Chosen {
        $chosen = @()
        foreach ($c in $itemsHost.Children) { if ($c -is [System.Windows.Controls.CheckBox] -and $c.IsChecked -and $c.Tag) { $chosen += $c.Tag } }
        return $chosen
    }
    function Get-Validated {
        $src = $srcBox.Text.Trim(); $tgt = $tgtBox.Text.Trim()
        if (-not $src -or -not $tgt) { Show-Notice 'Missing info' 'Enter both a From user and a To user.' 'Warn'; return $null }
        if ($src -eq $tgt) { Show-Notice 'Same user' 'The From and To users are the same.' 'Warn'; return $null }
        if (-not (Get-MgContext)) { Show-Notice 'Not connected' 'Connect to the tenant first (top bar).' 'Warn'; return $null }
        $o = Get-CopyOpts
        if (-not ($o.Mailbox -or $o.Dl -or $o.Unified -or $o.Security)) { Show-Notice 'Nothing selected' 'Tick at least one kind of access to look for.' 'Warn'; return $null }
        return @{ Src = $src; Tgt = $tgt; Opts = $o }
    }
    $scanProgress = { param($done, $total) Set-LoopProgress $done $total 12 90 }

    function OnLoadClick {
        $v = Get-Validated; if (-not $v) { return }
        $copyBtn.IsEnabled = $false
        $itemsHost.Children.Clear()
        $status.Text = "Generating preview for $($v.Src) - this can take a moment..."
        $progressBar1.Value = 12
        $inv = Get-UserAccessInventory $v.Src $v.Opts $scanProgress
        Add-Section 'Full Access (mailboxes)' $inv.Full
        Add-Section 'Send As (mailboxes)' $inv.SendAs
        Add-Section 'Distribution lists' $inv.Dl
        Add-Section 'Teams / Microsoft 365 groups' $inv.Unified
        Add-Section 'Security groups' $inv.Security
        $found = @($inv.Full).Count + @($inv.SendAs).Count + @($inv.Dl).Count + @($inv.Unified).Count + @($inv.Security).Count
        $personal = @(@($inv.Full) + @($inv.SendAs) | Where-Object { $_.Personal }).Count
        $progressBar1.Value = 100
        if (-not $found) {
            $status.Text = "Found nothing for $($v.Src) with those options." + $(if (@($inv.Skipped).Count) { "  Skipped: " + (@($inv.Skipped) -join '; ') } else { '' })
        } else {
            $copyBtn.IsEnabled = $true
            $msg = "Found $found item(s) for $($v.Src). Review below, then click Copy selected to give them to $($v.Tgt)."
            if ($personal) { $msg += "  $personal personal mailbox(es) are unchecked - tick any that are really shared." }
            if (@($inv.Skipped).Count) { $msg += "  Skipped " + @($inv.Skipped).Count + " (dynamic / on-prem / no address)." }
            $status.Text = $msg
        }
        Write-Host "Loaded $($v.Src)'s access: $found item(s)." -ForegroundColor Cyan
        $progressBar1.Value = 0
    }
    function OnCopyClick {
        $v = Get-Validated; if (-not $v) { return }
        $chosen = Get-Chosen
        if (-not @($chosen).Count) {
            if (-not @($itemsHost.Children).Count) { Show-Notice 'Load first' 'Click Load their access first to list what this user has, then tick what to copy.' 'Info' }
            else { Show-Notice 'Nothing ticked' 'Tick at least one item to copy.' 'Warn' }
            return
        }
        Write-Host "Copying $(@($chosen).Count) selected item(s) to $($v.Tgt)..." -ForegroundColor Cyan
        $progressBar1.Value = 12
        $applyProgress = { param($done, $total2) Set-LoopProgress $done $total2 12 98 }
        $res = Copy-UserAccess $v.Tgt $chosen $applyProgress
        $progressBar1.Value = 100
        $summary = @("Copied to $($v.Tgt).", "Granted: $($res.Granted)")
        if ($res.Already) { $summary += "Already had: $($res.Already)" }
        if (@($res.Failed).Count) { $summary += "Failed: $(@($res.Failed).Count)"; $res.Failed | ForEach-Object { $summary += "  $_" } }
        $status.Text = ($summary -join '  ')
        $kind = if (@($res.Failed).Count) { 'Warn' } else { 'Info' }
        Show-Notice 'Copy access' ($summary -join "`r`n") $kind
        $progressBar1.Value = 0
    }

    # Enforce Step 1 -> Step 2: Copy stays disabled until a preview is loaded, and re-locks if the
    # From user or the "look for" options change, so a stale list can never be copied.
    $markStale = {
        $copyBtn.IsEnabled = $false
        if (@($itemsHost.Children).Count) { $itemsHost.Children.Clear(); $status.Text = "Details changed - click Load their access again to refresh the list." }
    }.GetNewClosure()
    $srcBox.Add_TextChanged($markStale)
    foreach ($c in @($chkMbx, $chkDl, $chkUni, $chkSec, $chkUserMbx)) { $c.Add_Checked($markStale); $c.Add_Unchecked($markStale) }
    $dlg.FindName('LoadBtn').Add_Click({ OnLoadClick })
    $dlg.FindName('CopyBtn').Add_Click({ OnCopyClick })
    $dlg.FindName('SelectAllBtn').Add_Click({ Set-AllChecks $true })
    $dlg.FindName('SelectNoneBtn').Add_Click({ Set-AllChecks $false })
    [void]$dlg.ShowDialog()
}


# ---------------------------------------------------------------------------
function New-MailboxMemberDialog {
	New-StyledDialog -Title 'Add-MailboxMember' -Icon '&#xED93;' -BodyXaml @'
<StackPanel Margin="16" Width="360">
	<Border Style="{DynamicResource Card}">
		<StackPanel>
			<Grid>
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="70"/><ColumnDefinition Width="*"/>
				</Grid.ColumnDefinitions>
				<Grid.RowDefinitions>
					<RowDefinition Height="Auto"/><RowDefinition Height="Auto"/>
				</Grid.RowDefinitions>
				<TextBlock Text="Member" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
				<TextBox x:Name="MemberInput" Grid.Column="1"/>
				<TextBlock Text="Mailbox" Style="{DynamicResource Dim}" Grid.Row="1" VerticalAlignment="Center" Margin="0,8,0,0"/>
				<TextBox x:Name="MailboxInput" Grid.Row="1" Grid.Column="1" Margin="0,8,0,0"/>
			</Grid>
			<StackPanel Orientation="Horizontal" Margin="0,12,0,0">
				<RadioButton x:Name="AddMemberChip" Style="{DynamicResource Chip}" GroupName="MailboxMode" Content="Add Member"/>
				<RadioButton x:Name="RemoveMemberChip" Style="{DynamicResource Chip}" GroupName="MailboxMode" Content="Remove Member" Margin="8,0,0,0"/>
			</StackPanel>
			<Button x:Name="MemberBtn" Style="{DynamicResource BtnPrimary}" Content="Add Member" Margin="0,14,0,0"/>
			<TextBlock Text="Only apply a single permission:" Style="{DynamicResource Small}" Margin="0,12,0,4"/>
			<Grid>
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="*"/><ColumnDefinition Width="8"/>
					<ColumnDefinition Width="*"/><ColumnDefinition Width="8"/>
					<ColumnDefinition Width="*"/>
				</Grid.ColumnDefinitions>
				<Button x:Name="FullAccessBtn" Style="{DynamicResource BtnSecondary}" Content="FullAccess" Padding="6,7"/>
				<Button x:Name="SendOnBehalfBtn" Style="{DynamicResource BtnSecondary}" Content="SendOnBehalf" Grid.Column="2" Padding="6,7"/>
				<Button x:Name="SendAsBtn" Style="{DynamicResource BtnSecondary}" Content="SendAs" Grid.Column="4" Padding="6,7"/>
			</Grid>
		</StackPanel>
	</Border>
	<Border Style="{DynamicResource Card}" Margin="0,12,0,0">
		<StackPanel>
			<TextBlock Text="Bulk" Style="{DynamicResource H3}"/>
			<Button x:Name="OpenTemplateBtn" Style="{DynamicResource BtnSecondary}" Content="Open Template" Margin="0,12,0,0"/>
			<Button x:Name="BulkMembersBtn" Style="{DynamicResource BtnPrimary}" Content="Add Members" Margin="0,8,0,0"/>
			<Button x:Name="PasteBtn" Style="{DynamicResource BtnSecondary}" Content="Paste List..." Margin="0,8,0,0"/>
		</StackPanel>
	</Border>
	<Border Style="{DynamicResource Card}" Margin="0,12,0,0">
		<StackPanel>
			<TextBlock Text="Copy a user's access" Style="{DynamicResource H3}"/>
			<TextBlock Text="Give one user the same shared mailboxes, distribution lists and Teams / Microsoft 365 groups as another user." Style="{DynamicResource Small}" TextWrapping="Wrap" Margin="0,4,0,0"/>
			<Button x:Name="CopyAccessBtn" Style="{DynamicResource BtnSecondary}" Content="Copy access from a user..." Margin="0,10,0,0"/>
		</StackPanel>
	</Border>
</StackPanel>
'@
}

function Add-MailboxMember {
	param([string]$MailboxPrefill = '')   # when set (e.g. called from the termination script), pre-fills the mailbox
	$progressBar1.Value = 10
	$Script:mailboxMemberMode = 0
	$startedTranscript = $false
	if ($selectedScript -eq "Add-MailboxMember") {
		Start-Transcript -IncludeInvocationHeader -Path ".\Logs\Add-MailboxMember.txt"; $startedTranscript = $true
		Write-Host "Running Add-MailboxMember script..."
		$Script:mailboxMemberMode = 0
	} elseif ($selectedScript -eq "Remove-MailboxMember") {
		Start-Transcript -IncludeInvocationHeader -Path ".\Logs\Remove-MailboxMember.txt"; $startedTranscript = $true
		Write-Host "Running Remove-MailboxMember script..."
		$Script:mailboxMemberMode = 1
	}
	$progressBar1.Value = 20
	function OnRadioButtonSelect {
		if ($addMemberRadioButton.IsChecked -eq $true) {
			Set-DialogTitle $scriptForm1 "Add-MailboxMember"
			$memberButton.Content = "Add Member"
			$bulkMembersButton.Content = "Add Members"
			$Script:mailboxMemberMode = 0
		}
		elseif ($removeMemberRadioButton.IsChecked -eq $true) {
			Set-DialogTitle $scriptForm1 "Remove-MailboxMember"
			$memberButton.Content = "Remove Member"
			$bulkMembersButton.Content = "Remove Members"
			$Script:mailboxMemberMode = 1
		}
		Write-Host "Mode = $mailboxMemberMode"
		CheckForErrors
	}
	# All four mailbox buttons auto-route: if the "mailbox" is really a distribution list or
	# Teams / M365 group, the person is added to / removed from it as a member (mailbox-only
	# rights like Send As fall back to plain membership), and the summary says so afterward.
	function OnMemberButtonClick {
		$act = if ($mailboxMemberMode -eq 0) { 'add' } else { 'remove' }
		Invoke-SingleMemberChange -Target $mailboxInputBox.Text -Member $memberInputBox.Text -Expected 'Mailbox' -Action $act -MailboxRight 'FullAndSendAs'
		CheckForErrors
	}
	function OnFullAccessButtonClick {
		$act = if ($mailboxMemberMode -eq 0) { 'add' } else { 'remove' }
		Invoke-SingleMemberChange -Target $mailboxInputBox.Text -Member $memberInputBox.Text -Expected 'Mailbox' -Action $act -MailboxRight 'FullAccess'
		CheckForErrors
	}
	function OnSendOnBehalfButtonClick {
		$act = if ($mailboxMemberMode -eq 0) { 'add' } else { 'remove' }
		Invoke-SingleMemberChange -Target $mailboxInputBox.Text -Member $memberInputBox.Text -Expected 'Mailbox' -Action $act -MailboxRight 'SendOnBehalf'
		CheckForErrors
	}
	function OnSendAsButtonClick {
		$act = if ($mailboxMemberMode -eq 0) { 'add' } else { 'remove' }
		Invoke-SingleMemberChange -Target $mailboxInputBox.Text -Member $memberInputBox.Text -Expected 'Mailbox' -Action $act -MailboxRight 'SendAs'
		CheckForErrors
	}
	function OnOpenTemplateButtonClick {
		if ($mailboxMemberMode -eq 0) {
			Write-Host "Open template button clicked."
			$progressBar1.Value = 10
			Invoke-Item ".\Templates\Add-MailboxMember.csv"
			$progressBar1.Value = 0
		} elseif ($mailboxMemberMode -eq 1) {
			Write-Host "Open template button clicked."
			$progressBar1.Value = 10
			Invoke-Item ".\Templates\Remove-MailboxMember.csv"
			$progressBar1.Value = 0
		}
		CheckForErrors
	}
	function OnBulkMembersButtonClick {
		$progressBar1.Value = 10
		$typeCache = @{}
		$corrected = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
		$counts = @{ done = 0; noop = 0; failed = 0; skipped = 0 }
		$act = if ($mailboxMemberMode -eq 0) { 'add' } else { 'remove' }
		$csv = if ($mailboxMemberMode -eq 0) { ".\Templates\Add-MailboxMember.csv" } else { ".\Templates\Remove-MailboxMember.csv" }
		Import-Csv $csv | ForEach-Object {
			Step-Progress   # keep the bar climbing per item
			$member = $_.Member
			$mailbox = $_.Mailbox
			$progressBar1.Value = 40
			switch (Invoke-BulkMemberRow -Target $mailbox -Member $member -Expected 'Mailbox' -Action $act -Cache $typeCache -Corrected $corrected -MailboxRight 'FullAndSendAs') {
				'done'    { $counts.done++ }
				'noop'    { $counts.noop++ }
				'failed'  { $counts.failed++ }
				'unknown' { $counts.skipped++ }
			}
		}
		Show-BulkSummary $counts $act $corrected
	}

	$scriptForm1 = New-MailboxMemberDialog
	$memberInputBox = $scriptForm1.FindName('MemberInput')
	$mailboxInputBox = $scriptForm1.FindName('MailboxInput')
	if ($MailboxPrefill) { $mailboxInputBox.Text = $MailboxPrefill }
	Enable-RecipientAutocomplete $memberInputBox 'User'
	Enable-RecipientAutocomplete $mailboxInputBox 'Mailbox'
	$addMemberRadioButton = $scriptForm1.FindName('AddMemberChip')
	$removeMemberRadioButton = $scriptForm1.FindName('RemoveMemberChip')
	$memberButton = $scriptForm1.FindName('MemberBtn')
	$bulkMembersButton = $scriptForm1.FindName('BulkMembersBtn')
	$addMemberRadioButton.Add_Checked({ OnRadioButtonSelect })
	$removeMemberRadioButton.Add_Checked({ OnRadioButtonSelect })
	$memberButton.Add_Click({ OnMemberButtonClick })
	$scriptForm1.FindName('FullAccessBtn').Add_Click({ OnFullAccessButtonClick })
	$scriptForm1.FindName('SendOnBehalfBtn').Add_Click({ OnSendOnBehalfButtonClick })
	$scriptForm1.FindName('SendAsBtn').Add_Click({ OnSendAsButtonClick })
	$scriptForm1.FindName('OpenTemplateBtn').Add_Click({ OnOpenTemplateButtonClick })
	$bulkMembersButton.Add_Click({ OnBulkMembersButtonClick })
	$scriptForm1.FindName('PasteBtn').Add_Click({ Show-PasteMembersDialog -TargetPrefill $mailboxInputBox.Text -Action $(if ($mailboxMemberMode -eq 0) { 'add' } else { 'remove' }) })
	$scriptForm1.FindName('CopyAccessBtn').Add_Click({ Invoke-CopyAccessDialog -Owner $scriptForm1 })

	if ($mailboxMemberMode -eq 0) {
		Set-DialogTitle $scriptForm1 "Add-MailboxMember"
		$memberButton.Content = "Add Member"
		$bulkMembersButton.Content = "Add Members"
		$addMemberRadioButton.IsChecked = $true
	} elseif ($mailboxMemberMode -eq 1) {
		Set-DialogTitle $scriptForm1 "Remove-MailboxMember"
		$memberButton.Content = "Remove Member"
		$bulkMembersButton.Content = "Remove Members"
		$removeMemberRadioButton.IsChecked = $true
	}

	Write-Host "Loaded ScriptForm1."
	$progressBar1.Value = 0

	[void]$scriptForm1.ShowDialog()

	if ($startedTranscript) { Stop-Transcript }
}

# ---------------------------------------------------------------------------
function New-TrustedSenderDialog {
	New-StyledDialog -Title 'Add-TrustedSender' -Icon '&#xF039;' -BodyXaml @'
<StackPanel Margin="16" Width="360">
	<Border Style="{DynamicResource Card}">
		<StackPanel>
			<Grid>
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="110"/><ColumnDefinition Width="*"/>
				</Grid.ColumnDefinitions>
				<TextBlock Text="Email or Domain" Style="{DynamicResource Dim}" VerticalAlignment="Center"/>
				<TextBox x:Name="TrustedSenderInput" Grid.Column="1"/>
			</Grid>
			<TextBlock Style="{DynamicResource Small}" Margin="0,10,0,0"
					   Text="Adds the address or domain to the trusted senders list of every mailbox in the tenant. This can take a while on big tenants."/>
			<Button x:Name="TrustedSenderBtn" Style="{DynamicResource BtnPrimary}" Content="Add Trusted Sender" Margin="0,14,0,0" IsDefault="True"/>
		</StackPanel>
	</Border>
</StackPanel>
'@
}

function Add-TrustedSender {
	Start-Transcript -IncludeInvocationHeader -Path ".\Logs\Add-TrustedSender.txt"
	Write-Host "Running Add-TrustedSender script..."
	$progressBar1.Value = 10
	function OnTrustedSenderButtonClick {
		$trustedSender = $trustedSenderInputBox.Text
		$progressBar1.Value = 10
		Get-Mailbox -RecipientTypeDetails UserMailbox -ResultSize Unlimited | ForEach-Object {
			Step-Progress
			$progressBar1.Value = 30
			Set-MailboxJunkEmailConfiguration $_.Name -TrustedSendersAndDomains @{Add=$trustedSender}
			$progressBar1.Value = 80
			Write-Host "Configured $($_.Name)"
		}
		Write-Host "Finished configuring mailboxes."
		CheckForErrors
		OperationComplete
	}

	$ScriptForm5 = New-TrustedSenderDialog
	$trustedSenderInputBox = $ScriptForm5.FindName('TrustedSenderInput')
	$ScriptForm5.FindName('TrustedSenderBtn').Add_Click({ OnTrustedSenderButtonClick })

	Write-Host "Loaded ScriptForm5"
	$progressBar1.Value = 0

	[void]$ScriptForm5.ShowDialog()

	Stop-Transcript
}

# ---------------------------------------------------------------------------
function Add-UnifiedGroupMember {
	Start-Transcript -IncludeInvocationHeader -Path ".\Logs\Add-UnifiedGroupMember.txt"
	Write-Host "Running Add-UnifiedGroupMember script..."
	$progressBar1.Value = 10
	function OnAddMemberButtonClick {
		Write-Host "AddMember button clicked."
		$progressBar1.Value = 20
		$member = $memberInputBox.Text
		$group = $groupInputBox.Text
		$progressBar1.Value = 30
		Invoke-SingleMemberChange -Target $group -Member $member -Expected 'UnifiedGroup' -Action 'add'
	}
	function OnOpenTemplateButtonClick {
		Write-Host "OpenTemplate button clicked."
		$progressBar1.Value = 10
		Invoke-Item ".\Templates\Add-UnifiedGroupMember.csv"
		$progressBar1.Value = 100
		CheckForErrors
		$progressBar1.Value = 0
	}
	function OnAddBulkMembersButtonClick {
		Write-Host "AddBulkMembers button clicked."
		$progressBar1.Value = 10
		$typeCache = @{}
		$corrected = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
		$counts = @{ done = 0; noop = 0; failed = 0; skipped = 0 }
		Import-Csv ".\Templates\Add-UnifiedGroupMember.csv" | ForEach-Object {
			Step-Progress   # keep the bar climbing per item
			$progressBar1.Value = 30
			$member = $_.Member
			$group = $_.Group
			switch (Invoke-BulkMemberRow -Target $group -Member $member -Expected 'UnifiedGroup' -Action 'add' -Cache $typeCache -Corrected $corrected) {
				'done'    { $counts.done++ }
				'noop'    { $counts.noop++ }
				'failed'  { $counts.failed++ }
				'unknown' { $counts.skipped++ }
			}
		}
		Show-BulkSummary $counts 'add' $corrected
	}

	$scriptForm8 = New-MemberGroupDialog -Title 'Add-UnifiedGroupMember' -ActionText 'Add Member' -BulkText 'Add Members' -WithPaste
	$memberInputBox = $scriptForm8.FindName('MemberInput')
	$groupInputBox = $scriptForm8.FindName('GroupInput')
	Enable-RecipientAutocomplete $memberInputBox 'User'
	Enable-RecipientAutocomplete $groupInputBox 'Group'
	$scriptForm8.FindName('ActionBtn').Add_Click({ OnAddMemberButtonClick })
	$scriptForm8.FindName('OpenTemplateBtn').Add_Click({ OnOpenTemplateButtonClick })
	$scriptForm8.FindName('BulkBtn').Add_Click({ OnAddBulkMembersButtonClick })
	$scriptForm8.FindName('PasteBtn').Add_Click({ Show-PasteMembersDialog -TargetPrefill $groupInputBox.Text })

	Write-Host "Loaded ScriptForm8."
	$progressBar1.Value = 0

	[void]$scriptForm8.ShowDialog()

	Stop-Transcript
}
